/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Upper layer protocol data from file (IPv4 or IPv6)
int
file_payload_data (GtkWidget *entry, int type, SPSData *data)
{
  int i, index, filelen, result, flag;
  char *filename;
  uint8_t *buffer;
  GtkWidget *dialog;
  FILE *fi;

  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // Create filechooser dialog.
  dialog = gtk_file_chooser_dialog_new ("Load File ...", (GtkWindow *) data->main_window, GTK_FILE_CHOOSER_ACTION_OPEN,
             "_Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL);

  // Run the filechooser dialog.
  result = gtk_dialog_run (GTK_DIALOG (dialog));

  // Interpret result returned from filechooser dialog.
  if (result == GTK_RESPONSE_ACCEPT)
  {
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    gtk_widget_destroy (dialog);
  } else {
    gtk_widget_destroy (dialog);
    return (EXIT_SUCCESS);
  }

  // Open file.
  if ((fi = fopen (filename, "rb")) == NULL) {
    sprintf (data->error_text, "file_payload_data(): fopen() failed.");
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Count total number of bytes in file.
  filelen = 0;
  while ((i = fgetc(fi)) != EOF) {
    filelen++;
  }
  rewind (fi);

  // Array of unsigned chars
  buffer = allocate_ustrmem (filelen);

  // Read file into buffer.
  for (index=0; index<filelen; index++) {
    if ((i = fgetc (fi)) == EOF) {
      sprintf (data->error_text, "file_payload_data(): fgetc() failed.");
      report_error (data);
      free (buffer);
      return (EXIT_FAILURE);
    }
    buffer[index] = (uint8_t) i;
  }

  // Close file descriptor.
  fclose (fi);

  // Clear current data.
  memset (data->payload[type], 0, IP_MAXPACKET * sizeof (uint8_t));

  // Clear text entry since we used a file and not the keyboard.
  gtk_entry_set_text (GTK_ENTRY (entry), "");

  // New payload length based upon file contents.
  data->payloadlen[type] = filelen;

  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  flag = 0;
  if ((type == 0) || (type == 9) || (type == 1) || (type == 10) || (type == 2) || (type == 11)) {
    if (truncate_ip4 (type, data)) {
      flag = 1;
    }
  } else {
    if (truncate_ip6 (type, data)) {
      flag = 1;
    }
  }
  if (flag) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // Copy payload from buffer.
  memcpy (data->payload[type], buffer, data->payloadlen[type] * sizeof (uint8_t));

  // Update lengths, offsets, and checksums.
  if ((type == 0) || (type == 1) || (type == 2) ||
      (type == 9) || (type == 10) || (type == 11)) {
    ip4data_update (type, data);

  } else if ((type == 3) || (type == 4) || (type == 5) ||
      (type == 12) || (type == 13) || (type == 14)) {
    ip6data_update (type, data);
  }

  // Make user aware a data file is loaded.
  gtk_entry_set_text (GTK_ENTRY (entry), "Data file loaded.");

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frame.
  if ((type == 0) || (type == 1) || (type == 2) || (type == 9) || (type == 10) || (type == 11)) {
    create_ip4_frame (type, data);  

  } else if ((type == 3) || (type == 4) || (type == 5) || (type == 12) || (type == 13) || (type == 14)) {
    create_ip6_frame (type, data);  
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (buffer);

  return (EXIT_SUCCESS);
}

// Extension header data entry from file (IPv6)
int
file_data (GtkWidget *entry, int *datlen, int maxdatlen, uint8_t *dat, int type, GtkWidget *parent, SPSData *data)
{
  int i, c, index, filelen, result;
  char *filename, *temp, *value;
  uint8_t *buffer;
  GtkWidget *dialog;
  FILE *fi;

  // Arrays of chars
  value = allocate_strmem (IP_MAXPACKET);
  temp = allocate_strmem (TMP_STRINGLEN);

  data->parent = parent;

  // Create filechooser dialog.
  dialog = gtk_file_chooser_dialog_new ("Load File ...", (GtkWindow *) data->parent, GTK_FILE_CHOOSER_ACTION_OPEN,
             "Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL);

  // Run the filechooser dialog.
  result = gtk_dialog_run (GTK_DIALOG (dialog));

  // Interpret result returned from filechooser dialog.
  if (result == GTK_RESPONSE_ACCEPT)
  {
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    gtk_widget_destroy (dialog);
  } else {
    gtk_widget_destroy (dialog);
    free (value);
    free (temp);
    return (EXIT_FAILURE);
  }

  // Open file.
  if ((fi = fopen (filename, "rb")) == NULL) {
    sprintf (data->error_text, "file_data(): fopen() failed.");
    report_error (data);
    free (value);
    free (temp);
    return (EXIT_FAILURE);
  }

  // Count total number of bytes in file.
  filelen = 0;
  while ((i = fgetc(fi)) != EOF) {
    filelen++;
  }
  rewind (fi);

  // Array of unsigned chars
  buffer = allocate_ustrmem (filelen);

  // Read file into buffer.
  for (index=0; index<filelen; index++) {
    if ((i = fgetc (fi)) == EOF) {
      sprintf (data->error_text, "file_data(): fgetc() failed.");
      report_error (data);
      free (buffer);
      free (value);
      free (temp);
      return (EXIT_FAILURE);
    }
    buffer[index] = (uint8_t) i;
  }

  // Close file descriptor.
  fclose (fi);

  // Clear current data.
  memset (dat, 0, maxdatlen * sizeof (uint8_t));

  // Clear text entry since we used a file and not the keyboard.
  gtk_entry_set_text (GTK_ENTRY (entry), "");

  // New data length based upon file contents or limit.
  if (filelen <= maxdatlen) {
    (*datlen) = filelen;
  } else {
    (*datlen) = maxdatlen;
    sprintf (data->warning_text, "Extension header data was truncated\nto accomodate maximum size of %i bytes.", maxdatlen);
    report_warning (data);
  }

  // Copy new data into array specified in file_data() argument four.
  memcpy (dat, buffer, (*datlen) * sizeof (uint8_t));

  // Display data in entry.
  // NOTE: Always displays as comma-separated decimal numbers.
  memset (value, 0, IP_MAXPACKET * sizeof (char));
  c = 0;
  for (i=0; i<(*datlen); i++) {
    sprintf (temp, "%" PRIu8, (uint8_t) dat[i]);
    strncpy (value + c, temp, IP_MAXPACKET - c - 1);  // Minus 1 for string termination.
    c += strnlen (temp, TMP_STRINGLEN);
    if (i != ((*datlen) - 1)) {  // There's more values to come.
      sprintf (value, "%s, ", value);  // Add a comma and space.
      c += 2;
    }
  }
  gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  if (truncate_ip6 (type, data)) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frame.
  create_ip6_frame (type, data);  
  create_6to4_frame (type + 3, data);

  // Free allocated memory.
  free (buffer);
  free (value);
  free (temp);

  return (EXIT_SUCCESS);
}
