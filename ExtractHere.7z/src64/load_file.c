/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int flood_mode;  // Flood flag - indicates a flood is selected with flood checkbutton

// Load SPS file, which contains settings selected by user when saved.
int
load_file (SPSData *data)
{
  int status, i, j, k, buffer_size, index;
  int result;
  int ip6_type[6]={3,4,5,12,13,14};
  struct Ethhdr *ethhdr;
  struct ip *ip4hdr;
  struct ip6_hdr *ip6hdr;
  struct tcphdr *tcphdr;
  struct icmp *icmp4hdr;
  struct icmp6_hdr *icmp6hdr;
  struct udphdr *udphdr;
  int16_t *ival16;
  int32_t *ival32;
  GtkWidget *dialog;
  GtkTextBuffer *textbuffer24, *textbuffer26, *textbuffer28, *textbuffer30, *textbuffer32;
  char *filename, *text;
  uint8_t *buffer, *flags;
  FILE *fi;

  // Array for error messages and various calculated values.
  text = allocate_strmem (TEXT_STRINGLEN);

  // Array of unsigned chars
  flags = allocate_ustrmem (256);

  // Create filechooser dialog.
  dialog = gtk_file_chooser_dialog_new ("Load File ...", (GtkWindow *) data->main_window, GTK_FILE_CHOOSER_ACTION_OPEN,
             "_Cancel", GTK_RESPONSE_CANCEL, "_Open", GTK_RESPONSE_ACCEPT, NULL);

  // Run the filechooser dialog.
  result = gtk_dialog_run (GTK_DIALOG (dialog));

  // Interpret result returned from filechooser dialog.
  if (result == GTK_RESPONSE_ACCEPT)
  {
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    gtk_widget_destroy (dialog);
  } else {
    free (text);
    free (flags);
    gtk_widget_destroy (dialog);
    return (EXIT_SUCCESS);
  }

  // Open file.
  if ((fi = fopen (filename, "rb")) == NULL) {
    sprintf (data->error_text, "load_file(): fopen() failed.");
    data->parent = data->main_window;
    report_error (data);
    free (text);
    free (flags);
    return (EXIT_FAILURE);
  }

  // Count total number of bytes in file.
  buffer_size = 0;
  while ((i = fgetc(fi)) != EOF) {
    buffer_size++;
  }
  rewind (fi);

  // Allocate memory to store file contents in buffer.
  buffer = allocate_ustrmem (buffer_size);

  // Read entire file into buffer.
  for (i=0; i<buffer_size; i++) {
    if ((k = fgetc (fi)) == EOF) {
      sprintf (data->error_text, "ERROR: Failed to read SPS file.");
      data->parent = data->main_window;
      report_error (data);
      fclose (fi);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    } else {
      buffer[i] = (uint8_t) k;
    }
  }

  // Close file descriptor.
  fclose (fi);

  // Check for SPS file identification
  index = 0;
  if (strncmp ((char *) buffer, "Simple Packet Sender", 20) != 0) {
    sprintf (data->error_text, "This does not appear to be an SPS file.");
    data->parent = data->main_window;
    report_error (data);
    free (text);
    free (buffer);
    free (flags);
    return (EXIT_FAILURE);
  }
  index += 80;

  // Retrieve the Save Data flags:
  //   flags[0] = Send Packet settings
  //   flags[1] = IPv6 over IPv4 (6to4) information
  //   flags[2] = TCP (IPv4)
  //   flags[3] = ICMP (IPv4)
  //   flags[4] = UDP (IPv4)
  //   flags[5] = TCP (IPv6)
  //   flags[6] = ICMP (IPv6)
  //   flags[7] = UDP (IPv6)
  //   flags[8] = Traceroute settings
  //   flags[9] = IPv6 over IPv4 (6to4) information for traceroute
  //   flags[10] = TCP (IPv4) for traceroute
  //   flags[11] = ICMP (IPv4) for traceroute
  //   flags[12] = UDP (IPv4) for traceroute
  //   flags[13] = TCP (IPv6) for traceroute
  //   flags[14] = ICMP (IPv6) for traceroute
  //   flags[15] = UDP (IPv6) for traceroute
  for (i=0; i<256; i++) {
    flags[i] = buffer[index+i];
  }
  index += (256);

  // Send Packet Settings
  if (flags[0]) {

    // Packet type(s) to send
    data->packet_type = buffer[index];
    switch (data->packet_type) {

      // IPv4 TCP
      case 0:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton1), TRUE);
        break;

      // IPv4 ICMP
      case 1:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton2), TRUE);
        break;

      // IPv4 UDP
      case 2:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton3), TRUE);
        break;

      // IPv4 TCP, ICMP, and UDP
      case 100:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton4), TRUE);
        break;

      // IPv6 TCP
      case 3:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton5), TRUE);
        break;

      // IPv6 ICMP
      case 4:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton6), TRUE);
        break;

      // IPv6 UDP
      case 5:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton7), TRUE);
        break;

      // IPv6 TCP, ICMP, and UDP
      case 101:
        gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton8), TRUE);
        break;

      default:
        fprintf (stderr, "ERROR: Invalid packet type %i in load_file().\n", data->packet_type);
        free (text);
        free (buffer);
        free (flags);
        exit (EXIT_FAILURE);
    }
    index++;

    // Number of packets
    ival32 = (int32_t *) (buffer + index);  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
    data->npackets = (int) ntohl (*ival32);  // Value was stored in network byte order for consistent endianess across platforms
    index += 4;
    sprintf (text, "%" PRIu64, data->npackets);
    gtk_entry_set_text (GTK_ENTRY (data->entry18), text);

    // Flag for flood mode
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton11), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton11), FALSE);
    }
    // Variable flood_mode will be changed by on_checkbutton11_toggled(), so set it now.
    flood_mode = buffer[index];
    index++;
  }

  // IPv6 over IPv4 (6to4)
  if (flags[1]) {

    // Flag to use 6to4
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton12), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton12), FALSE);
    }
    // Variable data->sixto4_flag will be changed by on_checkbutton12_toggled(), so set it now.
    data->sixto4_flag = buffer[index];
    index++;

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[6] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    data->ifmtu[7] = data->ifmtu[6];
    data->ifmtu[8] = data->ifmtu[6];
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton17), data->ifmtu[6]);
    index += 2;

    // Flag to use ethernet header from IPv6 TCP page
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton14), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton14), FALSE);
    }
    // Variable data->specify_ether[6] will be changed by on_checkbutton14_toggled(), so set it now.
    data->specify_ether[6] = buffer[index];
    index++;

    // Flag for randomizing IPv4 source address for TCP over 6to4
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton13), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton13), FALSE);
    }
    // Variable data->ran_tcp6to4_sourceip will be changed by on_checkbutton13_toggled(), so set it now.
    data->ran_tcp6to4_sourceip = buffer[index];
    index++;

    // 6to4 IPv4 header for TCP
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IPv4 header struct within buffer
    memcpy (&data->ip4hdr[6], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    if (inet_ntop (AF_INET, &(data->ip4hdr[6].ip_src), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for TCP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry125), text);
    index += IP4_HDRLEN;

    // Flag to use ethernet header from IPv6 ICMP page
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton47), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton47), FALSE);
    }
    // Variable data->specify_ether[7] will be changed by on_checkbutton47_toggled(), so set it now.
    data->specify_ether[7] = buffer[index];
    index++;

    // Flag for randomizing IPv4 source address for ICMP over 6to4
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton26), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton26), FALSE);
    }
    // Variable data->ran_icmp6to4_sourceip will be changed by on_checkbutton26_toggled(), so set it now.
    data->ran_icmp6to4_sourceip = buffer[index];
    index++;

    // 6to4 IPv4 header for ICMP
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IPv4 header struct within buffer
    memcpy (&data->ip4hdr[7], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    if (inet_ntop (AF_INET, &(data->ip4hdr[7].ip_src), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for ICMP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry160), text);
    index += IP4_HDRLEN;

    // Flag to use ethernet header from IPv6 UDP page
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton32), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton32), FALSE);
    }
    // Variable data->specify_ether[8] will be changed by on_checkbutton32_toggled(), so set it now.
    data->specify_ether[8] = buffer[index];
    index++;

    // Flag for randomizing IPv4 source address for UDP over 6to4
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton27), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton27), FALSE);
    }
    // Variable data->ran_udp6to4_sourceip will be changed by on_checkbutton27_toggled(), so set it now.
    data->ran_udp6to4_sourceip = buffer[index];
    index++;

    // 6to4 IPv4 header for UDP
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IPv4 header struct within buffer
    memcpy (&data->ip4hdr[8], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    if (inet_ntop (AF_INET, &(data->ip4hdr[8].ip_src), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for 6to4 UDP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry161), text);
    index += IP4_HDRLEN;
  }

  // IPv4 TCP
  if (flags[2]) {

    // Flag to specify ethernet header
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton18), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton18), FALSE);
    }
    // Variable data->specify_ether[0] will be changed by on_checkbutton18_toggled(), so set it now.
    data->specify_ether[0] = buffer[index];
    index++;

    // Interface name for IPv4 TCP
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[0][i] = buffer[index];
      index++;
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry150), data->ifname[0]);

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[0] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton5), data->ifmtu[0]);
    index += 2;

    // Ethernet header for IPv4 header for TCP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[0], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    // Destination MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[0].dst_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry144), text);
    // Source MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[0].src_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry145), text);
    // Ethernet type code
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[0].type_code));
    gtk_entry_set_text (GTK_ENTRY (data->entry146), text);
    index += ETH_HDRLEN;

    // Flag for randomizing IPv4 source address for TCP
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton5), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton5), FALSE);
    }
    // Variable data->ran_tcp4_sourceip will be changed by on_checkbutton5_toggled(), so set it now.
    data->ran_tcp4_sourceip = buffer[index];
    index++;

    // IPv4 header for TCP
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IP4 header struct within buffer
    memcpy (&data->ip4hdr[0], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    // IP header length
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_hl);
    gtk_entry_set_text (GTK_ENTRY (data->entry29), text);
    // Protocol version
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_v);
    gtk_entry_set_text (GTK_ENTRY (data->entry30), text);
    // Type of service
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_tos);
    gtk_entry_set_text (GTK_ENTRY (data->entry31), text);
    // Total length of datagram
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[0].ip_len));
    gtk_entry_set_text (GTK_ENTRY (data->entry32), text);
    // ID sequence number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[0].ip_id));
    gtk_entry_set_text (GTK_ENTRY (data->entry33), text);
    // Zero
    sprintf (text, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[0].ip_off) >> 15));
    gtk_entry_set_text (GTK_ENTRY (data->entry122), text);
    // Do not fragment
    sprintf (text, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[0].ip_off) >> 14) & 1u));
    gtk_entry_set_text (GTK_ENTRY (data->entry37), text);
    // More fragments following
    sprintf (text, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[0].ip_off) >> 13) & 1u));
    gtk_entry_set_text (GTK_ENTRY (data->entry38), text);
    // Fragmentation offset
    sprintf (text, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[0].ip_off) & 0x1fffu));
    gtk_entry_set_text (GTK_ENTRY (data->entry39), text);
    // Time-to-Live
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_ttl);
    gtk_entry_set_text (GTK_ENTRY (data->entry40), text);
    // Transport layer protocol
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_p);
    gtk_entry_set_text (GTK_ENTRY (data->entry74), text);
    // Source IPv4 address
    if (inet_ntop (AF_INET, &(data->ip4hdr[0].ip_src), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for TCP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry35), text);
    // Destination IPv4 address
    if (inet_ntop (AF_INET, &(data->ip4hdr[0].ip_dst), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file: inet_ntop() failed for TCP destination IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry36), text);

    // IPv4 header checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[0].ip_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry34), text);
    index += IP4_HDRLEN;

    // Flag for decimal or hexadecimal IP option entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton24), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton24), TRUE);
    }
    // Variable data->dec_hex_ipopt_tcp4 will be changed by on_checkbutton24_toggled(), so set it now.
    data->dec_hex_ipopt_tcp4 = buffer[index];
    index++;

    // IPv4 header options
    data->ip_nopt[0] = buffer[index];  // Number of IP options: ip_nopt[type] = int
    index++;
    for (i=0; i<data->ip_nopt[0]; i++) {
      data->ip_optlen[0][i] = buffer[index];  // IPv4 option length: ip_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->ip_nopt[0]; i++) {
      for (j=0; j<data->ip_optlen[0][i]; j++) {
        data->ip_options[0][i][j] = buffer[index];  // IPv4 options data: ip_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of IP options.
    data->ip_opt_totlen[0] = 0;
    for (i=0; i<data->ip_nopt[0]; i++) {
      data->ip_opt_totlen[0] += data->ip_optlen[0][i];
    }

    // IPv4 header options padding
    data->ip_optpadlen[0] = buffer[index];  // IPv4 options padding: ip_optpadlen[type] = int
    index++;
    sprintf (text, "%i", data->ip_nopt[0]);
    textbuffer30 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview30));
    gtk_text_buffer_set_text (textbuffer30, text, -1);

    // Flag for randomizing TCP source port
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton7), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton7), FALSE);
    }
    // Variable data->ran_tcp4_sourceport will be changed by on_checkbutton7_toggled(), so set it now.
    data->ran_tcp4_sourceport = buffer[index];
    index++;

    // TCP header
    tcphdr = (struct tcphdr *) (buffer + index);  // Cast tcphdr as pointer to TCP header struct within buffer
    memcpy (&data->tcphdr[0], tcphdr, TCP_HDRLEN * sizeof (uint8_t));  // Extract TCP header
    // Source port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_sport));
    gtk_entry_set_text (GTK_ENTRY (data->entry41), text);
    // Destination port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_dport));
    gtk_entry_set_text (GTK_ENTRY (data->entry42), text);
    // Sequence number
    sprintf (text, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[0].th_seq));
    gtk_entry_set_text (GTK_ENTRY (data->entry43), text);
    // Acknowledgement number
    sprintf (text, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[0].th_ack));
    gtk_entry_set_text (GTK_ENTRY (data->entry44), text);
    // Reserved
    sprintf (text, "%" PRIu8, (uint8_t) data->tcphdr[0].th_x2);
    gtk_entry_set_text (GTK_ENTRY (data->entry45), text);
    // Data offset
    sprintf (text, "%" PRIu8, (uint8_t) data->tcphdr[0].th_off);
    gtk_entry_set_text (GTK_ENTRY (data->entry46), text);
    // FIN flag
    sprintf (text, "%" PRIu8, (uint8_t) data->tcphdr[0].th_flags & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry47), text);
    // SYN flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 1) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry48), text);
    // RST flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 2) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry49), text);
    // PSH flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 3) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry50), text);
    // ACK flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 4) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry51), text);
    // URG flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 5) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry52), text);
    // ECE flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 6) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry53), text);
    // CWR flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[0].th_flags >> 7) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry54), text);
    // Window size
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_win));
    gtk_entry_set_text (GTK_ENTRY (data->entry55), text);
    // Urgent pointer
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_urp));
    gtk_entry_set_text (GTK_ENTRY (data->entry77), text);
    // TCP checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry56), text);
    index += TCP_HDRLEN;

    // Flag for decimal or hexadecimal TCP option entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton41), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton41), TRUE);
    }
    // Variable data->dec_hex_tcpopt_tcp4 will be changed by on_radiobutton41_toggled(), so set it now.
    data->dec_hex_tcpopt_tcp4 = buffer[index];
    index++;

    // TCP header options
    data->tcp_nopt[0] = buffer[index];  // Number of TCP options: tcp_nopt[type] = int
    index++;
    for (i=0; i<data->tcp_nopt[0]; i++) {
      data->tcp_optlen[0][i] = buffer[index];  // TCP option length: tcp_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->tcp_nopt[0]; i++) {
      for (j=0; j<data->tcp_optlen[0][i]; j++) {
        data->tcp_options[0][i][j] = buffer[index];  // TCP options data: tcp_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of TCP options.
    data->tcp_opt_totlen[0] = 0;
    for (i=0; i<data->tcp_nopt[0]; i++) {
      data->tcp_opt_totlen[0] += data->tcp_optlen[0][i];
    }

    // TCP options padding
    data->tcp_optpadlen[0] = buffer[index];  // TCP options padding: tcp_optpadlen[type] = int
    index++;
    sprintf (text, "%i", data->tcp_nopt[0]);
    textbuffer24 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview24));
    gtk_text_buffer_set_text (textbuffer24, text, -1);

    // Flag for ASCII or hexadecimal TCP data entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton17), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton17), TRUE);
    }
    // Variable data->ascii_hex_tcp4 will be changed by on_radiobutton17_toggled(), so set it now.
    data->ascii_hex_tcp4 = buffer[index];
    index++;

    // Length of TCP data
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[0] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // TCP data
    memcpy (data->payload[0], buffer + index, data->payloadlen[0] * sizeof (uint8_t));
    if (data->payloadlen[0] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry162), "Data file loaded.");
    }

    index += IP_MAXPACKET;

    // Update ethernet frame.
    create_ip4_frame (0, data);
  }

  // IPv4 ICMP
  if (flags[3]) {

    // Flag to specify ethernet header
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton17), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton17), FALSE);
    }
    // Variable data->specify_ether[1] will be changed by on_checkbutton17_toggled(), so set it now.
    data->specify_ether[1] = buffer[index];
    index++;

    // Interface name for IPv4 ICMP
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[1][i] = buffer[index];
      index++;
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry151), data->ifname[1]);

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[1] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton6), data->ifmtu[1]);
    index += 2;

    // Ethernet header for IPv4 header for ICMP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[1], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    // Destination MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[1].dst_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry141), text);
    // Source MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[1].src_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry142), text);
    // Ethernet type code
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[1].type_code));
    gtk_entry_set_text (GTK_ENTRY (data->entry143), text);
    index += ETH_HDRLEN;

    // Flag for randomizing IPv4 source address for ICMP
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton9), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton9), FALSE);
    }
    // Variable data->ran_icmp4_sourceip will be changed by on_checkbutton9_toggled(), so set it now.
    data->ran_icmp4_sourceip = buffer[index];
    index++;

    // IPv4 header for ICMP
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IP4 header struct within buffer
    memcpy (&data->ip4hdr[1], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    // IP header length
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_hl);
    gtk_entry_set_text (GTK_ENTRY (data->entry57), text);
    // Protocol version
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_v);
    gtk_entry_set_text (GTK_ENTRY (data->entry58), text);
    // Type of service
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_tos);
    gtk_entry_set_text (GTK_ENTRY (data->entry59), text);
    // Total length of datagram
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[1].ip_len));
    gtk_entry_set_text (GTK_ENTRY (data->entry60), text);
    // ID sequence number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[1].ip_id));
    gtk_entry_set_text (GTK_ENTRY (data->entry61), text);
    // Zero
    sprintf (text, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[1].ip_off) >> 15));
    gtk_entry_set_text (GTK_ENTRY (data->entry123), text);
    // Do not fragment
    sprintf (text, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[1].ip_off) >> 14) & 1u));
    gtk_entry_set_text (GTK_ENTRY (data->entry65), text);
    // More fragments following
    sprintf (text, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[1].ip_off) >> 13) & 1));
    gtk_entry_set_text (GTK_ENTRY (data->entry66), text);
    // Fragmentation offset
    sprintf (text, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[1].ip_off) & 0x1fffu));
    gtk_entry_set_text (GTK_ENTRY (data->entry67), text);
    // Time-to-Live
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_ttl);
    gtk_entry_set_text (GTK_ENTRY (data->entry68), text);
    // Transport layer protocol
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_p);
    gtk_entry_set_text (GTK_ENTRY (data->entry75), text);
    // Source IPv4 address
    if (inet_ntop (AF_INET, &(data->ip4hdr[1].ip_src), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for ICMP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry63), text);
    // Destination IPv4 address
    if (inet_ntop (AF_INET, &(data->ip4hdr[1].ip_dst), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for ICMP destination IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry64), text);

    // IPv4 header checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[1].ip_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry62), text);
    index += IP4_HDRLEN;

    // Flag for decimal or hexadecimal IP option entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton43), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton43), TRUE);
    }
    // Variable data->dec_hex_ippopt_icmp4 will be changed by on_radiobutton43_toggled(), so set it now.
    data->dec_hex_ipopt_icmp4 = buffer[index];
    index++;

    // IPv4 header options
    data->ip_nopt[1] = buffer[index];  // Number of IP options: ip_nopt[type] = int
    index++;
    for (i=0; i<data->ip_nopt[1]; i++) {
      data->ip_optlen[1][i] = buffer[index];  // IPv4 option length: ip_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->ip_nopt[1]; i++) {
      for (j=0; j<data->ip_optlen[1][i]; j++) {
        data->ip_options[1][i][j] = buffer[index];  // IPv4 options data: ip_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of IP options.
    data->ip_opt_totlen[1] = 0;
    for (i=0; i<data->ip_nopt[1]; i++) {
      data->ip_opt_totlen[1] += data->ip_optlen[1][i];
    }

    // IPv4 header options padding
    data->ip_optpadlen[1] = buffer[index];  // IPv4 options padding: ip_optpadlen[type] = int
    index++;
    sprintf (text, "%i", data->ip_nopt[1]);
    textbuffer26 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview26));
    gtk_text_buffer_set_text (textbuffer26, text, -1);

    // ICMP header
    icmp4hdr = (struct icmp *) (buffer + index);  // Cast icmp4hdr[1] as pointer to ICMP header struct within buffer
    memcpy (&data->icmp4hdr[1], icmp4hdr, ICMP_HDRLEN * sizeof (uint8_t));  // Extract ICMP header
    // Message Type
    sprintf (text, "%" PRIu8, (uint8_t) data->icmp4hdr[1].icmp_type);
    gtk_entry_set_text (GTK_ENTRY (data->entry69), text);
    // Message Code
    sprintf (text, "%" PRIu8, (uint8_t) data->icmp4hdr[1].icmp_code);
    gtk_entry_set_text (GTK_ENTRY (data->entry70), text);
    // Identifier
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[1].icmp_id));
    gtk_entry_set_text (GTK_ENTRY (data->entry72), text);
    // Sequence Number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[1].icmp_seq));
    gtk_entry_set_text (GTK_ENTRY (data->entry73), text);
    // ICMP header checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[1].icmp_cksum));
    gtk_entry_set_text (GTK_ENTRY (data->entry71), text);
    index += ICMP_HDRLEN;

    // Flag for ASCII or hexadecimal ICMP data entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton9), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton9), TRUE);
    }
    // Variable data->ascii_hex_icmp4 will be changed by on_radiobutton9_toggled(), so set it now.
    data->ascii_hex_icmp4 = buffer[index];
    index++;

    // Length of ICMP data
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[1] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // ICMP data
    memcpy (data->payload[1], buffer + index, data->payloadlen[1] * sizeof (uint8_t));
    if (data->payloadlen[1] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry126), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Update ethernet frame.
    create_ip4_frame (1, data);
  }

  // IPv4 UDP
  if (flags[4]) {

    // Flag to specify ethernet header
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton19), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton19), FALSE);
    }
    // Variable data->specify_ether[2] will be changed by on_checkbutton19_toggled(), so set it now.
    data->specify_ether[2] = buffer[index];
    index++;

    // Interface name for IPv4 UDP
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[2][i] = buffer[index];
      index++;
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry152), data->ifname[2]);

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[2] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton7), data->ifmtu[2]);
    index += 2;

    // Ethernet header for IPv4 header for UDP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[2], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    // Destination MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[2].dst_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry147), text);
    // Source MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[2].src_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry148), text);
    // Ethernet type code
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[2].type_code));
    gtk_entry_set_text (GTK_ENTRY (data->entry149), text);
    index += ETH_HDRLEN;

    // Flag for randomizing IPv4 source address for UDP
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton1), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton1), FALSE);
    }
    // Variable data->ran_udp4_sourceip will be changed by on_checkbutton1_toggled(), so set it now.
    data->ran_udp4_sourceip = buffer[index];
    index++;

    // IPv4 header for UDP
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IP4 header struct within buffer
    memcpy (&data->ip4hdr[2], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    // IP header length
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_hl);
    gtk_entry_set_text (GTK_ENTRY (data->entry1), text);
    // Protocol version
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_v);
    gtk_entry_set_text (GTK_ENTRY (data->entry2), text);
    // Type of service
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_tos);
    gtk_entry_set_text (GTK_ENTRY (data->entry3), text);
    // Total length of datagram
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[2].ip_len));
    gtk_entry_set_text (GTK_ENTRY (data->entry4), text);
    // ID sequence number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[2].ip_id));
    gtk_entry_set_text (GTK_ENTRY (data->entry5), text);
    // Zero
    sprintf (text, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[2].ip_off) >> 15));
    gtk_entry_set_text (GTK_ENTRY (data->entry124), text);
    // Do not fragment
    sprintf (text, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[2].ip_off) >> 14) & 1));
    gtk_entry_set_text (GTK_ENTRY (data->entry9), text);
    // More fragments following
    sprintf (text, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[2].ip_off) >> 13) & 1));
    gtk_entry_set_text (GTK_ENTRY (data->entry10), text);
    // Fragmentation offset
    sprintf (text, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[2].ip_off) & 0x1fffu));
    gtk_entry_set_text (GTK_ENTRY (data->entry11), text);
    // Time-to-Live
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_ttl);
    gtk_entry_set_text (GTK_ENTRY (data->entry12), text);
    // Transport layer protocol
    sprintf (text, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_p);
    gtk_entry_set_text (GTK_ENTRY (data->entry76), text);
    // Source IPv4 address
    if (inet_ntop (AF_INET, &(data->ip4hdr[2].ip_src), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for UDP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry7), text);
    // Destination IPv4 address
    if (inet_ntop (AF_INET, &(data->ip4hdr[2].ip_dst), text, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for UDP destination IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry8), text);

    // IPv4 header checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[2].ip_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry6), text);
    index += IP4_HDRLEN;

    // Flag for decimal or hexadecimal IP option entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton45), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton45), TRUE);
    }
    // Variable data->dec_hex_ipopt_udp4 will be changed by on_radiobutton45_toggled(), so set it now.
    data->dec_hex_ipopt_udp4 = buffer[index];
    index++;

    // IPv4 header options
    data->ip_nopt[2] = buffer[index];  // Number of IP options: ip_nopt[type] = int
    index++;
    for (i=0; i<data->ip_nopt[2]; i++) {
      data->ip_optlen[2][i] = buffer[index];  // IPv4 option length: ip_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->ip_nopt[2]; i++) {
      for (j=0; j<data->ip_optlen[2][i]; j++) {
        data->ip_options[2][i][j] = buffer[index];  // IPv4 options data: ip_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of IP options.
    data->ip_opt_totlen[2] = 0;
    for (i=0; i<data->ip_nopt[2]; i++) {
      data->ip_opt_totlen[2] += data->ip_optlen[2][i];
    }

    // IPv4 header options padding
    data->ip_optpadlen[2] = buffer[index];  // IPv4 options padding: ip_optpadlen[type] = int
    index++;
    sprintf (text, "%i", data->ip_nopt[2]);
    textbuffer28 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview28));
    gtk_text_buffer_set_text (textbuffer28, text, -1);

    // Flag for randomizing UDP source port
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton3), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton3), FALSE);
    }
    // Variable data->ran_udp4_sourceport will be changed by on_checkbutton3_toggled(), so set it now.
    data->ran_udp4_sourceport = buffer[index];
    index++;

    // UDP header
    udphdr = (struct udphdr *) (buffer + index);  // Cast udphdr as pointer to UDP header struct within buffer
    memcpy (&data->udphdr[2], udphdr, UDP_HDRLEN * sizeof (uint8_t));  // Extract UDP header
    // Source port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_sport));
    gtk_entry_set_text (GTK_ENTRY (data->entry13), text);
    // Destination port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_dport));
    gtk_entry_set_text (GTK_ENTRY (data->entry14), text);
    // Length of UDP datagram
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_ulen));
    gtk_entry_set_text (GTK_ENTRY (data->entry15), text);
    // UDP checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry16), text);
    index += UDP_HDRLEN;

    // Flag for ASCII or hexadecimal UDP data entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton13), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton13), TRUE);
    }
    // Variable data->ascii_hex_udp4 will be changed by on_checkbutton13_toggled(), so set it now.
    data->ascii_hex_udp4 = buffer[index];
    index++;

    // Length of UDP data
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[2] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // UDP data
    memcpy (data->payload[2], buffer + index, data->payloadlen[2] * sizeof (uint8_t));
    if (data->payloadlen[2] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry17), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Update ethernet frame.
    create_ip4_frame (2, data);
  }

  // IPv6 TCP
  if (flags[5]) {

    // Interface name for IPv6 TCP
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[3][i] = buffer[index];
      index++;
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry154), data->ifname[3]);

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[3] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton8), data->ifmtu[3]);
    index += 2;

    // Ethernet header for IPv6 header for TCP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[3], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    // Destination MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[3].dst_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry131), text);
    // Source MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[3].src_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry132), text);
    // Ethernet type code
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[3].type_code));
    gtk_entry_set_text (GTK_ENTRY (data->entry133), text);
    index += ETH_HDRLEN;

    // Flag for randomizing IPv6 source address for TCP
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton2), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton2), FALSE);
    }
    // Variable data->ran_tcp6_sourceip will be changed by on_checkbutton2_toggled(), so set it now.
    data->ran_tcp6_sourceip = buffer[index];
    index++;

    // IPv6 header for TCP
    ip6hdr = (struct ip6_hdr *) (buffer + index);  // Cast ip6hdr as pointer to IP6 header struct within buffer
    memcpy (&data->ip6hdr[3], ip6hdr, IP6_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    // IP version
    sprintf (text, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[3].ip6_flow) >> 28));
    gtk_entry_set_text (GTK_ENTRY (data->entry22), text);
    // Traffic Class
    sprintf (text, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[3].ip6_flow) >> 20) & 0xfful));
    gtk_entry_set_text (GTK_ENTRY (data->entry23), text);
    // Flow Label
    sprintf (text, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[3].ip6_flow) & 0xffffful));
    gtk_entry_set_text (GTK_ENTRY (data->entry24), text);
    // Payload length
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[3].ip6_plen));
    gtk_entry_set_text (GTK_ENTRY (data->entry25), text);
    // Next header
    sprintf (text, "%" PRIu8, (uint8_t) data->ip6hdr[3].ip6_nxt);
    gtk_entry_set_text (GTK_ENTRY (data->entry26), text);
    // Hop limit
    sprintf (text, "%" PRIu8, (uint8_t) data->ip6hdr[3].ip6_hops);
    gtk_entry_set_text (GTK_ENTRY (data->entry27), text);
    // Source IPv6 address
    if (inet_ntop (AF_INET6, &(data->ip6hdr[3].ip6_src), text, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for TCP source IPv6 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry28), text);
    // Destination IPv6 address
    if (inet_ntop (AF_INET6, &(data->ip6hdr[3].ip6_dst), text, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for TCP destination IPv6 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry78), text);
    index += IP6_HDRLEN;

    // Flag for randomizing TCP source port
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton4), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton4), FALSE);
    }
    // Variable data->ran_tcp6_sourceport will be changed by on_checkbutton4_toggled(), so set it now.
    data->ran_tcp6_sourceport = buffer[index];
    index++;

    // TCP header (IPv6)
    tcphdr = (struct tcphdr *) (buffer + index);  // Cast tcphdr as pointer to TCP header struct within buffer
    memcpy (&data->tcphdr[3], tcphdr, TCP_HDRLEN * sizeof (uint8_t));  // Extract TCP header
    // Source port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_sport));
    gtk_entry_set_text (GTK_ENTRY (data->entry79), text);
    // Destination port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_dport));
    gtk_entry_set_text (GTK_ENTRY (data->entry80), text);
    // Sequence number
    sprintf (text, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[3].th_seq));
    gtk_entry_set_text (GTK_ENTRY (data->entry81), text);
    // Acknowledgement number
    sprintf (text, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[3].th_ack));
    gtk_entry_set_text (GTK_ENTRY (data->entry82), text);
    // Reserved
    sprintf (text, "%" PRIu8, (uint8_t) data->tcphdr[3].th_x2);
    gtk_entry_set_text (GTK_ENTRY (data->entry83), text);
    // Data offset
    sprintf (text, "%" PRIu8, (uint8_t) data->tcphdr[3].th_off);
    gtk_entry_set_text (GTK_ENTRY (data->entry84), text);
    // FIN flag
    sprintf (text, "%" PRIu8, (uint8_t) data->tcphdr[3].th_flags & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry85), text);
    // SYN flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 1) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry86), text);
    // RST flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 2) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry87), text);
    // PSH flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 3) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry88), text);
    // ACK flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 4) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry89), text);
    // URG flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 5) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry90), text);
    // ECE flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 6) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry91), text);
    // CWR flag
    sprintf (text, "%" PRIu8, (uint8_t) (data->tcphdr[3].th_flags >> 7) & 1);
    gtk_entry_set_text (GTK_ENTRY (data->entry92), text);
    // Window size
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_win));
    gtk_entry_set_text (GTK_ENTRY (data->entry93), text);
    // Urgent pointer
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_urp));
    gtk_entry_set_text (GTK_ENTRY (data->entry95), text);
    // TCP checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry94), text);
    index += TCP_HDRLEN;

    // Flag for decimal or hexadecimal TCP option entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton47), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton47), TRUE);
    }
    // Variable data->dec_hex_tcpopt_tcp6 will be changed by on_radiobutton47_toggled(), so set it now.
    data->dec_hex_tcpopt_tcp6 = buffer[index];
    index++;

    // TCP header options
    data->tcp_nopt[3] = buffer[index];  // Number of TCP options: tcp_nopt[type] = int
    index++;
    for (i=0; i<data->tcp_nopt[3]; i++) {
      data->tcp_optlen[3][i] = buffer[index];  // TCP option length: tcp_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->tcp_nopt[3]; i++) {
      for (j=0; j<data->tcp_optlen[3][i]; j++) {
        data->tcp_options[3][i][j] = buffer[index];  // TCP options data: tcp_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of TCP options.
    data->tcp_opt_totlen[3] = 0;
    for (i=0; i<data->tcp_nopt[3]; i++) {
      data->tcp_opt_totlen[3] += data->tcp_optlen[3][i];
    }

    // TCP options padding
    data->tcp_optpadlen[3] = buffer[index];  // TCP options padding: tcp_optpadlen[type] = int
    index++;
    sprintf (text, "%i", data->tcp_nopt[3]);
    textbuffer32 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview32));
    gtk_text_buffer_set_text (textbuffer32, text, -1);

   // Flag for ASCII or hexadecimal TCP data entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton19), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton19), TRUE);
    }
    // Variable data->ascii_hex_tcp6 will be changed by on_checkbutton19_toggled(), so set it now.
    data->ascii_hex_tcp6 = buffer[index];
    index++;

    // Length of TCP data
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[3] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // TCP data
    memcpy (data->payload[3], buffer + index, data->payloadlen[3] * sizeof (uint8_t));
    if (data->payloadlen[3] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry163), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (3, data);
    create_6to4_frame (6, data);
}

  // IPv6 ICMP
  if (flags[6]) {

    // Interface name for IPv6 ICMP
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[4][i] = buffer[index];
      index++;
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry153), data->ifname[4]);

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[4] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton9), data->ifmtu[4]);
    index += 2;

    // Ethernet header for IPv6 header for ICMP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[4], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    // Destination MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[4].dst_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry128), text);
    // Source MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[4].src_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry129), text);
    // Ethernet type code
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[4].type_code));
    gtk_entry_set_text (GTK_ENTRY (data->entry130), text);
    index += ETH_HDRLEN;

    // Flag for randomizing IPv6 source address for ICMP
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton10), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton10), FALSE);
    }
    // Variable data->ran_icmp6_sourceip will be changed by on_checkbutton10_toggled(), so set it now.
    data->ran_icmp6_sourceip = buffer[index];
    index++;

    // IPv6 header for ICMP
    ip6hdr = (struct ip6_hdr *) (buffer + index);  // Cast ip6hdr as pointer to IP6 header struct within buffer
    memcpy (&data->ip6hdr[4], ip6hdr, IP6_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    // IP version
    sprintf (text, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[4].ip6_flow) >> 28));
    gtk_entry_set_text (GTK_ENTRY (data->entry110), text);
    // Traffic Class
    sprintf (text, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[4].ip6_flow) >> 20) & 0xfful));
    gtk_entry_set_text (GTK_ENTRY (data->entry111), text);
    // Flow Label
    sprintf (text, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[4].ip6_flow) & 0xffffful));
    gtk_entry_set_text (GTK_ENTRY (data->entry112), text);
    // Payload length
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[4].ip6_plen));
    gtk_entry_set_text (GTK_ENTRY (data->entry113), text);
    // Next header
    sprintf (text, "%" PRIu8, (uint8_t) data->ip6hdr[4].ip6_nxt);
    gtk_entry_set_text (GTK_ENTRY (data->entry114), text);
    // Hop limit
    sprintf (text, "%" PRIu8, (uint8_t) data->ip6hdr[4].ip6_hops);
    gtk_entry_set_text (GTK_ENTRY (data->entry115), text);
    // Source IPv6 address
    if (inet_ntop (AF_INET6, &(data->ip6hdr[4].ip6_src), text, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for ICMP source IPv6 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry109), text);
    // Destination IPv6 address
    if (inet_ntop (AF_INET6, &(data->ip6hdr[4].ip6_dst), text, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for ICMP destination IPv6 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry116), text);
    index += IP6_HDRLEN;

    // ICMP header
    icmp6hdr = (struct icmp6_hdr *) (buffer + index);  // Cast icmp6hdr[4] as pointer to ICMP header struct within buffer
    memcpy (&data->icmp6hdr[4], icmp6hdr, ICMP_HDRLEN * sizeof (uint8_t));  // Extract ICMP header
    // Message Type
    sprintf (text, "%" PRIu8, (uint8_t) data->icmp6hdr[4].icmp6_type);
    gtk_entry_set_text (GTK_ENTRY (data->entry117), text);
    // Message Code
    sprintf (text, "%" PRIu8, (uint8_t) data->icmp6hdr[4].icmp6_code);
    gtk_entry_set_text (GTK_ENTRY (data->entry118), text);
    // Identifier
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[4].icmp6_id));
    gtk_entry_set_text (GTK_ENTRY (data->entry120), text);
    // Sequence Number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[4].icmp6_seq));
    gtk_entry_set_text (GTK_ENTRY (data->entry121), text);
    // ICMP header checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[4].icmp6_cksum));
    gtk_entry_set_text (GTK_ENTRY (data->entry119), text);
    index += ICMP_HDRLEN;

    // Flag for ASCII or hexadecimal ICMP data entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton11), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton11), TRUE);
    }
    // Variable data->ascii_hex_icmp6 will be changed by on_checkbutton11_toggled(), so set it now.
    data->ascii_hex_icmp6 = buffer[index];
    index++;

    // Length of ICMP data
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[4] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // ICMP data
    memcpy (data->payload[4], buffer + index, data->payloadlen[4] * sizeof (uint8_t));
    if (data->payloadlen[4] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry127), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (4, data);
    create_6to4_frame (7, data);
  }

  // IPv6 UDP
  if (flags[7]) {

    // Interface name for IPv6 UDP
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[5][i] = buffer[index];
      index++;
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry155), data->ifname[5]);

    // Maximum transmission unit
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[5] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    // Update MTU spinbutton.
    gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton10), data->ifmtu[5]);
    index += 2;

    // Ethernet header for IPv6 header for UDP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[5], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    // Destination MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[5].dst_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry134), text);
    // Source MAC address
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    mac_bin2string (data->ethhdr[5].src_mac, text);
    gtk_entry_set_text (GTK_ENTRY (data->entry135), text);
    // Ethernet type code
    memset (text, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[5].type_code));
    gtk_entry_set_text (GTK_ENTRY (data->entry136), text);
    index += ETH_HDRLEN;

    // Flag for randomizing IPv6 source address for UDP
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton6), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton6), FALSE);
    }
    // Variable data->ran_udp6_sourceip will be changed by on_checkbutton6_toggled(), so set it now.
    data->ran_udp6_sourceip = buffer[index];
    index++;

    // IPv6 header for UDP
    ip6hdr = (struct ip6_hdr *) (buffer + index);  // Cast ip6hdr as pointer to IP6 header struct within buffer
    memcpy (&data->ip6hdr[5], ip6hdr, IP6_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    // IP version
    sprintf (text, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[5].ip6_flow) >> 28));
    gtk_entry_set_text (GTK_ENTRY (data->entry97), text);
    // Traffic Class
    sprintf (text, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[5].ip6_flow) >> 20) & 0xfful));
    gtk_entry_set_text (GTK_ENTRY (data->entry98), text);
    // Flow Label
    sprintf (text, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[5].ip6_flow) & 0xffffful));
    gtk_entry_set_text (GTK_ENTRY (data->entry99), text);
    // Payload length
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[5].ip6_plen));
    gtk_entry_set_text (GTK_ENTRY (data->entry100), text);
    // Next header
    sprintf (text, "%" PRIu8, (uint8_t) data->ip6hdr[5].ip6_nxt);
    gtk_entry_set_text (GTK_ENTRY (data->entry101), text);
    // Hop limit
    sprintf (text, "%" PRIu8, (uint8_t) data->ip6hdr[5].ip6_hops);
    gtk_entry_set_text (GTK_ENTRY (data->entry102), text);
    // Source IPv6 address
    if (inet_ntop (AF_INET6, &(data->ip6hdr[5].ip6_src), text, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for UDP source IPv6 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry96), text);
    // Destination IPv6 address
    if (inet_ntop (AF_INET6, &(data->ip6hdr[5].ip6_dst), text, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "load_file(): inet_ntop() failed for UDP destination IPv6 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (text);
      free (buffer);
      free (flags);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (data->entry103), text);
    index += IP6_HDRLEN;

    // Flag for randomizing UDP source port
    if (buffer[index]) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton8), TRUE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton8), FALSE);
    }
    // Variable data->ran_udp6_sourceport will be changed by on_checkbutton8_toggled(), so set it now.
    data->ran_udp6_sourceport = buffer[index];
    index++;

    // UDP header
    udphdr = (struct udphdr *) (buffer + index);  // Cast udphdr as pointer to UDP header struct within buffer
    memcpy (&data->udphdr[5], udphdr, UDP_HDRLEN * sizeof (uint8_t));  // Extract UDP header
    // Source port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_sport));
    gtk_entry_set_text (GTK_ENTRY (data->entry104), text);
    // Destination port number
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_dport));
    gtk_entry_set_text (GTK_ENTRY (data->entry105), text);
    // Length of UDP datagram
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_ulen));
    gtk_entry_set_text (GTK_ENTRY (data->entry106), text);
    // UDP checksum
    sprintf (text, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_sum));
    gtk_entry_set_text (GTK_ENTRY (data->entry107), text);
    index += UDP_HDRLEN;

    // Flag for ASCII or hexadecimal UDP data entry
    if (buffer[index] == 1) {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton15), FALSE);
    } else {
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton15), TRUE);
    }
    // Variable data->ascii_hex_udp6 will be changed by on_checkbutton15_toggled(), so set it now.
    data->ascii_hex_udp6 = buffer[index];
    index++;

    // Length of UDP data
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[5] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // UDP data
    memcpy (data->payload[5], buffer + index, data->payloadlen[5] * sizeof (uint8_t));
    if (data->payloadlen[5] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry108), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (5, data);
    create_6to4_frame (8, data);
  }

  // Traceroute

  // Traceroute Settings (sps.ui)
  if (flags[8]) {

    // Packet type for traceroute
    data->packet_type_tr = buffer[index];
    index++;

    // Number of Probes per Hop for Traceroute
    data->num_probes = buffer[index];
    index++;

    // Timeout for Reply for Traceroute
    data->timeout_tr = buffer[index];
    index++;

    // Maximum Number of Hops for Traceroute
    data->maxhops = buffer[index];
    index++;

    // Flag for resolving host names
    data->resolve_tr = buffer[index];
    index++;

    // Populate traceroute settings on Traceroute page of sps.ui.
    tr_settings_show (data);
  }

  // Traceroute IPv6 over IPv4 (6to4) (traceroute.ui, so don't update ui)
  // Note that flag for 6to4 is in Traceroute Settings above
  if (flags[9]) {

    // Flag for IPv6 over IPv4 (6to4) for Traceroute
    data->sixto4_tr_flag = buffer[index];
    index++;

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[15] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    data->ifmtu[16] = data->ifmtu[15];
    data->ifmtu[17] = data->ifmtu[15];
    index += 2;

    // Flag to use ethernet header from IPv6 TCP page for traceroute
    data->specify_ether[15] = buffer[index];
    index++;

    // 6to4 IPv4 header for TCP for traceroute
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IPv4 header struct within buffer
    memcpy (&data->ip4hdr[15], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP4_HDRLEN;

    // Flag to use ethernet header from IPv6 ICMP page for traceroute
    data->specify_ether[16] = buffer[index];
    index++;

    // 6to4 IPv4 header for ICMP for traceroute
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IPv4 header struct within buffer
    memcpy (&data->ip4hdr[16], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP4_HDRLEN;

    // Flag to use ethernet header from IPv6 UDP page for traceroute
    data->specify_ether[17] = buffer[index];
    index++;

    // 6to4 IPv4 header for UDP for traceroute
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IPv4 header struct within buffer
    memcpy (&data->ip4hdr[17], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP4_HDRLEN;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[15], &data->ip6hdr[12], IP6_HDRLEN * sizeof (uint8_t));
    memcpy (&data->ip6hdr[16], &data->ip6hdr[13], IP6_HDRLEN * sizeof (uint8_t));
    memcpy (&data->ip6hdr[17], &data->ip6hdr[14], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_6to4_frame (15, data);
    create_6to4_frame (16, data);
    create_6to4_frame (17, data);
    if (data->traceroute_flag) {
      sixto4_tr_show (data);
    }
  }

  // IPv4 TCP for traceroute
  if (flags[10]) {

    // Flag to specify ethernet header
    data->specify_ether[9] = buffer[index];
    index++;

    // Interface name for IPv4 TCP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[9][i] = buffer[index];
      index++;
    }

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[9] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // Ethernet header for IPv4 header for TCP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[9], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    index += ETH_HDRLEN;

    // IPv4 header for TCP for traceroute
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IP4 header struct within buffer
    memcpy (&data->ip4hdr[9], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP4_HDRLEN;

    // Flag for decimal or hexadecimal IP option entry
    data->dec_hex_ipopt_tcp4_tr = buffer[index];
    index++;

    // IPv4 header options
    data->ip_nopt[9] = buffer[index];  // Number of IP options: ip_nopt[type] = int
    index++;
    for (i=0; i<data->ip_nopt[9]; i++) {
      data->ip_optlen[9][i] = buffer[index];  // IPv4 option length: ip_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->ip_nopt[9]; i++) {
      for (j=0; j<data->ip_optlen[9][i]; j++) {
        data->ip_options[9][i][j] = buffer[index];  // IPv4 options data: ip_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of IP options.
    data->ip_opt_totlen[9] = 0;
    for (i=0; i<data->ip_nopt[9]; i++) {
      data->ip_opt_totlen[9] += data->ip_optlen[9][i];
    }

    // IPv4 header options padding
    data->ip_optpadlen[9] = buffer[index];  // IPv4 options padding: ip_optpadlen[type] = int
    index++;

    // Flag for randomizing TCP source port for traceroute
    data->ran_tcp4_tr_sourceport = buffer[index];
    index++;

    // TCP header for traceroute
    tcphdr = (struct tcphdr *) (buffer + index);  // Cast tcphdr as pointer to TCP header struct within buffer
    memcpy (&data->tcphdr[9], tcphdr, TCP_HDRLEN * sizeof (uint8_t));  // Extract TCP header
    index += TCP_HDRLEN;

    // Flag for decimal or hexadecimal TCP option entry
    data->dec_hex_tcpopt_tcp4_tr = buffer[index];
    index++;

    // TCP header options for traceroute
    data->tcp_nopt[9] = buffer[index];  // Number of TCP options: tcp_nopt[type] = int
    index++;
    for (i=0; i<data->tcp_nopt[9]; i++) {
      data->tcp_optlen[9][i] = buffer[index];  // TCP option length: tcp_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->tcp_nopt[9]; i++) {
      for (j=0; j<data->tcp_optlen[9][i]; j++) {
        data->tcp_options[9][i][j] = buffer[index];  // TCP options data: tcp_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of TCP options.
    data->tcp_opt_totlen[9] = 0;
    for (i=0; i<data->tcp_nopt[9]; i++) {
      data->tcp_opt_totlen[9] += data->tcp_optlen[9][i];
    }

    // TCP options padding
    data->tcp_optpadlen[9] = buffer[index];  // TCP options padding: tcp_optpadlen[type] = int
    index++;

    // Flag for ASCII or hexadecimal TCP data entry for traceroute
    data->ascii_hex_tcp4_tr = buffer[index];
    index++;

    // Length of TCP data for traceroute
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[9] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // TCP data for traceroute
    memcpy (data->payload[9], buffer + index, data->payloadlen[9] * sizeof (uint8_t));
    index += IP_MAXPACKET;

    // Update ethernet frame.
    create_ip4_frame (9, data);

    if (data->traceroute_flag) {
      tcp4_tr_show (data);
    }
  }

  // IPv4 ICMP for Traceroute
  if (flags[11]) {

    // Flag to specify ethernet header for traceroute
    data->specify_ether[10] = buffer[index];
    index++;

    // Interface name for IPv4 ICMP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[10][i] = buffer[index];
      index++;
    }

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[10] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // Ethernet header for IPv4 header for ICMP
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[10], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    index += ETH_HDRLEN;

    // IPv4 header for ICMP for traceroute
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IP4 header struct within buffer
    memcpy (&data->ip4hdr[10], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP4_HDRLEN;

    // Flag for decimal or hexadecimal IP option entry
    data->dec_hex_ipopt_icmp4_tr = buffer[index];
    index++;

    // IPv4 header options
    data->ip_nopt[10] = buffer[index];  // Number of IP options: ip_nopt[type] = int
    index++;
    for (i=0; i<data->ip_nopt[10]; i++) {
      data->ip_optlen[10][i] = buffer[index];  // IPv4 option length: ip_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->ip_nopt[10]; i++) {
      for (j=0; j<data->ip_optlen[10][i]; j++) {
        data->ip_options[10][i][j] = buffer[index];  // IPv4 options data: ip_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of IP options.
    data->ip_opt_totlen[10] = 0;
    for (i=0; i<data->ip_nopt[10]; i++) {
      data->ip_opt_totlen[10] += data->ip_optlen[10][i];
    }

    // IPv4 header options padding
    data->ip_optpadlen[10] = buffer[index];  // IPv4 options padding: ip_optpadlen[type] = int
    index++;

    // ICMP header for traceroute
    icmp4hdr = (struct icmp *) (buffer + index);  // Cast icmp4hdr[10] as pointer to ICMP header struct within buffer
    memcpy (&data->icmp4hdr[10], icmp4hdr, ICMP_HDRLEN * sizeof (uint8_t));  // Extract ICMP header
    index += ICMP_HDRLEN;

    // Flag for ASCII or hexadecimal ICMP data entry
    data->ascii_hex_icmp4_tr = buffer[index];
    index++;

    // Length of ICMP data for traceroute
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[10] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // ICMP data for traceroute
    memcpy (data->payload[10], buffer + index, data->payloadlen[10] * sizeof (uint8_t));
    if (data->payloadlen[10] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry126), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Update ethernet frame.
    create_ip4_frame (10, data);
    if (data->traceroute_flag) {
      icmp4_tr_show (data);
    }
  }

  // IPv4 UDP for Traceroute
  if (flags[12]) {

    // Flag to specify ethernet header for traceroute
    data->specify_ether[11] = buffer[index];
    index++;

    // Interface name for IPv4 UDP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[11][i] = buffer[index];
      index++;
    }

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[11] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // Ethernet header for IPv4 header for UDP for traceroute
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[11], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    index += ETH_HDRLEN;

    // IPv4 header for UDP for traceroute
    ip4hdr = (struct ip *) (buffer + index);  // Cast ip4hdr as pointer to IP4 header struct within buffer
    memcpy (&data->ip4hdr[11], ip4hdr, IP4_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP4_HDRLEN;

    // Flag for decimal or hexadecimal IP option entry
    data->dec_hex_ipopt_udp4_tr = buffer[index];
    index++;

    // IPv4 header options
    data->ip_nopt[11] = buffer[index];  // Number of IP options: ip_nopt[type] = int
    index++;
    for (i=0; i<data->ip_nopt[11]; i++) {
      data->ip_optlen[11][i] = buffer[index];  // IPv4 option length: ip_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->ip_nopt[11]; i++) {
      for (j=0; j<data->ip_optlen[11][i]; j++) {
        data->ip_options[11][i][j] = buffer[index];  // IPv4 options data: ip_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of IP options.
    data->ip_opt_totlen[11] = 0;
    for (i=0; i<data->ip_nopt[11]; i++) {
      data->ip_opt_totlen[11] += data->ip_optlen[11][i];
    }

    // IPv4 header options padding
    data->ip_optpadlen[11] = buffer[index];  // IPv4 options padding: ip_optpadlen[type] = int
    index++;

    // Flag for randomizing UDP source port for traceroute
    data->ran_udp4_tr_sourceport = buffer[index];
    index++;

    // UDP header for traceroute
    udphdr = (struct udphdr *) (buffer + index);  // Cast udphdr as pointer to UDP header struct within buffer
    memcpy (&data->udphdr[11], udphdr, UDP_HDRLEN * sizeof (uint8_t));  // Extract UDP header
    index += UDP_HDRLEN;

    // Flag for ASCII or hexadecimal UDP data entry
    data->ascii_hex_udp4_tr = buffer[index];
    index++;

    // Length of UDP data for traceroute
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[11] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // UDP data for traceroute
    memcpy (data->payload[11], buffer + index, data->payloadlen[11] * sizeof (uint8_t));
    if (data->payloadlen[11] > 0) {
      gtk_entry_set_text (GTK_ENTRY (data->entry17), "Data file loaded.");
    }
    index += IP_MAXPACKET;

    // Update ethernet frame.
    create_ip4_frame (11, data);
    if (data->traceroute_flag) {
      udp4_tr_show (data);
    }
  }

  // IPv6 TCP for Traceroute
  if (flags[13]) {

    // Interface name for IPv6 TCP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[12][i] = buffer[index];
      index++;
    }

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[12] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // Ethernet header for IPv6 header for TCP for traceroute
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[12], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    index += ETH_HDRLEN;

    // IPv6 header for TCP for traceroute
    ip6hdr = (struct ip6_hdr *) (buffer + index);  // Cast ip6hdr as pointer to IP6 header struct within buffer
    memcpy (&data->ip6hdr[12], ip6hdr, IP6_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP6_HDRLEN;

    // Flag for randomizing TCP source port for traceroute
    data->ran_tcp6_tr_sourceport = buffer[index];
    index++;

    // TCP header (IPv6) for traceroute
    tcphdr = (struct tcphdr *) (buffer + index);  // Cast tcphdr as pointer to TCP header struct within buffer
    memcpy (&data->tcphdr[12], tcphdr, TCP_HDRLEN * sizeof (uint8_t));  // Extract TCP header
    index += TCP_HDRLEN;

    // Flag for decimal or hexadecimal TCP option entry
    data->dec_hex_tcpopt_tcp6_tr = buffer[index];
    index++;

    // TCP header options
    data->tcp_nopt[12] = buffer[index];  // Number of TCP options: tcp_nopt[type] = int
    index++;
    for (i=0; i<data->tcp_nopt[12]; i++) {
      data->tcp_optlen[12][i] = buffer[index];  // TCP option length: tcp_optlen[type][option #] = int
      index++;
    }
    for (i=0; i<data->tcp_nopt[12]; i++) {
      for (j=0; j<data->tcp_optlen[12][i]; j++) {
        data->tcp_options[12][i][j] = buffer[index];  // TCP options data: tcp_options[type][option #] = uint8_t *
        index++;
      }
    }

    // Calculate total length of TCP options.
    data->tcp_opt_totlen[12] = 0;
    for (i=0; i<data->tcp_nopt[12]; i++) {
      data->tcp_opt_totlen[12] += data->tcp_optlen[12][i];
    }

    // TCP options padding
    data->tcp_optpadlen[12] = buffer[index];  // TCP options padding: tcp_optpadlen[type] = int
    index++;

   // Flag for ASCII or hexadecimal TCP data entry
    data->ascii_hex_tcp6_tr = buffer[index];
    index++;

    // Length of TCP data for traceroute
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[12] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // TCP data for traceroute
    memcpy (data->payload[12], buffer + index, data->payloadlen[12] * sizeof (uint8_t));
    index += IP_MAXPACKET;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[15], &data->ip6hdr[12], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (12, data);
    create_6to4_frame (15, data);
    if (data->traceroute_flag) {
      tcp6_tr_show (data);
    }
}

  // IPv6 ICMP for Traceroute
  if (flags[14]) {

    // Interface name for IPv6 ICMP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[13][i] = buffer[index];
      index++;
    }

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[13] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // Ethernet header for IPv6 header for ICMP for traceroute
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[13], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    index += ETH_HDRLEN;

    // IPv6 header for ICMP for traceroute
    ip6hdr = (struct ip6_hdr *) (buffer + index);  // Cast ip6hdr as pointer to IP6 header struct within buffer
    memcpy (&data->ip6hdr[13], ip6hdr, IP6_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP6_HDRLEN;

    // ICMP header for traceroute
    icmp6hdr = (struct icmp6_hdr *) (buffer + index);  // Cast icmp6hdr[4] as pointer to ICMP header struct within buffer
    memcpy (&data->icmp6hdr[13], icmp6hdr, ICMP_HDRLEN * sizeof (uint8_t));  // Extract ICMP header
    index += ICMP_HDRLEN;

    // Flag for ASCII or hexadecimal ICMP data entry
    data->ascii_hex_icmp6_tr = buffer[index];
    index++;

    // Length of ICMP data for traceroute
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[13] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // ICMP data for traceroute
    memcpy (data->payload[13], buffer + index, data->payloadlen[13] * sizeof (uint8_t));
    index += IP_MAXPACKET;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[16], &data->ip6hdr[13], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (13, data);
    create_6to4_frame (16, data);
    if (data->traceroute_flag) {
      icmp6_tr_show (data);
    }
  }

  // IPv6 UDP for Traceroute
  if (flags[15]) {

    // Interface name for IPv6 UDP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      data->ifname[14][i] = buffer[index];
      index++;
    }

    // Maximum transmission unit.
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->ifmtu[9] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // Ethernet header for IPv6 header for UDP for traceroute
    ethhdr = (struct Ethhdr *) (buffer + index);  // Cast ethhdr as pointer to ethernet header within buffer
    memcpy (&data->ethhdr[14], ethhdr, ETH_HDRLEN * sizeof (uint8_t));  // Extract ethernet header
    index += ETH_HDRLEN;

    // IPv6 header for UDP for traceroute
    ip6hdr = (struct ip6_hdr *) (buffer + index);  // Cast ip6hdr as pointer to IP6 header struct within buffer
    memcpy (&data->ip6hdr[14], ip6hdr, IP6_HDRLEN * sizeof (uint8_t));  // Extract IPv4 header
    index += IP6_HDRLEN;

    // Flag for randomizing UDP source port for traceroute
    data->ran_udp6_tr_sourceport = buffer[index];
    index++;

    // UDP header for traceroute
    udphdr = (struct udphdr *) (buffer + index);  // Cast udphdr as pointer to UDP header struct within buffer
    memcpy (&data->udphdr[14], udphdr, UDP_HDRLEN * sizeof (uint8_t));  // Extract UDP header
    index += UDP_HDRLEN;

    // Flag for ASCII or hexadecimal UDP data entry
    data->ascii_hex_udp6_tr = buffer[index];
    index++;

    // Length of UDP data for traceroute
    ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    data->payloadlen[14] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
    index += 2;

    // UDP data for traceroute
    memcpy (data->payload[14], buffer + index, data->payloadlen[14] * sizeof (uint8_t));
    index += IP_MAXPACKET;

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[17], &data->ip6hdr[14], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (14, data);
    create_6to4_frame (17, data);
    if (data->traceroute_flag) {
      udp6_tr_show (data);
    }
  }
  // EXTENSION HEADERS

  // Hop-by-hop headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating hop-by-hop header: hbh_hdr_flag[type] = int
    data->hbh_hdr_flag[ip6_type[i]] = buffer[index];
    index++;

    // Number of hop-by-hop options: hbh_nopt[type] = int
    data->hbh_nopt[ip6_type[i]] = buffer[index];
    index++;

    // Hop-by-hop header, excluding options and padding
    if (data->hbh_nopt[ip6_type[i]] > 0) {
      data->hophdr[ip6_type[i]].nxt_hdr = buffer[index];
      index++;
      data->hophdr[ip6_type[i]].hdr_len = buffer[index];
      index++;
    }

    // Hop-by-hop option length: hbh_optlen[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      data->hbh_optlen[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Hop-by-hop options data: hbh_options[type][option #] = uint8_t *
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->hbh_optlen[ip6_type[i]][j]; k++) {
        data->hbh_options[ip6_type[i]][j][k] = buffer[index];
        index++;
      }
    }

    // Calculate total length of hop-by-hop options.
    data->hbh_opt_totlen[ip6_type[i]] = 0;
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      data->hbh_opt_totlen[ip6_type[i]] += data->hbh_optlen[ip6_type[i]][j];
    }

    // Option alignment parameter x (of xN + y)
    // hbh_x[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      data->hbh_x[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Option alignment parameter y (of xN + y)
    // hbh_y[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      data->hbh_y[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Hop-by-hop header options padding length (includes alignment padding)
    // hbh_optpadlen[type] = int
    if (data->hbh_nopt[ip6_type[i]] > 0) {
      data->hbh_optpadlen[ip6_type[i]] = buffer[index];
      index++;
    }

    // Hop-by-hop header options alignment padding length
    // hbh_optleadpadlen[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      data->hbh_optleadpadlen[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Hop-by-hop options alignment padding
    // hbh_optleadpad[type][option #] = uint8_t *
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->hbh_optleadpadlen[ip6_type[i]][j]; k++) {
        data->hbh_optleadpad[ip6_type[i]][j][k] = buffer[index];
        index++;
      }
    }

    // Hop-by-hop header trailing padding length
    // hbh_opttailpadlen[type] = int
    data->hbh_opttailpadlen[ip6_type[i]] = buffer[index];
    index++;

    // Hop-by-hop header trailing padding
    // hbh_opttailpad[type] = uint8_t *
    for (j=0; j<data->hbh_opttailpadlen[ip6_type[i]]; j++) {
      data->hbh_opttailpad[ip6_type[i]][j] = buffer[index];
      index++;
    }

    if (data->hbh_nopt[ip6_type[i]] > 0) {
      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[ip6_type[i]+3], &data->ip6hdr[ip6_type[i]], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (ip6_type[i], data);
      create_6to4_frame (ip6_type[i]+3, data);
    }
  }

  // Destination headers (first)
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating destination header (first): dstf_hdr_flag[type] = int
    data->dstf_hdr_flag[ip6_type[i]] = buffer[index];
    index++;

    // Number of destination options: dstf_nopt[type] = int
    data->dstf_nopt[ip6_type[i]] = buffer[index];
    index++;

    // Destination header (first), excluding options and padding
    if (data->dstf_nopt[ip6_type[i]] > 0) {
      data->dstfhdr[ip6_type[i]].nxt_hdr = buffer[index];
      index++;
      data->dstfhdr[ip6_type[i]].hdr_len = buffer[index];
      index++;
    }

    // Destination option length: dstf_optlen[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      data->dstf_optlen[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Destination options data: dstf_options[type][option #] = uint8_t *
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstf_optlen[ip6_type[i]][j]; k++) {
        data->dstf_options[ip6_type[i]][j][k] = buffer[index];
        index++;
      }
    }

    // Calculate total length of destination options.
    data->dstf_opt_totlen[ip6_type[i]] = 0;
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      data->dstf_opt_totlen[ip6_type[i]] += data->dstf_optlen[ip6_type[i]][j];
    }

    // Option alignment parameter x (of xN + y)
    // dstf_x[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      data->dstf_x[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Option alignment parameter y (of xN + y)
    // dstf_y[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      data->dstf_y[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Destination header (first) options padding length (includes alignment padding)
    // dstf_optpadlen[type] = int
    if (data->dstf_nopt[ip6_type[i]] > 0) {
      data->dstf_optpadlen[ip6_type[i]] = buffer[index];
      index++;
    }

    // Destination header (first) options alignment padding length
    // dstf_optleadpadlen[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      data->dstf_optleadpadlen[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Destination header (first) options alignment padding
    // dstf_optleadpad[type][option #] = uint8_t *
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstf_optleadpadlen[ip6_type[i]][j]; k++) {
        data->dstf_optleadpad[ip6_type[i]][j][k] = buffer[index];
        index++;
      }
    }

    // Destination header (first) trailing padding length
    // dstf_opttailpadlen[type] = int
    data->dstf_opttailpadlen[ip6_type[i]] = buffer[index];
    index++;

    // Destination header (first) trailing padding
    // dstf_opttailpad[type] = uint8_t *
    for (j=0; j<data->dstf_opttailpadlen[ip6_type[i]]; j++) {
      data->dstf_opttailpad[ip6_type[i]][j] = buffer[index];
      index++;
    }

    if (data->dstf_nopt[ip6_type[i]] > 0) {
      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[ip6_type[i]+3], &data->ip6hdr[ip6_type[i]], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (ip6_type[i], data);
      create_6to4_frame (ip6_type[i]+3, data);
    }
  }

  // Routing headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating routing header: route_hdr_flag[type] = int
    data->route_hdr_flag[ip6_type[i]] = buffer[index];
    index++;

    if (data->route_hdr_flag[ip6_type[i]]) {

      // Routing header, excluding data: routehdr[type] = struct Route_hdr
      data->routehdr[ip6_type[i]].nxt_hdr = buffer[index];
      index++;
      data->routehdr[ip6_type[i]].hdr_len = buffer[index];
      index++;
      data->routehdr[ip6_type[i]].routing_type = buffer[index];
      index++;
      data->routehdr[ip6_type[i]].segs_left = buffer[index];
      index++;

      // Routing header data length: route_datlen[type] = int
      ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      data->route_datlen[ip6_type[i]] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
      index += 2;

      // Routing header data: route_data[type] = uint8_t *
      for (j=0; j<data->route_datlen[ip6_type[i]]; j++) {
        data->route_data[ip6_type[i]][j] = buffer[index];
        index++;
      }

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[ip6_type[i]+3], &data->ip6hdr[ip6_type[i]], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (ip6_type[i], data);
      create_6to4_frame (ip6_type[i]+3, data);
    }
  }

  // Authentication headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating authentication header: auth_hdr_flag[type] = int
    data->auth_hdr_flag[ip6_type[i]] = buffer[index];
    index++;

    if (data->auth_hdr_flag[ip6_type[i]]) {

      // Flag indicating transport or tunnel mode authentication: auth_tr_tun_flag[type] = int
      data->auth_tr_tun_flag[ip6_type[i]] = buffer[index];
      index++;

      // Authentication header: authhdr[type] = struct Auth_hdr
      data->authhdr[ip6_type[i]].nxt_hdr = buffer[index];
      index++;
      data->authhdr[ip6_type[i]].pay_len = buffer[index];
      index++;
      ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      data->authhdr[ip6_type[i]].reserved = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
      index += 2;
      ival32 = (int32_t *) (buffer + index);  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      data->authhdr[ip6_type[i]].spi = (int) ntohs (*ival32);  // Value was stored in network byte order to be consistent across platforms
      index += 4;
      ival32 = (int32_t *) (buffer + index);  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      data->authhdr[ip6_type[i]].seq = (int) ntohs (*ival32);  // Value was stored in network byte order to be consistent across platforms
      index += 4;

      // Authentication data length: auth_len[type] = int
      ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      data->auth_len[ip6_type[i]] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
      index += 2;

      // Authentication data (integrity check value (ICV)): auth_data[type] = uint8_t *
      for (j=0; j<data->auth_len[ip6_type[i]]; j++) {
        data->auth_data[ip6_type[i]][j] = buffer[index];
        index++;
      }

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[ip6_type[i]+3], &data->ip6hdr[ip6_type[i]], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (ip6_type[i], data);
      create_6to4_frame (ip6_type[i]+3, data);
    }
  }

  // ESP headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating ESP header: esp_hdr_flag[type] = int
    data->esp_hdr_flag[ip6_type[i]] = buffer[index];
    index++;

    if (data->esp_hdr_flag[ip6_type[i]]) {

      // Flag indicating ESP transport or tunnel mode: esp_tr_tun_flag[type] = int
      data->esp_tr_tun_flag[ip6_type[i]] = buffer[index];
      index++;

      // ESP header: esphdr[type] = struct esp_hdr
      ival32 = (int32_t *) (buffer + index);  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      data->esphdr[ip6_type[i]].spi = (int) ntohs (*ival32);  // Value was stored in network byte order to be consistent across platforms
      index += 4;
      ival32 = (int32_t *) (buffer + index);  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      data->esphdr[ip6_type[i]].seq = (int) ntohs (*ival32);  // Value was stored in network byte order to be consistent across platforms
      index += 4;

      // ESP tail: esptail[type] = struct Esp_tail
      data->esptail[ip6_type[i]].pad_len = buffer[index];
      index++;
      data->esptail[ip6_type[i]].nxt_hdr = buffer[index];
      index++;

      // ESP payload padding: esp_pad[type] = uint8_t *
      for (j=0; j<data->esptail[ip6_type[i]].pad_len; j++) {
        data->esp_pad[ip6_type[i]][j] = buffer[index];
        index++;
      }

      // ESP authentication header data length: esp_auth_len[type] = int
      ival16 = (int16_t *) (buffer + index);  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      data->esp_auth_len[ip6_type[i]] = (int) ntohs (*ival16);  // Value was stored in network byte order to be consistent across platforms
      index += 2;

      // ESP authentication data (integrity check value (ICV)): esp_auth_data[type] = uint8_t *
      for (j=0; j<data->esp_auth_len[ip6_type[i]]; j++) {
        data->esp_auth_data[ip6_type[i]][j] = buffer[index];
        index++;
      }
    }
  }

  // Destination headers (last)
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating destination header (last): dstl_hdr_flag[type] = int
    data->dstl_hdr_flag[ip6_type[i]] = buffer[index];
    index++;

    // Number of destination options: dstl_nopt[type] = int
    data->dstl_nopt[ip6_type[i]] = buffer[index];
    index++;

    // Destination header (last), excluding options and padding
    if (data->dstl_nopt[ip6_type[i]] > 0) {
      data->dstlhdr[ip6_type[i]].nxt_hdr = buffer[index];
      index++;
      data->dstlhdr[ip6_type[i]].hdr_len = buffer[index];
      index++;
    }

    // Destination option length: dstl_optlen[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      data->dstl_optlen[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Destination options data: dstl_options[type][option #] = uint8_t *
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstl_optlen[ip6_type[i]][j]; k++) {
        data->dstl_options[ip6_type[i]][j][k] = buffer[index];
        index++;
      }
    }

    // Calculate total length of destination options.
    data->dstl_opt_totlen[ip6_type[i]] = 0;
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      data->dstl_opt_totlen[ip6_type[i]] += data->dstl_optlen[ip6_type[i]][j];
    }

    // Option alignment parameter x (of xN + y)
    // dstl_x[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      data->dstl_x[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Option alignment parameter y (of xN + y)
    // dstl_y[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      data->dstl_y[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Destination header (last) options padding length (includes alignment padding)
    // dstl_optpadlen[type] = int
    if (data->dstl_nopt[ip6_type[i]] > 0) {
      data->dstl_optpadlen[ip6_type[i]] = buffer[index];
      index++;
    }

    // Destination header (last) options alignment padding length
    // dstl_optleadpadlen[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      data->dstl_optleadpadlen[ip6_type[i]][j] = buffer[index];
      index++;
    }

    // Destination header (last) options alignment padding
    // dstl_optleadpad[type][option #] = uint8_t *
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstl_optleadpadlen[ip6_type[i]][j]; k++) {
        data->dstl_optleadpad[ip6_type[i]][j][k] = buffer[index];
        index++;
      }
    }

    // Destination header (last) trailing padding length
    // dstl_opttailpadlen[type] = int
    data->dstl_opttailpadlen[ip6_type[i]] = buffer[index];
    index++;

    // Destination header (last) trailing padding
    // dstl_opttailpad[type] = uint8_t *
    for (j=0; j<data->dstl_opttailpadlen[ip6_type[i]]; j++) {
      data->dstl_opttailpad[ip6_type[i]][j] = buffer[index];
      index++;
    }

    if (data->dstl_nopt[ip6_type[i]] > 0) {
      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[ip6_type[i]+3], &data->ip6hdr[ip6_type[i]], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (ip6_type[i], data);
      create_6to4_frame (ip6_type[i]+3, data);
    }
  }

  // Free allocated memory.
  free (text);
  free (buffer);
  free (flags);

  return (EXIT_SUCCESS);
}
