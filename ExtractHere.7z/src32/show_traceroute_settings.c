/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Populate traceroute settings on Traceroute page of sps.ui.
// Doesn't need traceroute window open since this is sps.ui.
int
tr_settings_show (SPSData *data)
{
  int temp;

  // Probe protocol type
  switch (data->packet_type_tr) {

    // IPv4 TCP
    case 9:
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton21), TRUE);
      break;

    // IPv4 ICMP
    case 10:
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton22), TRUE);
      break;

    // IPv4 UDP
    case 11:
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton23), TRUE);
      break;

    // IPv6 TCP
    case 12:
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton26), TRUE);
      break;

    // IPv6 ICMP
    case 13:
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton27), TRUE);
      break;

    // IPv6 UDP
    case 14:
      gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton28), TRUE);
      break;

    default:
      fprintf (stderr, "ERROR: Invalid packet type %i in tr_settings_show().\n", data->packet_type_tr);
      exit (EXIT_FAILURE);
  }

  // Number of Probes per Hop
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton2), data->num_probes);

  // Timeout for Reply (seconds)
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton4), data->timeout_tr);

  // Maximum Number of Hops
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton3), data->maxhops);

  // Flag for resolving hostnames of nodes during traceroute.
  temp = data->resolve_tr;  // Save value of flag
  if (data->resolve_tr) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton28), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton28), FALSE);
  }
  // Variable will be changed by on_checkbutton28_toggled(), so set it now.
  data->resolve_tr = temp;

  return (EXIT_SUCCESS);
}
