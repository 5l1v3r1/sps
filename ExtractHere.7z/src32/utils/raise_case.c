/*  raise_case.c - a tool to convert a file to include only upper case UTF-8 letters
    Output is file "out". Input file is not modified.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// Compile with gcc -Wall raise_case.c -o raise_case

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

#define UTF8_FILENAME "UTF-8.csv"
#define SMALL 0
#define CAPITAL 1

uint8_t ***utf8;  // utf8[record][SMALL/CAP] = uint8_t * of size 6
int nutf8;

// Function prototypes
int raise_case (uint8_t *, int, uint8_t *);
int is_valid_utf8 (uint8_t *, int);
int is_lower_utf8_letter (uint8_t *);
int find_val (uint8_t *, int *);
uint8_t *utf8_value (uint8_t *, uint8_t *);
int one_byte (int, int, uint8_t *);
int two_byte (int, int, uint8_t *);
int three_byte (int, int, uint8_t *);
int four_byte (int, int, uint8_t *);
int five_byte (int, int, uint8_t *);
int six_byte (int, int, uint8_t *);
int compare (uint8_t *, int, uint8_t *, int);
int load_utf8 (void);
char *allocate_strmem (int);
uint8_t *allocate_ustrmem (int);
uint8_t **allocate_ustrmemp (int);
uint8_t ***allocate_ustrmempp (int);

int
main (int argc, char **argv)
{
  int i, n, nbytes;
  char *filename;
  uint8_t *data, *temp;
  FILE *fi, *fo;

  // Allocate memory for various arrays.
  filename = allocate_strmem (1024);

  if (argc == 2) {
    strncpy (filename, argv[1], 1024);
  } else {
    fprintf (stderr, "Usage: raise_case filename\n");
    exit (EXIT_SUCCESS);
  }

  // Load small-capital UTF-8 cross-reference file.
  if (load_utf8 () != EXIT_SUCCESS) {
    exit (EXIT_FAILURE);
  }

  // Open input file.
  fi = fopen (filename, "r");
  if (fi == NULL) {
    fprintf (stderr, "ERROR: Cannot open input file \"%s\".\n", filename);
    exit (EXIT_FAILURE);
  }

  // Load bytes of input file into array data.
  if (fgetc (fi) == EOF) {
    fprintf (stderr, "ERROR: Input file \"%s\" is empty.\n", filename);
    exit (EXIT_FAILURE);
  } else {
    rewind (fi);
    nbytes = 0;
    while ((n = fgetc (fi)) != EOF) {
      nbytes++;
    }
    rewind (fi);
  }

  // Allocate memory for various arrays.
  data = allocate_ustrmem (nbytes);
  for (i=0; i<nbytes; i++) {
    data[i] = (uint8_t) fgetc (fi);
  }
  temp = allocate_ustrmem (nbytes);  // Will be same size since upper and lower case use same number of bytes.

  // Close file descriptor.
  fclose (fi);

  // Check for invalid UTF-8 characters.
  if (!is_valid_utf8 (data, nbytes)) {
    exit (EXIT_FAILURE);
  }

  // Convert any lower case UTF-8 letters to upper case.
  if (raise_case (data, nbytes, temp) == EXIT_FAILURE) {
    fprintf (stderr, "ERROR: raise_case() found invalid UTF-8 character.\n");
    exit (EXIT_FAILURE);
  }

  // Open output file.
  fo = fopen ("out", "w");
  if (fo == NULL) {
    fprintf (stderr, "ERROR: Cannot open output file \"out\" \n");
    exit (EXIT_FAILURE);
  }

  // Write data.
  for (i=0; i<nbytes; i++) {
    fputc (temp[i], fo);
  }
  fclose (fo);

  // Free allocated memory.
  free (filename);
  free (data);
  free (temp);

  return (EXIT_SUCCESS);
}

// Examine an array and report any non-UTF-8 characters.
int
is_valid_utf8 (uint8_t *testdata, int nbytes)
{
  int i, j;

  i = 0;
  while (i < nbytes) {
    if (one_byte (nbytes, i, testdata)) {
      i++;
    } else if (two_byte (nbytes, i, testdata)) {
      i += 2;
    } else if (three_byte (nbytes, i, testdata)) {
      i += 3;
    } else if (four_byte (nbytes, i, testdata)) {
      i += 4;
    } else if (five_byte (nbytes, i, testdata)) {
      i += 5;
    } else if (six_byte (nbytes, i, testdata)) {
      i += 6;
    } else {
      fprintf (stderr, "ERROR: Non-UTF-8 character appears at byte %08x\n", i);
      fprintf (stderr, "Here are 40 characters starting with problem character (ignore quotes): \"");
      if ((nbytes - (i+1)) >= 40) {
        for (j=i; j<(i+40); j++) {
           fprintf (stderr, "%c", testdata[j]);
        }
      } else {
        for (j=i; j<nbytes; j++) {
           fprintf (stderr, "%c", testdata[j]);
        }
      }
      fprintf (stderr, "\"\n");
      return (0);
    }
  }  // End while i < nbytes

  return (1);  // Success: data contains no invalid UTF-8 characters.
}

// Convert any lower case UTF-8 characters to upper case.
int
raise_case (uint8_t *input_string, int len_in, uint8_t *output_string)
{
  int i, j, len, ZERO;
  uint8_t *lower_val, *upper_val;

  ZERO = 0;

  // Allocate memory for various arrays.
  lower_val = allocate_ustrmem (6);
  upper_val = allocate_ustrmem (6);

  i = 0;  // Index of input character array
  j = 0;  // Index of output character array
  while (i < len_in) {
    memset (upper_val, 0, 6 * sizeof (uint8_t));
    memset (lower_val, 0, 6 * sizeof (uint8_t));
    if (one_byte (len_in, i, input_string)) {
      len = 1;
    } else if (two_byte (len_in, i, input_string)) {
      len = 2;
    } else if (three_byte (len_in, i, input_string)) {
      len = 3;
    } else if (four_byte (len_in, i, input_string)) {
      len = 4;
    } else if (five_byte (len_in, i, input_string)) {
      len = 5;
    } else if (six_byte (len_in, i, input_string)) {
      len = 6;
    } else {
      fprintf (stderr, "ERROR: raise_case(): Found an valid UTF-8 character.\n");
      return (EXIT_FAILURE);
    }
    memcpy (lower_val, input_string + i, len * sizeof (uint8_t));
    if (is_lower_utf8_letter (lower_val) > 0) {
      memcpy (upper_val, utf8[find_val (lower_val, &ZERO)][CAPITAL], len * sizeof (uint8_t));
      memcpy (output_string + j, upper_val, len * sizeof (uint8_t));
    } else {
      memcpy (output_string + j, input_string + i, len * sizeof (uint8_t));
    }
    i += len;
    j += len;
  }

  // Free allocated memory.
  free (lower_val);
  free (upper_val);

  return (EXIT_SUCCESS);
}

// Determine if character is lower case UTF-8 letter.
// Return 1 if it is lower case letter, 0 if it is upper case letter, -1 if neither.
int
is_lower_utf8_letter (uint8_t *value)
{
  int zero, one;

  zero = 0;
  one = 1;

  // Lower case letter
  if (find_val (value, &zero) > -1) {
    return (1);  // It's a lower case character.

  // Upper case letter
  } else if (find_val (value, &one) > -1) {
    return (0);  // It's an upper case character.

  // Neither upper nor lower case letter.
  } else {
    return (-1);  // Must be some non-letter symbol.
  }
}

int
find_val (uint8_t *value, int *char_case)
{
  int i, found;
  uint8_t *value2;

  // Allocate memory for various arrays.
  value2 = allocate_ustrmem (6);

  found = 0;

  // Search lower case character list.
  if (!(*char_case)) {

    for (i=0; i<nutf8; i++) {
      if (compare (value, 6, utf8[i][SMALL], 6) == 0) {
        found = 1;
        break;
      }
    }

  // Search upper case character list.
  } else if (*char_case) {
    for (i=0; i<nutf8; i++) {
      if (compare (value, 6, utf8[i][CAPITAL], 6) == 0) {
        found = 1;
        break;
      }
    }
  }

  // Free allocated memory.
  free (value2);

  if (!found) {
    return (-1);  // Couldn't find a match.
  }

  return (i);
}

uint8_t *
utf8_value (uint8_t *result, uint8_t *field)
{
  int i, j, k, len, nvals;
  char **endptr;
  uint8_t *temp;

  len = strlen ((char *) field);
  temp = allocate_ustrmem (3);

  // Count number of hexadecimal values are in the field.
  nvals = 0;
  i = 0;
  while (i < len) {
    while ((field[i] != ' ') && (field[i] != 0) && (i < len)) {
      i++;
    }
    nvals++;
    i++;
  }

  // Convert ASCII hex values to uint8_t array.
  memset (result, 0, 6 * sizeof (uint8_t));
  j = 0;  // Index of field
  k = 0;  // Index of result
  for (i=0; i<nvals; i++) {
    memset (temp, 0, 3 * sizeof (uint8_t));
    memcpy (temp, field + j, 2 * sizeof (uint8_t));
    j += 3;

    // Convert to base-10.
    endptr = NULL;
    result[k] = (uint8_t) strtol ((char *) temp, endptr, 16);
    if (endptr != NULL) {
      fprintf (stderr, "strtol() failed in value().\n");
      exit (EXIT_FAILURE);
    }
    k++;
  }

  // Free allocated memory.
  free (temp);

  return (result);
}

// Check for 1-byte UTF-8 character
int
one_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if (i >= nbytes) {
    return (0);  // Not a valid 1-byte UTF-8 character
  }

  if (data[i] >> 7) {
    return (0);  // Not a valid 1-byte UTF-8 character
  }

  return (1);  // Is a valid 1-byte UTF-8 character
}

// Check for 2-byte UTF-8 character
int
two_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 1) >= nbytes) {
    return (0);  // Not a valid 2-byte UTF-8 character
  }

  if ((data[i] >> 5) == 0x6) {  // 0x6 = 110b
    if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
      return (1);
    }
  }

  return (0);  // Not a valid 2-byte UTF-8 character
}

// Check for 3-byte UTF-8 character
int
three_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 2) >= nbytes) {
    return (0);  // Not a valid 3-byte UTF-8 character
  }
    
 if ((data[i] >> 4) == 0xe) {  // 0xe = 1110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       return (1); 
     }
   }
 }
  
  return (0);  // Not a valid 3-byte UTF-8 character
}

// Check for 4-byte UTF-8 character
int
four_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 3) >= nbytes) {
    return (0);  // Not a valid 4-byte UTF-8 character
  }
    
 if ((data[i] >> 3) == 0x1e) {  // 0x1e = 11110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // ox2 = 10b
         return (1);
       }
     }
   }
 }

  return (0);  // Not a valid 4-byte UTF-8 character
}

// Check for 5-byte UTF-8 character
int
five_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 4) >= nbytes) {
    return (0);  // Not a valid 5-byte UTF-8 character
  }
    
 if ((data[i] >> 2) == 0x3e) {  // 0x3e = 111110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // 0x2 = 10b
         if ((data[i+4] >> 6) == 0x2) {  // 0x2 = 10b
           return (1);
         }
       }
     }
   }
 }

  return (0);  // Not a valid 5-byte UTF-8 character
}

// Check for 6-byte UTF-8 character
int
six_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 5) >= nbytes) {
    return (0);  // Not a valid 6-byte UTF-8 character
  }
    
 if ((data[i] >> 1) == 0x7e) {  // 0x7e = 1111110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // 0x2 = 10b
         if ((data[i+4] >> 6) == 0x2) {  // 0x2 = 10b
           if ((data[i+5] >> 6) == 0x2) {  // 0x2 = 10b
             return (1);
           }
         }
       }
     }
   }
 }  
    
  return (0);  // Not a valid 6-byte UTF-8 character
}

// Compare two uint8_t strings. Return -1 is different, 0 if same.
// Strings will be compared out to len1 and len2, and no less.
int
compare (uint8_t *string1, int len1, uint8_t *string2, int len2)
{
  int i;

  if (len1 != len2) {
    return (-1);
  } else {
    for (i=0; i<len1; i++) {  // Use len1 or len2 since they must be equal at this point.
      if (string1[i] != string2[i]) {
        return (-1);
      }
    }
  }
  return (0);
}

// Load small-capital UTF-8 cross-reference file into array utf_xref.
// uint8_t ***utf8;  // utf8[record][SMALL/CAP] = uint8_t * of size 6
// int nutf8 = number of lines (characters) in file UTF8_FILENAME
int
load_utf8 (void)
{
  int i, j, k, n;
  uint8_t *temp;
  FILE *fi;

  // Allocate memory for various arrays.
  temp = allocate_ustrmem (1024);

  // Open small-capital UTF-8 cross-reference file.
  fi = fopen (UTF8_FILENAME, "rb");
  if (fi == NULL) {
    free (temp);
    return (EXIT_FAILURE);
  }

  // Count all lines in input file.
  if (fgetc (fi) == EOF) {
    fprintf (stderr, "ERROR: Small-capital UTF-8 cross-reference file %s is empty.\n", UTF8_FILENAME);
    free (temp);
    return (EXIT_FAILURE);
  } else {
    rewind (fi);
    nutf8 = 0;
    while (fgets ((char *) temp, 1024, fi) != NULL) {
      nutf8++;
    }
    rewind (fi);
  }

  // Allocate memory for lines of input file
  utf8 = allocate_ustrmempp (nutf8);
  for (i=0; i<nutf8; i++) {
    utf8[i] = allocate_ustrmemp (2);
    for (j=0; j<2; j++) {
      utf8[i][j] = allocate_ustrmem (6);  // Maximum length of UTF-8 character is 6 bytes.
    }
  }

  // Read input file into a character array
  k = 0;  // Index of array utf8
  for (i=0; i<nutf8; i++) {
    memset (temp, 0, 1024 * sizeof (uint8_t));
    j = 0;
    while ((n = fgetc (fi)) != ',') {
      if (n == EOF) break;
      temp[j] = (uint8_t) n;
      j++;
    }
    while ((n = fgetc (fi)) != '\n') {
      if (n == EOF) break;
    }
    utf8_value (utf8[k][i % 2], temp);  // Lower case if (i % 2) = 0, Upper case if (i % 2) = 1
    if (i % 2) k++;
  }

  // Close file descriptor.
  fclose (fi);

  // Free allocated memory.
  free (temp);

  return (EXIT_SUCCESS);
}

// Allocate memory for an array of chars.
char *
allocate_strmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_strmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (char *) malloc (len * sizeof (char));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (char));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_strmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of unsigned chars.
uint8_t *
allocate_ustrmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t *) malloc (len * sizeof (uint8_t));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of unsigned chars.
uint8_t **
allocate_ustrmemp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmemp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t **) malloc (len * sizeof (uint8_t *));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t *));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmemp().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of pointers to arrays of unsigned chars.
uint8_t ***
allocate_ustrmempp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmempp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t ***) malloc (len * sizeof (uint8_t **));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t **));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmempp().\n");
    exit (EXIT_FAILURE);
  }
}
