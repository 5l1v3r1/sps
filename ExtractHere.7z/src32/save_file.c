/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int flood_mode;  // Flood flag - indicates a flood is selected with flood checkbutton

// Save SPS file, which contains settings selected by user.
int
save_file (SPSData *data)
{
  int i, j, k, buffer_size;
  int result;
  int ip6_type[6]={3,4,5,12,13,14};
  int16_t *ival16;
  int32_t *ival32;
  GtkWidget *dialog;
  char *filename, *text;
  uint8_t *buffer;
  FILE *fo;

  // Size of buffer
  buffer_size = 400000;

  // Array for error messages.
  text = allocate_strmem (TEXT_STRINGLEN);

  // Array of unsigned chars
  buffer = allocate_ustrmem (buffer_size);

  // Check to make sure the user selected something to save.
  j = 0;  // Initially assume no items to save.
  for (i=0; i<data->save_nitems; i++) {
    if (data->save_flags[i]) {
      j = 1;
      break;
    }
  }
  if (!j) {
    sprintf (data->error_text, "Nothing was selected for saving.");
    data->parent = data->main_window;
    report_error (data);
    free (text);
    free (buffer);
    return (EXIT_FAILURE);
  }

  // Create filechooser dialog.
  dialog = gtk_file_chooser_dialog_new ("Save File ...", (GtkWindow *) data->main_window, GTK_FILE_CHOOSER_ACTION_SAVE,
             GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,GTK_STOCK_SAVE, GTK_RESPONSE_ACCEPT, NULL);
  gtk_file_chooser_set_do_overwrite_confirmation (GTK_FILE_CHOOSER (dialog), TRUE);

  // Run the filechooser dialog.
  result = gtk_dialog_run (GTK_DIALOG (dialog));

  // Interpret result returned from filechooser dialog.
  if (result == GTK_RESPONSE_ACCEPT)
  {
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    gtk_widget_destroy (dialog);
  } else {
    free (text);
    free (buffer);
    gtk_widget_destroy (dialog);
    return (EXIT_SUCCESS);
  }

  // Open output file.
  if ((fo = fopen (filename, "wb")) == NULL) {
    sprintf (data->error_text, "save_file(): fopen() failed to open an output file.");
    data->parent = data->main_window;
    report_error (data);
    free (text);
    free (buffer);
    return (EXIT_FAILURE);
  }

  // SPS file identification
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  strncpy (text, "Simple Packet Sender", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
  for (i=0; i<80; i++) {
    fputc ((uint8_t) text[i], fo);
  }

  // Save the "save flag" values.
  for (i=0; i<256; i++) {
    fputc (data->save_flags[i], fo);
  }

  // Send Packet Settings
  if (data->save_flags[0]) {

    fputc (data->packet_type, fo);  // Packet type(s) to send

    // Number of packets
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival32 = (int32_t *) buffer;  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
    *ival32 = htonl ((int32_t ) data->npackets);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);
    fputc (buffer[2], fo);
    fputc (buffer[3], fo);

    fputc ((uint8_t) flood_mode, fo);  // Flag for flood mode
  }

  // IPv6 over IPv4 (6to4)
  if (data->save_flags[1]) {

    fputc (data->sixto4_flag, fo);  // Flag to use 6to4

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[6]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    fputc (data->specify_ether[6], fo);  // Flag to use ethernet header from IPv6 TCP page

    fputc (data->ran_tcp6to4_sourceip, fo);  // Flag for randomizing IPv4 source address for TCP over 6to4

    // 6to4 IPv4 header for TCP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[6], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    fputc (data->specify_ether[7], fo);  // Flag to use ethernet header from IPv6 ICMP page

    fputc (data->ran_icmp6to4_sourceip, fo);  // Flag for randomizing IPv4 source address for ICMP over 6to4

    // 6to4 IPv4 header for ICMP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[7], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    fputc (data->specify_ether[8], fo);  // Flag to use ethernet header from IPv6 UDP page

    fputc (data->ran_udp6to4_sourceip, fo);  // Flag for randomizing IPv4 source address for UDP over 6to4

    // 6to4 IPv4 header for UDP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[8], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv4 TCP
  if (data->save_flags[2]) {

    fputc (data->specify_ether[0], fo);  // Flag to specify ethernet header

    // Interface name for IPv4 TCP
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[0][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[0]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv4 header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[0], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing IPv4 source address
    fputc (data->ran_tcp4_sourceip, fo);

    // IPv4 header for TCP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[0], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal IP option entry
    fputc (data->dec_hex_ipopt_tcp4, fo);

    // IPv4 header options and padding
    fputc (data->ip_nopt[0], fo);  // Number of IP options: ip_nopt[type] = int
    for (i=0; i<data->ip_nopt[0]; i++) {
      fputc (data->ip_optlen[0][i], fo);  // IPv4 option length: ip_optlen[type][option #] = int
    }
    for (i=0; i<data->ip_nopt[0]; i++) {
      for (j=0; j<data->ip_optlen[0][i]; j++) {
        fputc (data->ip_options[0][i][j], fo);  // IPv4 options data: ip_options[type][option #] = uint8_t *
      }
    }
    fputc (data->ip_optpadlen[0], fo);  // IPv4 options padding length: ip_optpadlen[type] = int

    // Flag for randomizing TCP source port
    fputc (data->ran_tcp4_sourceport, fo);

    // TCP header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->tcphdr[0], TCP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<TCP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal TCP option entry
    fputc (data->dec_hex_tcpopt_tcp4, fo);

    // TCP header options and padding
    fputc (data->tcp_nopt[0], fo);  // Number of TCP options: tcp_nopt[type] = int
    for (i=0; i<data->tcp_nopt[0]; i++) {
      fputc (data->tcp_optlen[0][i], fo);  // TCP option length: tcp_optlen[type][option #] = int
    }
    for (i=0; i<data->tcp_nopt[0]; i++) {
      for (j=0; j<data->tcp_optlen[0][i]; j++) {
        fputc (data->tcp_options[0][i][j], fo);  // TCP options data: tcp_options[type][option #] = uint8_t *
      }
    }
    fputc (data->tcp_optpadlen[0], fo);  // TCP options padding length: tcp_optpadlen[type] = int

    // Flag for ASCII or hexadecimal TCP data entry
    fputc (data->ascii_hex_tcp4, fo);

    // Length of TCP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[0]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // TCP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[0], data->payloadlen[0] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv4 ICMP
  if (data->save_flags[3]) {

    fputc (data->specify_ether[1], fo);  // Flag to specify ethernet header

    // Interface name for IPv4 ICMP
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[1][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[1]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv4 header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[1], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing IPv4 source address
    fputc (data->ran_icmp4_sourceip, fo);

    // IPv4 header for ICMP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[1], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal IP option entry
    fputc (data->dec_hex_ipopt_icmp4, fo);

    // IPv4 header options and padding
    fputc (data->ip_nopt[1], fo);  // Number of IP options: ip_nopt[type] = int
    for (i=0; i<data->ip_nopt[1]; i++) {
      fputc (data->ip_optlen[1][i], fo);  // IPv4 option length: ip_optlen[type][option #] = int
    }
    for (i=0; i<data->ip_nopt[1]; i++) {
      for (j=0; j<data->ip_optlen[1][i]; j++) {
        fputc (data->ip_options[1][i][j], fo);  // IPv4 options data: ip_options[type][option #] = uint8_t *
      }
    }
    fputc (data->ip_optpadlen[1], fo);  // IPv4 options padding length: ip_optpadlen[type] = int

    // ICMP header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->icmp4hdr[1], ICMP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ICMP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal ICMP data entry
    fputc (data->ascii_hex_icmp4, fo);

    // Length of ICMP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[1]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // ICMP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[1], data->payloadlen[1] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv4 UDP
  if (data->save_flags[4]) {

    fputc (data->specify_ether[2], fo);  // Flag to specify ethernet header

    // Interface name for IPv4 UDP
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[2][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[2]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv4 header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[2], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing IPv4 source address
    fputc (data->ran_udp4_sourceip, fo);

    // IPv4 header for UDP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[2], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal IP option entry
    fputc (data->dec_hex_ipopt_udp4, fo);

    // IPv4 header options and padding
    fputc (data->ip_nopt[2], fo);  // Number of IP options: ip_nopt[type] = int
    for (i=0; i<data->ip_nopt[2]; i++) {
      fputc (data->ip_optlen[2][i], fo);  // IPv4 option length: ip_optlen[type][option #] = int
    }
    for (i=0; i<data->ip_nopt[2]; i++) {
      for (j=0; j<data->ip_optlen[2][i]; j++) {
        fputc (data->ip_options[2][i][j], fo);  // IPv4 options data: ip_options[type][option #] = uint8_t *
      }
    }
    fputc (data->ip_optpadlen[2], fo);  // IPv4 options padding length: ip_optpadlen[type] = int

    // Flag for randomizing UDP source port
    fputc (data->ran_udp4_sourceport, fo);

    // UDP header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->udphdr[2], UDP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<UDP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal UDP data entry
    fputc (data->ascii_hex_udp4, fo);

    // Length of UDP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[2]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // UDP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[2], data->payloadlen[2] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv6 TCP
  if (data->save_flags[5]) {

    // Interface name for IPv6 TCP
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[3][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[3]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv6 header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[3], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing IPv6 source address
    fputc (data->ran_tcp6_sourceip, fo);

    // IPv6 header for TCP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing TCP source port
    fputc (data->ran_tcp6_sourceport, fo);

    // TCP header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->tcphdr[3], TCP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<TCP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal TCP option entry
    fputc (data->dec_hex_tcpopt_tcp6, fo);

    // TCP header options and padding
    fputc (data->tcp_nopt[3], fo);  // Number of TCP options: tcp_nopt[type] = int
    for (i=0; i<data->tcp_nopt[3]; i++) {
      fputc (data->tcp_optlen[3][i], fo);  // TCP option length: tcp_optlen[type][option #] = int
    }
    for (i=0; i<data->tcp_nopt[3]; i++) {
      for (j=0; j<data->tcp_optlen[3][i]; j++) {
        fputc (data->tcp_options[3][i][j], fo);  // TCP options data: tcp_options[type][option #] = uint8_t *
      }
    }
    fputc (data->tcp_optpadlen[3], fo);  // TCP options padding length: tcp_optpadlen[type] = int

    // Flag for ASCII or hexadecimal TCP data entry
    fputc (data->ascii_hex_tcp6, fo);

    // Length of TCP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[3]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // TCP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[3], data->payloadlen[3] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv6 ICMP
  if (data->save_flags[6]) {

    // Interface name for IPv6 ICMP
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[4][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[4]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv6 header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[4], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing IPv6 source address
    fputc (data->ran_icmp6_sourceip, fo);

    // IPv6 header for ICMP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // ICMP header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->icmp6hdr[4], ICMP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ICMP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal ICMP data entry
    fputc (data->ascii_hex_icmp6, fo);

    // Length of ICMP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[4]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // ICMP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[4], data->payloadlen[4] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv6 UDP
  if (data->save_flags[7]) {

    // Interface name for IPv6 UDP
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[5][i], fo);
    }

    // Maximum transmission unit (MTU)
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[5]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv6 header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[5], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing IPv6 source address
    fputc (data->ran_udp6_sourceip, fo);

    // IPv6 header for UDP
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing UDP source port
    fputc (data->ran_udp6_sourceport, fo);

    // UDP header
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->udphdr[5], UDP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<UDP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal UDP data entry
    fputc (data->ascii_hex_udp6, fo);

    // Length of UDP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[5]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // UDP data
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[5], data->payloadlen[5] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // Traceroute settings
  if (data->save_flags[8]) {

    fputc (data->packet_type_tr, fo);  // Packet type for traceroute
    fputc (data->num_probes, fo);  // Number of probes per hop
    fputc (data->timeout_tr, fo);  // Timeout for reply
    fputc (data->maxhops, fo);  // Maximum number of hops
    fputc (data->resolve_tr, fo);  // Resolve hostnames of hops
  }

  // IPv6 over IPv4 (6to4) information for traceroute
  if (data->save_flags[9]) {

    fputc (data->sixto4_tr_flag, fo);  // Flag to use 6to4

    // Maximum  transmission unit (MTU)
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[15]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    fputc (data->specify_ether[15], fo);  // Flag to use ethernet header from IPv6 TCP traceroute page

    // 6to4 IPv4 header for TCP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[15], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    fputc (data->specify_ether[16], fo);  // Flag to use ethernet header from IPv6 ICMP traceroute page

    // 6to4 IPv4 header for ICMP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[16], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    fputc (data->specify_ether[17], fo);  // Flag to use ethernet header from IPv6 UDP traceroute page

    // 6to4 IPv4 header for UDP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[17], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv4 TCP for Traceroute
  if (data->save_flags[10]) {

    // Flag to specify ethernet header
    fputc (data->specify_ether[9], fo);

    // Interface name for IPv4 TCP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[9][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[9]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv4 header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[9], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // IPv4 header for TCP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[9], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal IP option entry
    fputc (data->dec_hex_ipopt_tcp4_tr, fo);

    // IPv4 header options and padding for traceroute
    fputc (data->ip_nopt[9], fo);  // Number of IP options: ip_nopt[type] = int
    for (i=0; i<data->ip_nopt[9]; i++) {
      fputc (data->ip_optlen[9][i], fo);  // IPv4 option length: ip_optlen[type][option #] = int
    }
    for (i=0; i<data->ip_nopt[9]; i++) {
      for (j=0; j<data->ip_optlen[9][i]; j++) {
        fputc (data->ip_options[9][i][j], fo);  // IPv4 options data: ip_options[type][option #] = uint8_t *
      }
    }
    fputc (data->ip_optpadlen[9], fo);  // IPv4 options padding length: ip_optpadlen[type] = int

    // Flag for randomizing TCP source port
    fputc (data->ran_tcp4_tr_sourceport, fo);

    // TCP header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->tcphdr[9], TCP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<TCP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal TCP option entry
    fputc (data->dec_hex_tcpopt_tcp4_tr, fo);

    // TCP header options and padding for traceroute
    fputc (data->tcp_nopt[9], fo);  // Number of TCP options: tcp_nopt[type] = int
    for (i=0; i<data->tcp_nopt[9]; i++) {
      fputc (data->tcp_optlen[9][i], fo);  // TCP option length: tcp_optlen[type][option #] = int
    }
    for (i=0; i<data->tcp_nopt[9]; i++) {
      for (j=0; j<data->tcp_optlen[9][i]; j++) {
        fputc (data->tcp_options[9][i][j], fo);  // TCP options data: tcp_options[type][option #] = uint8_t *
      }
    }
    fputc (data->tcp_optpadlen[9], fo);  // TCP options padding length: tcp_optpadlen[type] = int

    // Flag for ASCII or hexadecimal TCP data entry
    fputc (data->ascii_hex_tcp4_tr, fo);

    // Length of TCP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[9]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // TCP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[9], data->payloadlen[9] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv4 ICMP for Traceroute
  if (data->save_flags[11]) {

    // Flag to specify ethernet header for traceroute
    fputc (data->specify_ether[10], fo);

    // Interface name for IPv4 ICMP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[10][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[10]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv4 header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[10], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // IPv4 header for ICMP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[10], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal IP option entry
    fputc (data->dec_hex_ipopt_icmp4_tr, fo);

    // IPv4 header options and padding for traceroute
    fputc (data->ip_nopt[10], fo);  // Number of IP options: ip_nopt[type] = int
    for (i=0; i<data->ip_nopt[10]; i++) {
      fputc (data->ip_optlen[10][i], fo);  // IPv4 option length: ip_optlen[type][option #] = int
    }
    for (i=0; i<data->ip_nopt[10]; i++) {
      for (j=0; j<data->ip_optlen[10][i]; j++) {
        fputc (data->ip_options[10][i][j], fo);  // IPv4 options data: ip_options[type][option #] = uint8_t *
      }
    }
    fputc (data->ip_optpadlen[10], fo);  // IPv4 options padding length: ip_optpadlen[type] = int

    // ICMP header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->icmp4hdr[10], ICMP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ICMP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal ICMP data entry
    fputc (data->ascii_hex_icmp4_tr, fo);

    // Length of ICMP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[10]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // ICMP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[10], data->payloadlen[10] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv4 UDP for Traceroute
  if (data->save_flags[12]) {

    // Flag to specify ethernet header
    fputc (data->specify_ether[11], fo);

    // Interface name for IPv4 UDP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[11][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[11]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv4 header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[11], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // IPv4 header for UDP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip4hdr[11], IP4_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP4_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal IP option entry
    fputc (data->dec_hex_ipopt_udp4, fo);

    // IPv4 header options and padding for traceroute
    fputc (data->ip_nopt[11], fo);  // Number of IP options: ip_nopt[type] = int
    for (i=0; i<data->ip_nopt[11]; i++) {
      fputc (data->ip_optlen[11][i], fo);  // IPv4 option length: ip_optlen[type][option #] = int
    }
    for (i=0; i<data->ip_nopt[11]; i++) {
      for (j=0; j<data->ip_optlen[11][i]; j++) {
        fputc (data->ip_options[11][i][j], fo);  // IPv4 options data: ip_options[type][option #] = uint8_t *
      }
    }
    fputc (data->ip_optpadlen[11], fo);  // IPv4 options padding length: ip_optpadlen[type] = int

    // Flag for randomizing UDP source port
    fputc (data->ran_udp4_tr_sourceport, fo);

    // UDP header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->udphdr[11], UDP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<UDP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal UDP data entry
    fputc (data->ascii_hex_udp4_tr, fo);

    // Length of UDP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[11]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // UDP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[11], data->payloadlen[11] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv6 TCP for Traceroute
  if (data->save_flags[13]) {

    // Interface name for IPv6 TCP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[12][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[12]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv6 header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[12], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // IPv6 header for TCP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip6hdr[12], IP6_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing TCP source port
    fputc (data->ran_tcp6_tr_sourceport, fo);

    // TCP header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->tcphdr[12], TCP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<TCP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for decimal or hexadecimal TCP option entry
    fputc (data->dec_hex_tcpopt_tcp6_tr, fo);

    // TCP header options and padding for traceroute
    fputc (data->tcp_nopt[12], fo);  // Number of TCP options: tcp_nopt[type] = int
    for (i=0; i<data->tcp_nopt[12]; i++) {
      fputc (data->tcp_optlen[12][i], fo);  // TCP option length: tcp_optlen[type][option #] = int
    }
    for (i=0; i<data->tcp_nopt[12]; i++) {
      for (j=0; j<data->tcp_optlen[12][i]; j++) {
        fputc (data->tcp_options[12][i][j], fo);  // TCP options data: tcp_options[type][option #] = uint8_t *
      }
    }
    fputc (data->tcp_optpadlen[12], fo);  // TCP options padding length: tcp_optpadlen[type] = int

    // Flag for ASCII or hexadecimal TCP data entry for traceroute
    fputc (data->ascii_hex_tcp6_tr, fo);

    // Length of TCP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[12]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // TCP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[12], data->payloadlen[12] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv6 ICMP for Traceroute
  if (data->save_flags[14]) {

    // Interface name for IPv6 ICMP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[13][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[13]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv6 header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[13], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // IPv6 header for ICMP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip6hdr[13], IP6_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // ICMP header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->icmp6hdr[13], ICMP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ICMP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal ICMP data entry for traceroute
    fputc (data->ascii_hex_icmp6_tr, fo);

    // Length of ICMP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[13]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // ICMP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[13], data->payloadlen[13] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // IPv6 UDP for Traceroute
  if (data->save_flags[15]) {

    // Interface name for IPv6 UDP for traceroute
    for (i=0; i<TMP_STRINGLEN; i++) {
      fputc (data->ifname[14][i], fo);
    }

    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->ifmtu[14]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // Ethernet header for IPv6 header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ethhdr[14], ETH_HDRLEN * sizeof (uint8_t));
    for (i=0; i<ETH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // IPv6 header for UDP for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->ip6hdr[14], IP6_HDRLEN * sizeof (uint8_t));
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for randomizing UDP source port for traceroute
    fputc (data->ran_udp6_tr_sourceport, fo);

    // UDP header for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, &data->udphdr[14], UDP_HDRLEN * sizeof (uint8_t));
    for (i=0; i<UDP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Flag for ASCII or hexadecimal UDP data entry for traceroute
    fputc (data->ascii_hex_udp6_tr, fo);

    // Length of UDP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
    *ival16 = htons ((int16_t ) data->payloadlen[14]);  // Use network byte order for consistent endianess across platforms
    fputc (buffer[0], fo);
    fputc (buffer[1], fo);

    // UDP data for traceroute
    memset (buffer, 0, buffer_size * sizeof (uint8_t));
    memcpy (buffer, data->payload[14], data->payloadlen[14] * sizeof (uint8_t));  // We use buffer because we also want the zeros
    for (i=0; i<IP_MAXPACKET; i++) {
      fputc (buffer[i], fo);
    }
  }

  // EXTENSION HEADERS

  // Hop-by-hop headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not to be saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating hop-by-hop header: hbh_hdr_flag[type] = int
    fputc (data->hbh_hdr_flag[ip6_type[i]], fo);

    // Number of hop-by-hop options: hbh_nopt[type] = int
    fputc (data->hbh_nopt[ip6_type[i]], fo);

    // Hop-by-hop header, excluding options and padding
    if (data->hbh_nopt[ip6_type[i]] > 0) {
      fputc (data->hophdr[ip6_type[i]].nxt_hdr, fo);
      fputc (data->hophdr[ip6_type[i]].hdr_len, fo);
    }

    // Hop-by-hop option length: hbh_optlen[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      fputc (data->hbh_optlen[ip6_type[i]][j], fo);
    }

    // Hop-by-hop options data: hbh_options[type][option #] = uint8_t *
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->hbh_optlen[ip6_type[i]][j]; k++) {
        fputc (data->hbh_options[ip6_type[i]][j][k], fo);
      }
    }

    // Option alignment parameter x (of xN + y)
    // hbh_x[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      fputc (data->hbh_x[ip6_type[i]][j], fo);
    }

    // Option alignment parameter y (of xN + y)
    // hbh_y[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      fputc (data->hbh_y[ip6_type[i]][j], fo);
    }

    // Hop-by-hop header options padding length (includes alignment padding)
    // hbh_optpadlen[type] = int
    if (data->hbh_nopt[ip6_type[i]] > 0) {
      fputc (data->hbh_optpadlen[ip6_type[i]], fo);
    }

    // Hop-by-hop header options alignment padding length
    // hbh_optleadpadlen[type][option #] = int
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      fputc (data->hbh_optleadpadlen[ip6_type[i]][j], fo);
    }

    // Hop-by-hop options alignment padding
    // hbh_optleadpad[type][option #] = uint8_t *
    for (j=0; j<data->hbh_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->hbh_optleadpadlen[ip6_type[i]][j]; k++) {
        fputc (data->hbh_optleadpad[ip6_type[i]][j][k], fo);
      }
    }

    // Hop-by-hop header trailing padding length
    // hbh_opttailpadlen[type] = int
    fputc (data->hbh_opttailpadlen[ip6_type[i]], fo);

    // Hop-by-hop header trailing padding
    // hbh_opttailpad[type] = uint8_t *
    for (j=0; j<data->hbh_opttailpadlen[ip6_type[i]]; j++) {
      fputc (data->hbh_opttailpad[ip6_type[i]][j], fo);
    }
  }

  // Destination headers (first)
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not to be saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating destination header (first): dstf_hdr_flag[type] = int
    fputc (data->dstf_hdr_flag[ip6_type[i]], fo);

    // Number of destination options: dstf_nopt[type] = int
    fputc (data->dstf_nopt[ip6_type[i]], fo);

    // Destination header (first), excluding options and padding
    if (data->dstf_nopt[ip6_type[i]] > 0) {
      fputc (data->dstfhdr[ip6_type[i]].nxt_hdr, fo);
      fputc (data->dstfhdr[ip6_type[i]].hdr_len, fo);
    }

    // Destination option length: dstf_optlen[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      fputc (data->dstf_optlen[ip6_type[i]][j], fo);
    }

    // Destination options data: dstf_options[type][option #] = uint8_t *
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstf_optlen[ip6_type[i]][j]; k++) {
        fputc (data->dstf_options[ip6_type[i]][j][k], fo);
      }
    }

    // Option alignment parameter x (of xN + y)
    // dstf_x[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      fputc (data->dstf_x[ip6_type[i]][j], fo);
    }

    // Option alignment parameter y (of xN + y)
    // dstf_y[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      fputc (data->dstf_y[ip6_type[i]][j], fo);
    }

    // Destination header (first) options padding length (includes alignment padding)
    // dstf_optpadlen[type] = int
    if (data->dstf_nopt[ip6_type[i]] > 0) {
      fputc (data->dstf_optpadlen[ip6_type[i]], fo);
    }

    // Destination header (first) options alignment padding length
    // dstf_optleadpadlen[type][option #] = int
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      fputc (data->dstf_optleadpadlen[ip6_type[i]][j], fo);
    }

    // Destination header (first) options alignment padding
    // dstf_optleadpad[type][option #] = uint8_t *
    for (j=0; j<data->dstf_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstf_optleadpadlen[ip6_type[i]][j]; k++) {
        fputc (data->dstf_optleadpad[ip6_type[i]][j][k], fo);
      }
    }

    // Destination header (first) trailing padding length
    // dstf_opttailpadlen[type] = int
    fputc (data->dstf_opttailpadlen[ip6_type[i]], fo);

    // Destination header (first) trailing padding
    // dstf_opttailpad[type] = uint8_t *
    for (j=0; j<data->dstf_opttailpadlen[ip6_type[i]]; j++) {
      fputc (data->dstf_opttailpad[ip6_type[i]][j], fo);
    }

  }

  // Routing headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not to be saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating routing header: route_hdr_flag[type] = int
    fputc (data->route_hdr_flag[ip6_type[i]], fo);

    if (data->route_hdr_flag[ip6_type[i]]) {

      // Routing header, excluding data: routehdr[type] = struct Route_hdr
      fputc (data->routehdr[ip6_type[i]].nxt_hdr, fo);
      fputc (data->routehdr[ip6_type[i]].hdr_len, fo);
      fputc (data->routehdr[ip6_type[i]].routing_type, fo);
      fputc (data->routehdr[ip6_type[i]].segs_left, fo);

      // Routing header data length: route_datlen[type] = int
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      *ival16 = htons ((int16_t ) data->route_datlen[ip6_type[i]]);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);

      // Routing header data: route_data[type] = uint8_t *
      for (j=0; j<data->route_datlen[ip6_type[i]]; j++) {
        fputc (data->route_data[ip6_type[i]][j], fo);
      }
    }
  }

  // Authentication headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not to be saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating authentication header: auth_hdr_flag[type] = int
    fputc (data->auth_hdr_flag[ip6_type[i]], fo);

    if (data->auth_hdr_flag[ip6_type[i]]) {

      // Flag indicating transport or tunnel mode authentication: auth_tr_tun_flag[type] = int
      fputc (data->auth_tr_tun_flag[ip6_type[i]], fo);

      // Authentication header: authhdr[type] = struct Auth_hdr
      fputc (data->authhdr[ip6_type[i]].nxt_hdr, fo);
      fputc (data->authhdr[ip6_type[i]].pay_len, fo);
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      *ival16 = htons ((int16_t ) data->authhdr[ip6_type[i]].reserved);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival32 = (int32_t *) buffer;  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      *ival32 = htonl ((int32_t ) data->authhdr[ip6_type[i]].spi);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);
      fputc (buffer[2], fo);
      fputc (buffer[3], fo);
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival32 = (int32_t *) buffer;  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      *ival32 = htonl ((int32_t ) data->authhdr[ip6_type[i]].seq);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);
      fputc (buffer[2], fo);
      fputc (buffer[3], fo);

      // Authentication data length: auth_len[type] = int
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      *ival16 = htons ((int16_t ) data->auth_len[ip6_type[i]]);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);

      // Authentication data (integrity check value (ICV)): auth_data[type] = uint8_t *
      for (j=0; j<data->auth_len[ip6_type[i]]; j++) {
        fputc (data->auth_data[ip6_type[i]][j], fo);
      }
    }
  }

  // ESP headers
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not to be saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating ESP header: esp_hdr_flag[type] = int
    fputc (data->esp_hdr_flag[ip6_type[i]], fo);

    if (data->esp_hdr_flag[ip6_type[i]]) {

      // Flag indicating ESP transport or tunnel mode: esp_tr_tun_flag[type] = int
      fputc (data->esp_tr_tun_flag[ip6_type[i]], fo);

      // ESP header: esphdr[type] = struct esp_hdr
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival32 = (int32_t *) buffer;  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      *ival32 = htonl ((int32_t ) data->esphdr[ip6_type[i]].spi);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);
      fputc (buffer[2], fo);
      fputc (buffer[3], fo);
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival32 = (int32_t *) buffer;  // Cast ival32 as pointer to 32 bit (4 byte) int within buffer
      *ival32 = htonl ((int32_t ) data->esphdr[ip6_type[i]].seq);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);
      fputc (buffer[2], fo);
      fputc (buffer[3], fo);

      // ESP tail: esptail[type] = struct esp_tail
      fputc (data->esptail[ip6_type[i]].pad_len, fo);
      fputc (data->esptail[ip6_type[i]].nxt_hdr, fo);

      // ESP payload padding: esp_pad[type] = uint8_t *
      for (j=0; j<data->esptail[ip6_type[i]].pad_len; j++) {
        fputc (data->esp_pad[ip6_type[i]][j], fo);
      }

      // ESP authentication header data length: esp_auth_len[type] = int
      memset (buffer, 0, buffer_size * sizeof (uint8_t));
      ival16 = (int16_t *) buffer;  // Cast ival16 as pointer to 16 bit (2 byte) int within buffer
      *ival16 = htons ((int16_t ) data->esp_auth_len[ip6_type[i]]);  // Use network byte order for consistent endianess across platforms
      fputc (buffer[0], fo);
      fputc (buffer[1], fo);

      // ESP authentication data (integrity check value (ICV)): esp_auth_data[type] = uint8_t *
      for (j=0; j<data->esp_auth_len[ip6_type[i]]; j++) {
        fputc (data->esp_auth_data[ip6_type[i]][j], fo);
      }
    }
  }

  // Destination headers (last)
  for (i=0; i<6; i++) {  // i is index to ip6_type array

    // Skip those types which are not to be saved.
    if (!skip_type (i, data)) {
      continue;
    }

    // Flag indicating destination header (last): dstl_hdr_flag[type] = int
    fputc (data->dstl_hdr_flag[ip6_type[i]], fo);

    // Number of destination options: dstl_nopt[type] = int
    fputc (data->dstl_nopt[ip6_type[i]], fo);

    // Destination header (last), excluding options and padding
    if (data->dstl_nopt[ip6_type[i]] > 0) {
      fputc (data->dstlhdr[ip6_type[i]].nxt_hdr, fo);
      fputc (data->dstlhdr[ip6_type[i]].hdr_len, fo);
    }

    // Destination option length: dstl_optlen[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      fputc (data->dstl_optlen[ip6_type[i]][j], fo);
    }

    // Destination options data: dstl_options[type][option #] = uint8_t *
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstl_optlen[ip6_type[i]][j]; k++) {
        fputc (data->dstl_options[ip6_type[i]][j][k], fo);
      }
    }

    // Option alignment parameter x (of xN + y)
    // dstl_x[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      fputc (data->dstl_x[ip6_type[i]][j], fo);
    }

    // Option alignment parameter y (of xN + y)
    // dstl_y[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      fputc (data->dstl_y[ip6_type[i]][j], fo);
    }

    // Destination header (last) options padding length (includes alignment padding)
    // dstl_optpadlen[type] = int
    if (data->dstl_nopt[ip6_type[i]] > 0) {
      fputc (data->dstl_optpadlen[ip6_type[i]], fo);
    }

    // Destination header (last) options alignment padding length
    // dstl_optleadpadlen[type][option #] = int
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      fputc (data->dstl_optleadpadlen[ip6_type[i]][j], fo);
    }

    // Destination header (last) options alignment padding
    // dstl_optleadpad[type][option #] = uint8_t *
    for (j=0; j<data->dstl_nopt[ip6_type[i]]; j++) {
      for (k=0; k<data->dstl_optleadpadlen[ip6_type[i]][j]; k++) {
        fputc (data->dstl_optleadpad[ip6_type[i]][j][k], fo);
      }
    }

    // Destination header (last) trailing padding length
    // dstl_opttailpadlen[type] = int
    fputc (data->dstl_opttailpadlen[ip6_type[i]], fo);

    // Destination header (last) trailing padding
    // dstl_opttailpad[type] = uint8_t *
    for (j=0; j<data->dstl_opttailpadlen[ip6_type[i]]; j++) {
      fputc (data->dstl_opttailpad[ip6_type[i]][j], fo);
    }
  }

  // Close file descriptor.
  fclose (fo);

  // Free allocated memory.
  free (text);
  free (buffer);

  return (EXIT_SUCCESS);
}
