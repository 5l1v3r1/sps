/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int downloading;  // Flag to indicate a file download thread is active
extern int show_dl_messages;  // Flag to show sent and received messages on stdout as files download
extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()

G_LOCK_EXTERN (downloading);  // MUTEX for flag indicating a download thread is active
G_LOCK_EXTERN (show_dl_messages);  // MUTEX for flag indicating messages from file download threads should be sent to stdout
G_LOCK_EXTERN (message_available);  // MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen()

// Retrieve the www.iso.org's ISO 3166-1 country code list.
// This function is executed as a separate thread, spawned by either on_button55_clicked() or download_all().
int
get_countries (SPSData *data)
{
  int sd, total_len, data_len;
  char *ip_addr, *get, *received_data;

  // Array of chars
  ip_addr = allocate_strmem (INET6_ADDRSTRLEN);

  // Array of chars
  get = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars for received data
  // Reserve more memory than we'll really need, just to be safe.
  received_data = allocate_strmem (100000);

  // Set country code file status to "Loading".
  g_idle_add ((GSourceFunc) cc_loading, data);

  // HTTP GET statement to retrieve the ISO 3166-1 country code list.
  sprintf (get, "GET %s%s HTTP/1.1\r\nHost: %s\r\n\r\n", data->country_dir, data->country_file, data->country_www);

  // Make TCP connection to remote host.
  if ((sd = http_sock (data->country_www, ip_addr, HTTP_PORT, data)) < 0) {
    free (ip_addr);
    free (get);
    free (received_data);
    g_idle_add ((GSourceFunc) cc_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("\nConnected to %s (%s)\n", data->country_www, ip_addr);
  }
  G_UNLOCK (show_dl_messages);

  // Request the country code file.
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("\nRequesting country code file.\n");
  }
  G_UNLOCK (show_dl_messages);
  if (send_get (sd, get, data) == EXIT_FAILURE) {
    free (ip_addr);
    free (get);
    free (received_data);
    g_idle_add ((GSourceFunc) cc_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Receive the country code file.
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("\nReceiving country code file.\n");
  }
  G_UNLOCK (show_dl_messages);
  if (http_recv (sd, received_data, &total_len, &data_len, data) == EXIT_FAILURE) {
    free (ip_addr);
    free (get);
    free (received_data);
    g_idle_add ((GSourceFunc) cc_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Save the country code file.
  if (save_data (received_data, &total_len, &data_len, data->country_file, data) == EXIT_FAILURE) {
    free (ip_addr);
    free (get);
    free (received_data);
    g_idle_add ((GSourceFunc) cc_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("\nCountry code file received and saved.\n");
    printf ("\nDONE!\n");
  }
  G_UNLOCK (show_dl_messages);

  // Close socket.
  close (sd);

  G_LOCK (downloading);
  downloading = 0;
  G_UNLOCK (downloading);

  // Load country codes into memory.
  read_countries (data);

  // Update country code file status.
  g_idle_add ((GSourceFunc) cc_available, data);

  // Free allocated memory.
  free (ip_addr);
  free (get);
  free (received_data);

  return (EXIT_SUCCESS);
}

// Request socket descriptor for HTTP connection.
int
http_sock (char *host, char *ip_addr, const char *port, SPSData *data)
{
  int sd, status;
  struct addrinfo hints, *servinfo, *p;
  struct timeval ts;

  // Populate struct hints for getaddrinfo().
  memset (&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  // Resolve URL to IP address.
  if ((status = getaddrinfo (host, port, &hints, &servinfo)) != 0) {
    sprintf (data->error_text, "http_sock(): getaddrinfo() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  // Loop through all the results and connect to the first we can.
  // Request socket descriptor.
  for (p = servinfo; p != NULL; p = p->ai_next) {
    if ((sd = socket (p->ai_family, p->ai_socktype, p->ai_protocol)) < 0) {
      status = errno;
      continue;
    }

    // Set socket timeout option for connection.
    memset (&ts, 0, sizeof (struct timeval));
    ts.tv_sec = HTTP_TIMEOUT;
    if ((setsockopt (sd, SOL_SOCKET, SO_RCVTIMEO, &ts, sizeof (ts))) != 0) {
      status = errno;
      close (sd);
      continue;
    }

    // Establish connection to remote host.
    if (connect (sd, p->ai_addr, p->ai_addrlen) < 0) {
      status = errno;
      close (sd);
      continue;
    }
    break;
  }

  if (p == NULL) {
    sprintf (data->error_text, "http_sock(): Failed to establish a connection with remote host.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  // Get IP address so calling function can report it.
  if (inet_ntop (p->ai_family, get_in_addr ((struct sockaddr *)p->ai_addr), ip_addr, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "http_sock(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    freeaddrinfo (servinfo);
    return (EXIT_FAILURE);
  }

  freeaddrinfo (servinfo);

  return (sd);
}

// Send an HTTP GET.
int
send_get (int sd, char *command, SPSData *data)
{
  int status;

  if (write (sd, command, strnlen (command, TEXT_STRINGLEN)) < 1) {
    status = errno;
    sprintf (data->error_text, "send_get(): write() failed to write bytes to socket.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  sleep (1);  // Allow remote host to respond.

  return (EXIT_SUCCESS);
}

// Receive data resulting from an HTTP GET.
int
http_recv (int sd, char *received_data, int *total_len, int *data_len, SPSData *data)
{
  int i, j, k, nbytes, status, code;
  char *text, *line, *http_data, *err_msg;

  // Allocate memory for various arrays of chars.
  text = allocate_strmem (TEXT_STRINGLEN);
  err_msg = allocate_strmem (TEXT_STRINGLEN);
  line = allocate_strmem (TEXT_STRINGLEN);
  http_data = allocate_strmem (IP_MAXPACKET);

  i = 0;
  nbytes = 1;
  *total_len = 0;
  while (nbytes) {
    memset (http_data, 0, IP_MAXPACKET * sizeof (char));
    if ((nbytes = recv (sd, http_data, IP_MAXPACKET, 0)) < 0) {
      status = errno;
      if (status == EAGAIN) {  // No response within TIMEOUT seconds. EAGAIN = 11
        sprintf (data->error_text, "http_recv(): recv() timed-out.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        free (text);
        free (err_msg);
        free (line);
        free (http_data);
        return (EXIT_FAILURE);
      } else if (status == ECONNREFUSED) {  // ECONNREFUSED = 111
        sprintf (data->error_text, "http_recv(): remote host refused connection.\nError message: %s\n", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        free (text);
        free (err_msg);
        free (line);
        free (http_data);
        return (EXIT_FAILURE);
      } else if (status == EINTR) {  // EINTR = 4
          continue;  // Something weird happened, but let's keep listening.
      } else {
        sprintf (data->error_text, "http_recv(): recv() failed.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        free (text);
        free (err_msg);
        free (line);
        free (http_data);
        return (EXIT_FAILURE);
      }
    }
    for (j=0; j<nbytes; j++) {
      received_data[i] = http_data[j];
      i++;
    }
    *total_len += nbytes;
  }

  // Check status code for error message in response.
  // See Sections 6.1 and 6.1.1 of RFC 2616.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  i = 0;
  while ((received_data[i] != ' ') && (i < TEXT_STRINGLEN)) {
    i++;
  }
  if (i == TEXT_STRINGLEN) {
    sprintf (data->error_text, "http_recv(): Couldn't find status code in HTTP response.");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (text);
    free (err_msg);
    free (line);
    free (http_data);
    return (EXIT_FAILURE);
  }
  i++;
  text[0] = received_data[i]; i++;
  text[1] = received_data[i]; i++;
  text[2] = received_data[i]; i++;
  if (!is_ascii_uint (text)) {
    sprintf (data->error_text, "HTTP status code appears to be invalid: %s", text);
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (text);
    free (err_msg);
    free (line);
    free (http_data);
    return (EXIT_FAILURE);
  } else {
    code = (int) ascii_to_int64 (text);
  }
  if (code != 200) {
    i++;  // Skip space
    memset (err_msg, 0, TEXT_STRINGLEN * sizeof (char));
    j = 0;
    while ((received_data[i] != '\r') && (received_data[i] != '\n') && (i < TEXT_STRINGLEN)) {
      err_msg[j] = received_data[i];
      i++;
      j++;
    }
    if (i == TEXT_STRINGLEN) {
      sprintf (data->error_text, "http_recv(): Couldn't find reason phrase in HTTP response.");
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      free (text);
      free (err_msg);
      free (line);
      free (http_data);
      return (EXIT_FAILURE);
    }
    sprintf (data->error_text, "http_recv(): HTTP response indicates a problem.\n%i %s", code, err_msg);
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (text);
    free (err_msg);
    free (line);
    free (http_data);
    return (EXIT_FAILURE);
  }

  // Find content length.
  i = 0;  // Index to temp_array.
  k = 0;  // Line count.
  memset (line, 0, TEXT_STRINGLEN * sizeof (char));
  while ((strncmp (line, "Content-Length:", TEXT_STRINGLEN) != 0) && (k < 80)) {  // Limit k to 80 to avoid endless loops.
    j = 0;
    memset (line, 0, TEXT_STRINGLEN * sizeof (char));
    while ((received_data[i] != '\r') && (j < 80)) {  // Limit j to 80 to avoid endless loops.
      line[j] = received_data[i];
      i++;
      j++;
    }
    if (i == 80) {
      sprintf (data->error_text, "http_recv(): Can't read line from received data.\n");
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      free (text);
      free (err_msg);
      free (line);
      free (http_data);
      return (EXIT_FAILURE);
    }
    i += 2;  // Skip the \r\n to get to next line.
    line[15] = 0;  // Truncate line length to allow for only "Content-Length:" + '\0'.
    k++;  // Increment line count.
  }
  if (k == 80) {
    sprintf (data->error_text, "http_recv(): Can't find 'CONTENT-LENGTH:' in HTTP data received data.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (text);
    free (err_msg);
    free (line);
    free (http_data);
    return (EXIT_FAILURE);
  }
  if (!is_ascii_uint (line + 16)) {
    sprintf (data->error_text, "http_recv(): 'CONTENT-LENGTH:' appears invalid in HTTP data received data: %s\n", line + 16);
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (text);
    free (err_msg);
    free (line);
    free (http_data);
  } else {
    *data_len = (int) ascii_to_int64 (line+16);
  }

  // Free allocated memory.
  free (text);
  free (err_msg);
  free (line);
  free (http_data);

  return (EXIT_SUCCESS);
}

// Save received data to file.
int
save_data (char *received_data, int *total_len, int *data_len, char *filename, SPSData *data)
{
  int i;
  FILE *fo;

  // Open file to save received data.
  fo = fopen (filename, "wb");
  if (fo == NULL) {
    sprintf (data->error_text, "save_data(): Can't open file to save data.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  // Write data to file, excluding received HTTP header info.
  for (i=(*total_len) - (*data_len); i<(*total_len); i++) {
    fputc (received_data[i], fo);
  }

  // Close file.
  fclose (fo);

  return (EXIT_SUCCESS);
}

// Set country code file status to "Loading".
// This idle function returns 0 in order to stop.
int
cc_loading (SPSData *data)
{
  GtkTextBuffer *textbuffer;

  // Update file status on ui.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview15));
  gtk_text_buffer_set_text (textbuffer, "Loading", -1);

  return (0);  // This idle function stops when it returns a value of zero.
}

// Set country code file status to "Not Available" because an error occurred.
// This idle function returns 0 in order to stop.
int
cc_not_available (SPSData *data)
{
  GtkTextBuffer *textbuffer;

  // Update file status on ui.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview15));
  gtk_text_buffer_set_text (textbuffer, "Not Available", -1);

  return (0);  // This idle function stops when it returns a value of zero.
}

// Set country code file status to "Loaded".
// This idle function returns 0 in order to stop.
int
cc_available (SPSData *data)
{
  GtkTextBuffer *textbuffer;

  // Update file status on ui.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview15));

  if (data->countries_loaded) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }

  return (0);  // This idle function stops when it returns a value of zero.
}
