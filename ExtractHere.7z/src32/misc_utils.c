/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Prepare a string of text containing a hexadecimal and ASCII listing of data.
// Returns length of string_out.
int
hexascii_listing (uint8_t *data, int len, char *string_out, int ether)
{
  int i, j, c, d, nchunks, remaindr;
  char *ascii;

  // Allocate memory for ASCII array.
  ascii = allocate_strmem (len);

  // Populate ASCII array with only alpha-numerics and symbols. i.e., no control characters
  alphanum_and_symbols (data, len, ascii);

  // Number of full lines nchunks (16 bytes per line), and partial lines remaindr.
  nchunks = (int) (len / 16);
  remaindr = len % 16;

  c = 0;  // Index of data
  d = 0;  // Index of string_out
  i = 0;  // Line number (each line is a 16-byte "chunk")

  // If displaying a packet and ethernet header is not specified (i.e., using HDRINCL),
  // put dashes where ethernet header would be (first 14 bytes).
  if (!ether) {
    sprintf (string_out, "%08x :", 0); d += 10;
    for (j=0; j<8; j++) { sprintf (string_out + d, " --"); d += 3; }
    string_out[d] = ' '; d++;
    for (j=8; j<ETH_HDRLEN; j++) { sprintf (string_out + d, " --"); d += 3; }
    c += ETH_HDRLEN;
    // Print last two hexadecimal bytes.
    sprintf (string_out + d, " %02x", data[c]); d += 3;
    c++;
    sprintf (string_out + d, " %02x", data[c]); d += 3;
    string_out[d] =  '\n'; d++;
    c++;

    i++;  // Move to next line ("chunk").
  }

  // List data, except any partial line.
  for (  ; i<nchunks; i++) {
    sprintf (string_out + d, "%08x :", (i * 16)); d += 10;
    for (j=0; j<8; j++) { sprintf (string_out + d, " %02x", data[j+c]); d += 3; }
    string_out[d] = ' '; d++;
    for (j=8; j<16; j++) { sprintf (string_out + d, " %02x", data[j+c]); d += 3; }
    string_out[d] = ' '; d++;
    for (j=0; j<8; j++) { sprintf (string_out + d, " %c", ascii[j+c]); d += 2; }
    string_out[d] = ' '; d++;
    for (j=8; j<16; j++) { sprintf (string_out + d, " %c", ascii[j+c]); d += 2; }
    string_out[d] = '\n'; d++;
    c += 16;
  }

  // Print address for last line
  sprintf (string_out + d, "%08x : ", (nchunks * 16)); d += 11;

  // Write the final (partial) line of hexadecimals
  if (remaindr <= 8) {
    for (i=0; i<remaindr; i++) { sprintf (string_out + d, "%02x ", data[(nchunks * 16) + i]); d += 3; }
    for (i=0; i<(8-remaindr); i++) { sprintf (string_out + d, "   "); d += 3; }
    string_out[d] = ' '; d++;
    for (i=0; i<8; i++) { sprintf (string_out + d, "   "); d += 3; }
  } else if (remaindr > 8) {
    for (i=0; i<8; i++) { sprintf (string_out + d, "%02x ", data[(nchunks * 16) + i]); d += 3; }
    string_out[d] = ' '; d++;
    for (i=8; i<remaindr; i++) { sprintf (string_out + d, "%02x ", data[(nchunks * 16) + i]); d += 3; }
    for (i=0; i<(16-remaindr); i++) { sprintf (string_out + d, "   "); d += 3; }
  }
  string_out[d] = ' '; d++;

  // Write the final (partial) line of ASCII characters.
  if (remaindr <= 8) {
    for (i=0; i<remaindr; i++) { sprintf (string_out + d, "%c ", ascii[(nchunks * 16) + i]); d += 2; }
  } else if (remaindr > 8) {
    for (i=0; i<8; i++) { sprintf (string_out + d, "%c ", ascii[(nchunks * 16) + i]); d += 2; }
    string_out[d] = ' '; d++;
    for (i=8; i<remaindr; i++) { sprintf (string_out + d, "%c ", ascii[(nchunks * 16) + i]); d += 2; }
  }

  // Free allocated memory.
  free (ascii);

  return (d);
}

// Copy data to ascii array but only allow alphanumerics and symbols.
int
alphanum_and_symbols (uint8_t *data, int len, char *ascii)
{
  int i;

  // Replace any characters outside of range ' ' to '~' into ' '.
  // 32 = ' ', 126 = '~'
  for (i=0; i<len; i++) {
    if ((data[i] < 32) || (data[i] > 126)) {
      ascii[i] = 32;
    } else {
      ascii[i] = data[i];
    }
  }

  return (EXIT_SUCCESS);
}

// Function to convert 8 bit binary to decimal
int
bin8_to_dec (int *bin)
{
  int i;
  int dec;

  dec = 0;
  for (i=0; i<8; i++) {
    dec += (bin[i] << i);
  }

  return (dec);
}

// Do some rough checks to see if address is a valid IPv4 address.
int
is_valid_ip4 (const char *ip)
{
  unsigned int n1, n2, n3, n4;
  char *buf;

  // Array of chars
  buf = allocate_strmem (INET_ADDRSTRLEN);

  // Less than four values given? (truncates extras if more than four)
  if (sscanf (ip, "%u.%u.%u.%u", &n1, &n2, &n3, &n4) != 4) {
    free (buf);
    return (0);  // Less than four values given.
  }

  // All four are within 0 and 255, and first isn't 0?
  if ((n1 != 0) && (n1 <= 255) && (n2 <= 255) && (n3 <= 255) && (n4 <= 255)) {

  // OK, but any weird characters? (note: negative signs are weird) Compare input ip with reconstructed to check.
    sprintf (buf, "%u.%u.%u.%u", n1, n2, n3, n4);
    if (!strncmp (buf, ip, INET_ADDRSTRLEN)) {
      free (buf);
      return (1);  // Appears to be a valid IPv4 address.
    } else {
      free (buf);
      return (0);  // A weird character was detected.
    }
  } else {
    free (buf);
    return (0);  // Out of range value detected.
  }
}

// Check string for valid comma-separated hexadecimal values.
int
is_valid_hexdata (const char *string, SPSData *data)
{
  int i, j, len, result;
  char temp[TMP_STRINGLEN];
  char **endptr;

  len = strnlen (string, IP_MAXPACKET);

  // Check for a character which is neither hexadecimal, a comma, nor a space.
  for (i=0; i<len; i++) {
    if (!(is_valid_hex (string[i])) && (string[i] != ',') && (string[i] != ' ')) {
      return (0);  // Character is neither hexadecimal, a comma, nor a space.
    }
  }

  // Check for data composed of only spaces (bad).
  j = 0;  // If j = 1 it means we found a non-space character (good).
  for (i=0; i<len; i++) {
    if (string[i] != ' ') {
      j = 1;
      break;
    }
  }
  if (!j) {
    return (0);  // Nothing but spaces were found in string.
  }

  // Check if first character is a comma (which is bad).
  i = 0;
  while (i < len) {
    if (string[i] == ',') {
      return (0);  // First character is a comma.
    } else if (string[i] == ' ') {
      i++;
      continue;  // This character is a space so ignore it and keep looping.
    } else {
      break;  // First character must be valid hexadecimal, so we're done.
    }
  }

  // Check if last character is a comma (which is bad).
  i = len - 1;
  while (i >= 0) {
    if (string[i] == ',') {
      return (0);  // First character is a comma.
    } else if (string[i] == ' ') {
      i--;
      continue;  // This character is a space so ignore it and keep looping.
    } else {
      break;  // Last character must be valid hexadecimal, so we're done.
    }
  }

  // Check for adjacent commas (which is bad.).
  for (i=0; i<(len-1); i++) {
    if ((string[i] == ',') && (string[i+1] == ',')) {
      return (0);  // Found two adjacent commas.
    }
  }

  // We need to limit values to 0xff.
  i = 0;
  while (i < len) {

    // Grab next hexadecimal value.
    memset (temp, 0, TMP_STRINGLEN * sizeof (char));
    j = 0;
    while ((string[i+j] != ' ') && (string[i+j] != ',') && ((i + j) < len)) {
      temp[j] = string[i+j];
      j++;
    }
    i += j;

    // Clobber leading zeros.
    for (j=0; j<(int) strnlen (temp, TMP_STRINGLEN); j++) {
      if (temp[j] == '0') {
        temp[j] = ' ';  // replace zero with space
      } else if ((temp[j] != ' ') && (temp[j] != '0')) {
        break;  // valid digit was found; we're done looking for leading zeros.
      }
    }

    // Convert to base-10 chars and store as data.
    endptr = NULL;
    result = strtol (temp, endptr, 16);
    if (endptr != NULL) {
      sprintf (data->error_text, "is_valid_hex_data(): strtol() failed.");
      data->parent = data->main_window;
      report_error (data);
      return (0);  // strtol() failed.
    }
    if ((result < 0) || (result > 0xff)) {
      return (0);  // Value is less than 0 or greater than 0xff.
    }

    // Increment i until we find more hexadecimal values or hit end of string.
    while (((string[i] == ' ') || (string[i] == ',')) && (i < len)) {
      i++;
    }
  }

  return (1);  //  String appears to be valid comma-separated hexadecimal data.
}

// Check for valid hexadecimal character.
int
is_valid_hex (char byte)
{
  // Within ranges 0 to 9, a to f, or A to F is ok.
  if (!(((byte > 64) && (byte < 71)) || ((byte > 96) && (byte < 103)) ||
    ((byte > 47) && (byte < 58)))) {
    return (0);  // Found invalid hexadecimal character.
  }

  return (1);  // Appears to be valid hexadecimal character.
}

// Check string for valid comma-separated decimal values.
int
is_valid_decdata (const char *string, SPSData *data)
{
  int i, j, len, result;
  char temp[TMP_STRINGLEN];
  char **endptr;

  len = strnlen (string, IP_MAXPACKET);

  // Check for a character which is neither decimal, a comma, nor a space.
  for (i=0; i<len; i++) {
    if (!(is_valid_dec (string[i])) && (string[i] != ',') && (string[i] != ' ')) {
      return (0);  // Character is neither decimal, a comma, nor a space.
    }
  }

  // Check for data composed of only spaces (bad).
  j = 0;  // If j = 1 it means we found a non-space character (good).
  for (i=0; i<len; i++) {
    if (string[i] != ' ') {
      j = 1;
      break;
    }
  }
  if (!j) {
    return (0);  // Nothing but spaces were found in string.
  }

  // Check if first character is a comma (which is bad).
  i = 0;
  while (i < len) {
    if (string[i] == ',') {
      return (0);  // First character is a comma.
    } else if (string[i] == ' ') {
      i++;
      continue;  // This character is a space so ignore it and keep looping.
    } else {
      break;  // First character must be valid hexadecimal, so we're done.
    }
  }

  // Check if last character is a comma (which is bad).
  i = len - 1;
  while (i >= 0) {
    if (string[i] == ',') {
      return (0);  // First character is a comma.
    } else if (string[i] == ' ') {
      i--;
      continue;  // This character is a space so ignore it and keep looping.
    } else {
      break;  // Last character must be valid hexadecimal, so we're done.
    }
  }

  // Check for adjacent commas (which is bad.).
  for (i=0; i<(len-1); i++) {
    if ((string[i] == ',') && (string[i+1] == ',')) {
      return (0);  // Found two adjacent commas.
    }
  }

  // We need to limit values to 255.
  i = 0;
  while (i < len) {

    // Grab next decimal value.
    memset (temp, 0, TMP_STRINGLEN * sizeof (char));
    j = 0;
    while ((string[i+j] != ' ') && (string[i+j] != ',') && ((i + j) < len)) {
      temp[j] = string[i+j];
      j++;
    }
    i += j;

    // Clobber leading zeros.
    for (j=0; j<(int) strnlen (temp, TMP_STRINGLEN); j++) {
      if (temp[j] == '0') {
        temp[j] = ' ';  // replace zero with space
      } else if ((temp[j] != ' ') && (temp[j] != '0')) {
        break;  // valid digit was found; we're done looking for leading zeros.
      }
    }

    // Store as data.
    endptr = NULL;
    result = strtol (temp, endptr, 10);
    if (endptr != NULL) {
      sprintf (data->error_text, "is_valid_dec_data(): strtol() failed.");
      data->parent = data->main_window;
      report_error (data);
      return (0);  // strtol() failed.
    }
    if ((result < 0) || (result > 255)) {
      return (0);  // Value is less than 0 or greater than 255.
    }

    // Increment i until we find more decimal values or hit end of string.
    while (((string[i] == ' ') || (string[i] == ',')) && (i < len)) {
      i++;
    }
  }

  return (1);
}

// Check for valid decimal digit.
int
is_valid_dec (char byte)
{
  // '0' = 48, '9' = 57
  if (!((byte > 47) && (byte < 58))) {
    return (0);  // Character is an invalid decimal digit.
  }

  return (1);  // Character is a valid decimal digit.
}

// Check for ASCII representation of unsigned integer numbers.
int
is_ascii_uint (const char *string)
{
  int i;

  // Only 0 to 9 are accepted. Negative signs and decimals will return failure.
  // '0' = 48, '9' = 57
  for (i=0; i<(int) strnlen (string, IP_MAXPACKET); i++) {
    if ((string[i] < 48) || (string[i] > 57)) {
      return (0);  // Found invalid ASCII representation of unsigned integer number.
    }
  }

  return (1);  // Appears to be valid ASCII representation of unsigned integer numbers.
}

// Convert an ASCII representation of a 64-bit integer into a 64-bit integer.
int64_t
ascii_to_int64 (char *string)
{
  int64_t result;
  char **endptr;

  endptr = NULL;
  errno = 0;
  result = (int64_t) strtoll (string, endptr, 10);
  if ((errno != 0) || (endptr != NULL)) {
    return (-1);  // Error condition
  }

  return (result);
}

// Get sockaddr (IPv4 or IPv6).
// This excellent bit of code is taken from
// Brian “Beej Jorgensen” Hall (beej@beej.us).
void *
get_in_addr (struct sockaddr *sa)
{
  if (sa->sa_family == AF_INET) {
    return &(((struct sockaddr_in*)sa)->sin_addr);
  }

  return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

// Recursive carry for subtracting arbitrarily long numbers.
int
carry (int n, int i, int *t, int *s)
{
  // For IPv4 (4 bytes) n = 4. For IPv6 (16 bytes) n = 16.
  if (i == n) return 0;  // Can't carry from any higher order bytes.

  if (t[i+1] != 0) {
    t[i+1]--;
  } else {
    t[i+1] = 255;
    if (carry (n, i+1, t, s) == 0) return 0;  // Can't carry from any higher order bytes.
  }

  return (1);
}

// Parse character string into 4-byte IPv4 address.
int
parse_ipv4 (char *ip4string, uint32_t *ip4)
{
  int i, j, p;
  char temp[4];

  p = 0;
  for (i=3; i>=0; i--) {
    j = 0;
    memset (temp, 0, 4 * sizeof (char));
    while (ip4string[p] && (ip4string[p] != '.')) {
      temp[j] = ip4string[p];
      p++;
      j++;
    }
    ip4[i] = (uint32_t) ascii_to_int64 (temp);
    p++;  // Skip the '.'
  }

  return (EXIT_SUCCESS);
}

// Determine CIDR (slash) notation or IPv4 range based upon "value"
// given in delegation file.
int
show_cidr_or_range (uint32_t val, unsigned int *ip4, char *answer)
{
  int i, j, flag;
  unsigned int inc[4];

  // Can we use slash notation to express range of addresses?
  flag = 0;
  for (i=0; i<31; i++) {
    if (val == (1u << i)) {
      flag++;
      break;
    }
  }

  // Yes.
  if (flag) {
    sprintf (answer, "%i.%i.%i.%i/%i", ip4[3], ip4[2], ip4[1], ip4[0], 32 - i);

  // No, we cannot use slash notation. We'll show range instead.
  } else {
    answer[0] = 0;  // Start with string of zero length (faster than memsetting whole string; speed counts here).
    for (i=3; i>0; i--) {
      sprintf (answer, "%s%i.", answer, ip4[i]);  // Starting address
    }
    sprintf (answer, "%s%i", answer, ip4[0]);

    // Calculate increments.
    j = 24;
    for (i=3; i>=0; i--) {
      inc[i] = (val >> j) & 255u;
      j -= 8;
    }

    // Calculate final address by adding increments with carry.
    for (i=0; i<3; i++) {
      if ((ip4[i] + inc[i]) > 255u) {
        inc[i+1]++;
        ip4[i] += inc[i];
        ip4[i] = ip4[i] & 255u;
      } else {
        ip4[i] += inc[i];
      }
    }
    if ((ip4[3] + inc[3]) > 255u) {
      printf ("ERROR: This number of IPv4 addresses exceeds total IPv4 space.\n");
      printf ("       Value: %i\n", val);
      exit (EXIT_FAILURE);
    } else {
      ip4[3] += inc[3];
    }

    sprintf (answer, "%s to %i.%i.%i.%i", answer, ip4[3], ip4[2], ip4[1], ip4[0]);
  }

  return (EXIT_SUCCESS);
}

// Parse character string into 16-byte IPv6 address.
int
parse_ipv6 (char *ip6string, unsigned int *ip6)
{
  int i, j, k, p, left, right, nright, tempi, flag;
  char temp[5];

  memset (ip6, 0, 16 * sizeof (unsigned int));

  // Determine if a double-colon exists, and if so, where.
  flag = 0;
  p = 0;
  while (ip6string[p]) {
    if ((ip6string[p] == ':') && (ip6string[p+1] == ':')) {
      flag = 1;
      left = p;  // Index of left colon in string.
      right = p + 1;  // Index of right colon in string.
      break;
    }
    p++;
  }

  // We have a double-colon.
  if (flag) {
    // Work on the left side first.
    k = 15;
    p = 0;
    while (p < left) {
      i = 0;
      memset (temp, 0, 5 * sizeof (char));
      while (ip6string[p] != ':') {
        temp[i] = ip6string[p];
        i++;
        p++;
      }
      p++;  // Skip ':'
      sscanf (temp, "%x", &tempi);
      if (tempi <= 255) {
        k--;
        ip6[k] = tempi;
        k--;
      } else {
        ip6[k] = (int) (tempi / 256);
        k--;
        ip6[k] = tempi % 256;
        k--;
      }
    }

    // Now work on right side.
    // First count how many groups on right side of double-colon.
    // Recall that 'right' is string index to right colon of double-colon.
    if (ip6string[right+1] != 0) {  // There's numbers to the right of the right colon.
      i = 0;
      p = right + 1;
      while (ip6string[p]) {
        if (ip6string[p] == ':') i++;
        p++;
      }
      i++;
      nright = i;

      k = (i * 2) - 1;
      p = right + 1;
      for (j=0; j<nright; j++) {
        i = 0;
        memset (temp, 0, 5 * sizeof (char));
        while (ip6string[p] && (ip6string[p] != ':')) {
          temp[i] = ip6string[p];
          i++;
          p++;
        }
        p++;  // Skip ':'
        sscanf (temp, "%x", &tempi);
        if (tempi <= 255) {
          k--;
          ip6[k] = tempi;
          k--;
        } else {
          ip6[k] = (int) (tempi / 256);
          k--;
          ip6[k] = tempi % 256;
          k--;
        }
      }
    }

  // We don't have a double-colon.
  } else {
    k = 15;
    p = 0;
    while (ip6string[p]) {
      i = 0;
      memset (temp, 0, 5 * sizeof (char));
      while (ip6string[p] && (ip6string[p] != ':')) {
        temp[i] = ip6string[p];
        i++;
        p++;
      }
      p++;  // Skip ':'
      sscanf (temp, "%x", &tempi);
      if (tempi <= 255) {
        k--;
        ip6[k] = tempi;
        k--;
      } else {
        ip6[k] = (int) (tempi / 256);
        k--;
        ip6[k] = tempi % 256;
        k--;
      }
    }
  }

  return (EXIT_SUCCESS);
}

// Test if an IPv4 address is within a range of IPv4 addresses.
// Return 1 if within range, 0 if outside of range.
int
interval_test_ipv4 (char *teststring, char *ip4string, uint32_t val)
{
  int i, j, p, flag;
  uint32_t test[4], ip4_start[4], inc[4], ip4_end[4];
  int t[4], s[4], e[4];
  char temp[4];

  // Extract the test IPv4 address from string.
  p = 0;
  for (i=3; i>=0; i--) {
    j = 0;
    memset (temp, 0, 4 * sizeof (char));
    while (teststring[p] && (teststring[p] != '.')) {
      temp[j] = teststring[p];
      p++;
      j++;
    }
    test[i] = (uint32_t) ascii_to_int64 (temp);
    p++;  // Skip the '.'
  }

  // Determine the starting IPv4 address of the range.
  p = 0;
  for (i=3; i>=0; i--) {
    j = 0;
    memset (temp, 0, 4 * sizeof (char));
    while (ip4string[p] && (ip4string[p] != '.')) {
      temp[j] = ip4string[p];
      p++;
      j++;
    }
    ip4_start[i] = (uint32_t) ascii_to_int64 (temp);
    p++;  // Skip the '.'
  }

  // Calculate increments.
  val -= 1u;
  j = 24;
  for (i=3; i>=0; i--) {
    inc[i] = (val >> j) & 255u;
    j -= 8;
  }

  // Determine final IPv4 address by adding increments with carry.
  for (i=0; i<3; i++) {
    if ((ip4_start[i] + inc[i]) > 255u) {
      inc[i+1]++;
      ip4_end[i] = ip4_start[i] + inc[i];
      ip4_end[i] = ip4_end[i] & 255u;
    } else {
      ip4_end[i] = ip4_start[i] + inc[i];
    }
  }
  if ((ip4_start[3] + inc[3]) > 255u) {
    printf ("ERROR: This number of IPv4 addresses exceeds total IPv4 space.\n");
    exit (EXIT_FAILURE);
  } else {
    ip4_end[3] = ip4_start[3] + inc[3];
  }

  // Test to see if IPv4 address falls within start-end range.
  // To do this, we do two subtractions with carry:
  // 1)  (test - start) > 0 
  // 2)  (end - test) > 0
  // If BOTH (1) and (2) are true, then we are within range.

  // Copy arrays so we don't corrupt originals.
  // Cast as int so we can get negative subtraction results.
  for (i=0; i<4; i++) {
    t[i] = (int) test[i];
    s[i] = (int) ip4_start[i];
  }

  flag = 1;  // Initially assume it does fall within range.

  // Is this IPv4 address less than the starting IP address of the range.
  // Let's check by subtraction, recursively carrying as necessary.
  for (i=0; i<4; i++) {              // Loop through bytes of address from LSB.
    if ((t[i] - s[i]) < 0) {         // Need to carry from next higher order byte.
      if ((i == 3) || (carry (4, i, t, s) == 0)) {
        flag = 0;
        break;
      }
    }
  }

  // Copy arrays so we don't corrupt originals.
  // Cast as int so we can get negative subtraction results.
  for (i=0; i<4; i++) {
    t[i] = (int) test[i];
    e[i] = (int) ip4_end[i];
  }

  // Is this IPv4 address greater than the end IP address of the range.
  // Let's check by subtraction, recursively carrying as necessary
  // Copy arrays so we don't corrupt originals.
  for (i=0; i<4; i++) {              // Loop through bytes of address from LSB.
    if ((e[i] - t[i]) < 0) {         // Need to carry from next higher order byte.
      if ((i == 3) || (carry (4, i, e, t) == 0)) {
        flag = 0;
        break;
      }
    }
  }

  return (flag);
}

// Test if an IPv6 address is within a range of IPv6 addresses.
int
interval_test_ipv6 (char *teststring, char *ip6string, unsigned int val)
{
  int i, flag, hostbits, hostbytes, bit_remainder;
  unsigned int test[16], ip6_start[16], ip6_end[16];
  int t[16], s[16], e[16];

  // Extract the test IPv6 address from string.
  parse_ipv6 (teststring, test);

  // Determine the starting IPv6 address of the range.
  parse_ipv6 (ip6string, ip6_start);

  // Determine final IPv6 address of the range.
  // Begin with start IP address.
  parse_ipv6 (ip6string, ip6_end);
  hostbits = 128 - val;  // Hostbits = 128 - prefix bits
  hostbytes = (int) hostbits / 8;
  bit_remainder = hostbits - (hostbytes * 8);
  for (i=0; i<hostbytes; i++) {
    ip6_end[i] = 255u;
  }
  if ((hostbits % 8) != 0) {
    for (i=0; i<bit_remainder; i++) {
      ip6_end[hostbytes] = ip6_end[hostbytes] | (1u << i);
    }
  }

  // Test to see if IPv6 address falls within start-end range.
  // To do this, we do two subtractions with carry:
  // 1)  (test - start) > 0 
  // 2)  (end - test) > 0
  // If BOTH (1) and (2) are true, then we are within range.

  // Copy arrays so we don't corrupt originals.
  // Cast as int so we can get negative subtraction results.
  for (i=0; i<16; i++) {
    t[i] = (int) test[i];
    s[i] = (int) ip6_start[i];
  }

  flag = 1;  // Initially assume it does fall within range.

  // Is this IPv6 address less than the starting IP address of the range.
  // Let's check by subtraction, recursively carrying as necessary.
  for (i=0; i<16; i++) {             // Loop through bytes of address from LSB.
    if ((t[i] - s[i]) < 0) {         // Need to carry from next higher order byte.
      if ((i == 15) || (carry (16, i, t, s) == 0)) {
        flag = 0;
        break;
      }
    }
  }

  // Copy arrays so we don't corrupt originals.
  // Cast as int so we can get negative subtraction results.
  for (i=0; i<16; i++) {
    t[i] = (int) test[i];
    e[i] = (int) ip6_end[i];
  }

  // Is this IPv6 address greater than the end IP address of the range.
  // Let's check by subtraction, recursively carrying as necessary
  // Copy arrays so we don't corrupt originals.
  for (i=0; i<16; i++) {             // Loop through bytes of address from LSB.
    if ((e[i] - t[i]) < 0) {         // Need to carry from next higher order byte.
      if ((i == 15) || (carry (16, i, e, t) == 0)) {
        flag = 0;
        break;
      }
    }
  }

  return (flag);
}

// Cross-reference between "save type" index and packet type index.
// Used by load_file() and save_file().
int
skip_type (int i, SPSData *data)
{
  int ip6_type[6]={3,4,5,12,13,14};

  // If not selected by user, then skip it by returning 0.
  if ((!data->save_flags[5] && (ip6_type[i] == 3)) ||
      (!data->save_flags[6] && (ip6_type[i] == 4)) ||
      (!data->save_flags[7] && (ip6_type[i] == 5)) ||
      (!data->save_flags[13] && (ip6_type[i] == 12)) ||
      (!data->save_flags[14] && (ip6_type[i] == 13)) ||
      (!data->save_flags[15] && (ip6_type[i] == 14))) {
    return (0);  // Packet type not selected by user; skip it.
  }

  return (1);  // Don't skip this packet type.
}

// Read a single line of text from a text file.
// Returns -1 when EOF is encountered.
int
read_line (FILE *fi, char *line, int limit)
{
  int i, n;

  i = 0;  // i is pointer to byte in line.
  for (;;) {

    // Check for line index out of bounds.
    if (i >= limit) {
      fprintf (stderr, "ERROR: Line exceeds maximum line length of %i.\n", limit);
      line[limit - 1] = 0;  // Force string termination.
      fprintf (stderr, "       Line contains: %s\n", line);
      exit (EXIT_FAILURE);
    }

    // Grab next byte from file.
    n = fgetc (fi);

    // End of file reached.
    // Tell calling function, by returning -1, that we're at end of file, so it won't call read_line() again.
    if (n == EOF) {
      return (-1);
    }

    // Found a carriage return. Ignore it.
    if (n == '\r') {
      continue;
    }

    // Found a newline. Change to 0 for string termination.
    // Break out of loop since this is the end of the current line.
    if (n == '\n') {
      line[i] = 0;  // Replace with 0 for string termination.
      break;
    }

    // Seems to be a valid character. Keep it.
    line[i] = n;
    i++;
  }

  return (0);  // Finished line, but not at end of file.
}

// Pack Msgdata struct with pointers to a textview and a message string.
Msgdata *
packit (Msgdata *msgdata, char *message)
{
  msgdata->message = message;

  return (msgdata);
}

// Clear textview.
int
clear_textview (GtkWidget *textview)
{
  GtkTextBuffer *textbuffer;

  // Clear any text in the textview.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));  // IPv4
  gtk_text_buffer_set_text (textbuffer, "", -1);

  return (EXIT_SUCCESS);
}
