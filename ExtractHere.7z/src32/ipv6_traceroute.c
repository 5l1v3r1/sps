/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()
extern int tracing;  // Flag to indicate a traceroute thread is active

G_LOCK_EXTERN (message_available);  // Obtain a MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen().
G_LOCK_EXTERN (tracing);  // Obtain a MUTEX for flag indicating a traceroute thread is active.

// Start an IPv6 traceroute.
// This function will be executed as a separate thread on_button24_clicked.
int
ipv6_tr_send (SPSData *data)
{
  int status, frame, sendsd, recsd, probes;
  int bytes, timeout, node, trylim, trycount, done;
  char *src_ip, *dst_ip, *rec_ip;
  char hostname[NI_MAXHOST], *message;
  struct ip6_hdr *iphdr;
  struct tcphdr *tcphdr;
  struct icmp6_hdr *icmphdr;
  uint8_t *rec_ether_frame;
  struct sockaddr_in6 sa;
  struct sockaddr from;
  struct sockaddr_ll device;
  socklen_t fromlen;
  struct timezone tz;
  struct timeval wait, t1, t2;
  double dt;
  Msgdata *msgdata;

  // Allocate memory for various arrays.
  rec_ip = allocate_strmem (INET6_ADDRSTRLEN);
  rec_ether_frame = allocate_ustrmem (IP_MAXPACKET);
  src_ip = allocate_strmem (INET6_ADDRSTRLEN);
  dst_ip = allocate_strmem (INET6_ADDRSTRLEN);

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Make sure all interface names were specified.
  if (((data->packet_type_tr == 12) && (strnlen (data->ifname[12], TMP_STRINGLEN) < 2)) ||
      ((data->packet_type_tr == 13) && (strnlen (data->ifname[13], TMP_STRINGLEN) < 2)) ||
      ((data->packet_type_tr == 14) && (strnlen (data->ifname[14], TMP_STRINGLEN) < 2))) {
    sprintf (data->error_text, "ipv6_tr_send(): Appears to be an invalid interface name.");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Resolve interface index.
  memset (&device, 0, sizeof (device));
  if ((device.sll_ifindex = if_nametoindex (data->ifname[data->packet_type_tr])) == 0) {
    status = errno;
  }
  if (device.sll_ifindex == 0) {
    sprintf (data->error_text, "ipv6_tr_send(): if_nametoindex() failed to obtain interface index.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Fill out sockaddr_ll struct.
  device.sll_family = AF_PACKET;
  memcpy (device.sll_addr, data->ethhdr[data->packet_type_tr].src_mac, 6 * sizeof (uint8_t));
  device.sll_halen = 6u;

  // Grab system date and time.
  message = date_and_time (message, TEXT_STRINGLEN);

  // Show target of traceroute.
  memset (&sa, 0, sizeof (sa));
  sa.sin6_family = AF_INET6;
  inet_ntop (AF_INET6, &(data->ip6hdr[data->packet_type_tr].ip6_dst), dst_ip, INET6_ADDRSTRLEN);

  if ((status = inet_pton (AF_INET6, dst_ip, &sa.sin6_addr)) != 1) {
    sprintf (data->error_text, "ipv6_tr_send(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  if (data->resolve_tr) {
    if ((status = getnameinfo ((struct sockaddr*)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
      sprintf (data->error_text, "ipv6_tr_send(): getnameinfo() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
    if (data->packet_type_tr == 12) {
      sprintf (message, "%s TCP (IPv6) traceroute to %s (%s) port %i\n", message, dst_ip, hostname, ntohs (data->tcphdr[12].th_dport));
    } else if (data->packet_type_tr == 13) {
      sprintf (message, "%s ICMP (IPv6) traceroute to %s (%s)\n", message, dst_ip, hostname);
    } else if (data->packet_type_tr == 14) {
      sprintf (message, "%s UDP (IPv6) traceroute to %s (%s) port %i\n", message, dst_ip, hostname, ntohs (data->udphdr[14].uh_dport));
    }
  } else {
    if (data->packet_type_tr == 12) {
      sprintf (message, "%s TCP (IPv6) traceroute to %s port %i\n", message, dst_ip, ntohs (data->tcphdr[12].th_dport));
    } else if (data->packet_type_tr == 13) {
      sprintf (message, "%s ICMP (IPv6) traceroute to %s\n", message, dst_ip);
    } else if (data->packet_type_tr == 14) {
      sprintf (message, "%s UDP (IPv6) traceroute to %s port %i\n", message, dst_ip, ntohs (data->udphdr[14].uh_dport));
    }
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview7;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Submit request for raw socket descriptors - one to send, one to receive.
  if ((sendsd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "ipv6_tr_send(): socket() failed to get a socket descriptor for sending.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  if ((recsd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "ipv6_tr_send(): socket() failed to get a socket descriptor for receiving.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Set maximum number of tries for a host before incrementing TTL and moving on.
  trylim = 3;

  // Set pointers to IPv6, ICMP, and TCP headers within received ethernet frame.
  iphdr = (struct ip6_hdr *) (rec_ether_frame + ETH_HDRLEN);
  icmphdr = (struct icmp6_hdr *) (rec_ether_frame + ETH_HDRLEN + IP6_HDRLEN);
  tcphdr = (struct tcphdr *) (rec_ether_frame + ETH_HDRLEN + IP6_HDRLEN);

  // SEND LOOP
  // Loop incrementing TTL each time, exiting when we get our target IP address.
  done = 0;
  trycount = 0;
  node = 1;
  probes = 0;

  for (;;) {

    if (!tracing) {  // Break out of Send loop if Stop button was pressed.
      done = 2;
      break;
    }

    // Set hop limit and update ethernet frames.
    data->ip6hdr[data->packet_type_tr].ip6_hops = node;
    create_ip6_frame (data->packet_type_tr, data);

    // Send ethernet frame.
    for (frame=0; frame<data->nframes[data->packet_type_tr]; frame++) {
      if ((bytes = sendto (sendsd, data->ether_frame[data->packet_type_tr][frame], data->frame_length[data->packet_type_tr][frame], 0, (struct sockaddr *) &device, sizeof (device))) <= 0) {
        status = errno;
        sprintf (data->error_text, "ipv6_tr_send(): sendto() failed.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        G_LOCK (tracing);
        tracing = 0;
        G_UNLOCK (tracing);
        free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
        return (EXIT_FAILURE);
      }
    }

    probes++;

    // Start timer.
    (void) gettimeofday (&t1, &tz);

    // Set time for the socket to timeout and give up waiting for a reply.
    timeout = data->timeout_tr;
    wait.tv_sec  = timeout;  
    wait.tv_usec = 0;
    setsockopt (recsd, SOL_SOCKET, SO_RCVTIMEO, (char *) &wait, sizeof (struct timeval));

    // Listen for incoming ethernet frame from socket sd.
    // We expect an ICMP ethernet frame of the form:
    //     MAC (6 bytes) + MAC (6 bytes) + ethernet type (2 bytes)
    //     + ethernet data (IPv6 header + ICMP header + IPv6 header + TCP/ICMP/UDP header)
    // Keep at it for data->timeout seconds, or until we get an ICMP reply.

    // RECEIVE LOOP
    for (;;) {

      memset (rec_ether_frame, 0, IP_MAXPACKET * sizeof (uint8_t));
      memset (&from, 0, sizeof (from));
      fromlen = sizeof (from);
      if ((bytes = recvfrom (recsd, rec_ether_frame, IP_MAXPACKET, 0, (struct sockaddr *) &from, &fromlen)) < 0) {

        status = errno;

        // Deal with error conditions first.
        if (status == EAGAIN) {  // EAGAIN = 11
          memset (message, 0, TEXT_STRINGLEN * sizeof (char));
          sprintf (message, "  %i No reply within %i seconds.\n", node, timeout);
          msgdata = allocate_msgdata (1);
          msgdata->textview = data->textview7;
          g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
          trycount++;
          break;  // Break out of Receive loop.
        } else if (status == EINTR) {  // EINTR = 4
          continue;  // Something weird happened, but let's keep listening.
        } else {
          sprintf (data->error_text, "ipv6_tr_send(): recvfrom() failed.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          G_LOCK (message_available);
          message_available = 1;
          G_UNLOCK (message_available);
          G_LOCK (tracing);
          tracing = 0;
          G_UNLOCK (tracing);
          free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
          return (EXIT_FAILURE);
        }
      }  // End of error handling conditionals.

      // Check for an IP ethernet frame. If not, ignore and keep listening.
      if (((rec_ether_frame[12] << 8) + rec_ether_frame[13]) == ETH_P_IPV6) {

        // Did we get an ICMP6_TIME_EXCEEDED?
        if ((iphdr->ip6_nxt == IPPROTO_ICMPV6) && (icmphdr->icmp6_type == ICMP6_TIME_EXCEEDED)) {

          trycount = 0;
          // Stop timer and calculate how long it took to get a reply.
          (void) gettimeofday (&t2, &tz);
          dt = (double) (t2.tv_sec - t1.tv_sec) * 1000.0 + (double) (t2.tv_usec - t1.tv_usec) / 1000.0;

          // Extract source IP address from received ethernet frame.
          if (inet_ntop (AF_INET6, &(iphdr->ip6_src), rec_ip, INET6_ADDRSTRLEN) == NULL) {
            status = errno;
            sprintf (data->error_text, "ipv6_tr_send(): inet_ntop() failed.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            G_LOCK (message_available);
            message_available = 1;
            G_UNLOCK (message_available);
            G_LOCK (tracing);
            tracing = 0;
            G_UNLOCK (tracing);
            free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
            return (EXIT_FAILURE);
          }

          // Report source IP address and time for reply.
          if (!data->resolve_tr) {
            memset (message, 0, TEXT_STRINGLEN * sizeof (char));
            sprintf (message, "%2i  %s  %g ms (%i bytes received)", node, rec_ip, dt, bytes);
          } else if (data->resolve_tr) {
            sa.sin6_family = AF_INET6;
            if ((status = inet_pton (AF_INET6, rec_ip, &sa.sin6_addr)) != 1) {
              sprintf (data->error_text, "ipv6_tr_send(): inet_pton() failed.\nError message: %s", strerror (status));
              data->parent = data->main_window;
              G_LOCK (message_available);
              message_available = 1;
              G_UNLOCK (message_available);
              G_LOCK (tracing);
              tracing = 0;
              G_UNLOCK (tracing);
              free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
              return (EXIT_FAILURE);
            }
            if ((status = getnameinfo ((struct sockaddr*)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
              fprintf (stderr, "getnameinfo() failed.\nError message: %s", strerror (status));
              exit (EXIT_FAILURE);
            }
            memset (message, 0, TEXT_STRINGLEN * sizeof (char));
            sprintf (message, "%2i  %s (%s)  %g ms (%i bytes received)", node, rec_ip, hostname, dt, bytes);
          }
          if (probes < data->num_probes) {
            sprintf (message, "%s : ", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            break;  // Break out of Receive loop and probe this node again.
          } else {
            sprintf (message, "%s\n", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            node++;
            probes = 0;
            break;  // Break out of Receive loop and probe next node in route.
          }
        }  // End of ICMP6_TIME_EXCEEDED conditional.

        // Did we reach our destination?
        // TCP SYN-ACK means TCP SYN packet reached destination node.
        // ICMP echo reply means ICMP echo request packet reached destination node.
        // ICMP port unreachable means UDP packet reached destination node.
        if (((iphdr->ip6_nxt == IPPROTO_TCP) && (tcphdr->th_flags == 18)) ||  // (18 = SYN, ACK)
            ((iphdr->ip6_nxt == IPPROTO_ICMPV6) && (icmphdr->icmp6_type == ICMP6_ECHO_REPLY) && (icmphdr->icmp6_code == 0)) ||  // ECHO REPLY
            ((iphdr->ip6_nxt == IPPROTO_ICMPV6) && (icmphdr->icmp6_type == ICMP6_DST_UNREACH) && (icmphdr->icmp6_code == ICMP6_DST_UNREACH_NOPORT))) {  // PORT UNREACHABLE

          // Stop timer and calculate how long it took to get a reply.
          (void) gettimeofday (&t2, &tz);
          dt = (double) (t2.tv_sec - t1.tv_sec) * 1000.0 + (double) (t2.tv_usec - t1.tv_usec) / 1000.0;

          // Extract source IP address from received ethernet frame.
          if (inet_ntop (AF_INET6, &(iphdr->ip6_src), rec_ip, INET6_ADDRSTRLEN) == NULL) {
            status = errno;
            sprintf (data->error_text, "ipv6_send(): inet_ntop() failed.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            G_LOCK (message_available);
            message_available = 1;
            G_UNLOCK (message_available);
            G_LOCK (tracing);
            tracing = 0;
            G_UNLOCK (tracing);
            free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
            return (EXIT_FAILURE);
          }

          // Report source IP address and time for reply.
          memset (message, 0, TEXT_STRINGLEN * sizeof (char));
          sprintf (message, "%2i  %s  %g ms", node, rec_ip, dt);
          if (probes < data->num_probes) {
            sprintf (message, "%s : ", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            break;  // Break out of Receive loop and probe this node again.
          } else {
            sprintf (message, "%s\n", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            done = 1;
            break;  // Break out of Receive loop and finish.
          }
        }  // End of Reached Destination conditional.
      }  // End of Was IP Frame conditional.
    }  // End of Receive loop.


    // Reached destination node or Stop button pressed.
    if ((done == 1) || (done == 2)) {
      break;  // Break out of Send loop.

    // Reached maxhops.
    } else if (node > data->maxhops) {
      memset (message, 0, TEXT_STRINGLEN * sizeof (char));
      sprintf (message, "Reached maximum number of hops. Maximum is set to %i hops.\n", data->maxhops);
      msgdata = allocate_msgdata (1);
      msgdata->textview = data->textview7;
      g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
      done = 3;
      break;  // Break out of Send loop.
    }

    // We ran out of tries, let's move on to next node unless we reached maxhops limit.
    if (trycount == trylim) {
      memset (message, 0, TEXT_STRINGLEN * sizeof (char));
      sprintf (message, "%2i  Node won't respond after %i probes.\n", node, trylim);
      msgdata = allocate_msgdata (1);
      msgdata->textview = data->textview7;
      g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
      node++;
      probes = 0;
      trycount = 0;
      continue;
    }

    // Randomize source ports if requested.
    // create_ip6_frame() will be called when Send loop cycles and TTL is updated.

    // TCP
    if ((data->packet_type_tr == 12) && data->ran_tcp6_tr_sourceport) {
      data->tcphdr[data->packet_type_tr].th_sport = htons (ran16_0to65535 (data));

      // TCP header checksum (16 bits)
      data->tcphdr[data->packet_type_tr].th_sum = tcp6_checksum (data->ip6hdr[data->packet_type_tr], data->tcphdr[data->packet_type_tr], data->tcp_nopt[data->packet_type_tr], data->tcp_opt_totlen[data->packet_type_tr], data->tcp_optlen[data->packet_type_tr], data->tcp_options[data->packet_type_tr], data->tcp_optpadlen[data->packet_type_tr], data->payload[data->packet_type_tr], data->payloadlen[data->packet_type_tr]);
    }

    // UDP
    if ((data->packet_type_tr == 14) && data->ran_udp6_tr_sourceport) {
      data->udphdr[data->packet_type_tr].uh_sport = htons (ran16_0to65535 (data));

      // UDP header checksum (16 bits)
      data->udphdr[data->packet_type_tr].uh_sum = udp6_checksum (data->ip6hdr[data->packet_type_tr], data->udphdr[data->packet_type_tr], data->payload[data->packet_type_tr], data->payloadlen[data->packet_type_tr]);
    }

  }  // End of Send loop.

  if (done == 1) {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "End of traceroute.\n\n");
    msgdata = allocate_msgdata (1);
    msgdata->textview = data->textview7;
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  } else if ((done == 2) || (done == 3)) {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "Traceroute aborted.\n\n");
    msgdata = allocate_msgdata (1);
    msgdata->textview = data->textview7;
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
  }

  // Close socket descriptors.
  close (sendsd);
  close (recsd);

  // Have idle function update IPv6 traceroute source ports, which may have changed if randomized.
  // Only start idle function if traceroute packet-editing window is activated.
  if (data->traceroute_flag) {
    g_idle_add ((GSourceFunc) update_tr_ip6_sources, data);
  }

  // Free allocated memory.
  free_ipv6_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);

  // Clear tracing flag.
  G_LOCK (tracing);
  tracing = 0;
  G_UNLOCK (tracing);

  return (EXIT_SUCCESS);
}

// Free allocated memory used in ipv6_tr_send().
int
free_ipv6_tr_mem (char *rec_ip, uint8_t *rec_ether_frame, char *src_ip, char *dst_ip, char *message)
{
  free (rec_ether_frame);
  free (src_ip);
  free (dst_ip);
  free (rec_ip);
  free (message);

  return (EXIT_SUCCESS);
}

// Idle function to update IPv6 traceroute source ports, which may have changed if randomized.
// This idle function returns 0 in order to stop.
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
update_tr_ip6_sources (SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP (IPv6 traceroute) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[12].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry259), value);

  // UDP (IPv4 traceroute) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[14].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry307), value);

  // Free allocated memory.
  free (value);

  return (0);  // This idle function stops when it returns a value of zero.
}

// Populate IPv6 TCP entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
tcp6_tr_show (SPSData *data)
{
  int status, old;
  uint8_t *tcp6_flags;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer38;

  // TCP flags
  tcp6_flags = allocate_ustrmem (8);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Ethernet header

  // Destination link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[12].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry247), value);

  // Source Interface Name
  gtk_entry_set_text (GTK_ENTRY (data->entry249), data->ifname[12]);

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton14), data->ifmtu[12]);

  // Source link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[12].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry248), value);

  // Ethernet type code (16 bits)
  // http://www.iana.org/assignments/ethernet-numbers
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[12].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry250), value);

  // TCP header options

  // TCP option entry format
  if (data->dec_hex_tcpopt_tcp6_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton54), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton54), FALSE);
  }

  // Number of TCP options
  textbuffer38 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview38));
  sprintf (value, "%i", data->tcp_nopt[12]);
  gtk_text_buffer_set_text (textbuffer38, value, -1);

  // TCP options entry
  if (data->ip_nopt[12] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry422), "Options loaded.");
  }

  // Default option number after which to insert a new option
  gtk_entry_set_text (GTK_ENTRY (data->entry423), "");

  // Number of TCP option to remove (0 = none)
  gtk_entry_set_text (GTK_ENTRY (data->entry424), "");

  // TCP data

  // TCP data entry
  if (data->payloadlen[12] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry276), "Data file loaded.");
  }

  // TCP data entry format
  if (data->ascii_hex_tcp6_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton36), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton36), FALSE);
  }

  // IPv6 header

  // Version (4 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[12].ip6_flow) >> 28));
  gtk_entry_set_text (GTK_ENTRY (data->entry251), value);

  // Traffic Class (8 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[12].ip6_flow) >> 20) & 0xfful));
  gtk_entry_set_text (GTK_ENTRY (data->entry252), value);

  // Flow Label (20 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[12].ip6_flow) & 0xffffful));
  gtk_entry_set_text (GTK_ENTRY (data->entry253), value);

  // Payload length (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[12].ip6_plen));
  gtk_entry_set_text (GTK_ENTRY (data->entry254), value);

  // Next header (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[12].ip6_nxt);
  gtk_entry_set_text (GTK_ENTRY (data->entry255), value);

  // Hop limit (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[12].ip6_hops);
  gtk_entry_set_text (GTK_ENTRY (data->entry256), value);

  // Source IPv6 address (128 bits)
  if (inet_ntop (AF_INET6, &(data->ip6hdr[12].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp6_tr_show(): inet_ntop() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }

  gtk_entry_set_text (GTK_ENTRY (data->entry257), value);

  // Destination IPv6 address (128 bits)
  if (inet_ntop (AF_INET6, &(data->ip6hdr[12].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp6_tr_show(): inet_ntop() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry258), value);

  // TCP header (IPv6)

  // Source port number (16 bits)
  old = data->ran_tcp6_tr_sourceport;
  if (data->ran_tcp6_tr_sourceport) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton37), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton37), FALSE);
  }
  // Variable data->ran_tcp6_tr_sourceport will be changed by on_checkbutton37_toggled(), so set it now.
  data->ran_tcp6_tr_sourceport = old;
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[12].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry259), value);

  // Destination port number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[12].th_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry260), value);

  // Sequence number (32 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[12].th_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry261), value);

  // Acknowledgement number (32 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[12].th_ack));
  gtk_entry_set_text (GTK_ENTRY (data->entry262), value);

  // Reserved (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[12].th_x2);
  gtk_entry_set_text (GTK_ENTRY (data->entry263), value);

  // Data offset (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[12].th_off);
  gtk_entry_set_text (GTK_ENTRY (data->entry264), value);

  // FIN flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[12].th_flags & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry265), value);

  // SYN flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 1) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry266), value);

  // RST flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 2) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry267), value);

  // PSH flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 3) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry268), value);

  // ACK flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 4) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry269), value);

  // URG flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 5) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry270), value);

  // ECE flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 6) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry271), value);

  // CWR flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[12].th_flags >> 7) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry272), value);

  // Window size (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[12].th_win));
  gtk_entry_set_text (GTK_ENTRY (data->entry273), value);

  // Urgent pointer (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[12].th_urp));
  gtk_entry_set_text (GTK_ENTRY (data->entry275), value);

  // TCP checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[12].th_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry274), value);

  // Free allocated memory.
  free (tcp6_flags);
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}

// Populate IPv6 ICMP entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
icmp6_tr_show (SPSData *data)
{
  int status;
  char *ipaddress, *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Ethernet header

  // Destination link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[13].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry277), value);

  // Source Interface Name
  gtk_entry_set_text (GTK_ENTRY (data->entry279), data->ifname[13]);

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton15), data->ifmtu[13]);

  // Source link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[13].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry278), value);
  
  // Ethernet type code (16 bits)
  // http://www.iana.org/assignments/ethernet-numbers
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[13].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry280), value);

  // ICMP data

  // ICMP data entry
  if (data->payloadlen[13] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry294), "Data file loaded.");
  }

  // ICMP data entry format
  if (data->ascii_hex_icmp6_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton38), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton38), FALSE);
  }

  // IPv6 header

  // Version (4 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[13].ip6_flow) >> 28));
  gtk_entry_set_text (GTK_ENTRY (data->entry281), value);

  // Traffic Class (8 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[13].ip6_flow) >> 20) & 0xfful));
  gtk_entry_set_text (GTK_ENTRY (data->entry282), value);

  // Flow Label (20 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[13].ip6_flow) & 0xffffful));
  gtk_entry_set_text (GTK_ENTRY (data->entry283), value);

  // Payload length (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[13].ip6_plen));
  gtk_entry_set_text (GTK_ENTRY (data->entry284), value);

  // Next header (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[13].ip6_nxt);
  gtk_entry_set_text (GTK_ENTRY (data->entry285), value);

  // Hop limit (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[13].ip6_hops);
  gtk_entry_set_text (GTK_ENTRY (data->entry286), value);

  // Source IPv6 address (128 bits)
  if (inet_ntop (AF_INET6, &(data->ip6hdr[13].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp6_tr_show(): inet_ntop() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry287), value);

  // Destination IPv6 address (128 bits)
  if (inet_ntop (AF_INET6, &(data->ip6hdr[13].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp6_tr_show(): inet_ntop() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry288), value);

  // ICMP header (IPv6)

  // Message Type (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp6hdr[13].icmp6_type);
  gtk_entry_set_text (GTK_ENTRY (data->entry289), value);

  // Message Code (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp6hdr[13].icmp6_code);
  gtk_entry_set_text (GTK_ENTRY (data->entry290), value);

  // Identifier (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[13].icmp6_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry292), value);

  // Sequence Number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[13].icmp6_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry293), value);

  // ICMP header checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[13].icmp6_cksum));
  gtk_entry_set_text (GTK_ENTRY (data->entry291), value);

  // Free allocated memory.
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}

// Populate IPv6 UDP entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
udp6_tr_show (SPSData *data)
{
  int status, old;
  char *ipaddress, *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Ethernet header

  // Destination link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[14].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry295), value);

  // Source Interface Name
  gtk_entry_set_text (GTK_ENTRY (data->entry297), data->ifname[14]);

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton16), data->ifmtu[14]);

  // Source link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[14].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry296), value);
  
  // Ethernet type code (16 bits)
  // http://www.iana.org/assignments/ethernet-numbers
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[14].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry298), value);

  // UDP data

  // UDP data entry
  if (data->payloadlen[14] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry311), "Data file loaded.");
  }

  // UDP data entry format
  if (data->ascii_hex_udp6 == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton40), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton40), FALSE);
  }

  // IPv6 header

  // Version (4 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[14].ip6_flow) >> 28));
  gtk_entry_set_text (GTK_ENTRY (data->entry299), value);

  // Traffic Class (8 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[14].ip6_flow) >> 20) & 0xfful));
  gtk_entry_set_text (GTK_ENTRY (data->entry300), value);

  // Flow Label (20 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[14].ip6_flow) & 0xffffful));
  gtk_entry_set_text (GTK_ENTRY (data->entry301), value);

  // Payload length (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[14].ip6_plen));
  gtk_entry_set_text (GTK_ENTRY (data->entry302), value);

  // Next header (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[14].ip6_nxt);
  gtk_entry_set_text (GTK_ENTRY (data->entry303), value);

  // Hop limit (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[14].ip6_hops);
  gtk_entry_set_text (GTK_ENTRY (data->entry304), value);

  // Source IPv6 address (128 bits)
  if (inet_ntop (AF_INET6, &(data->ip6hdr[14].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp6_tr_show(): inet_ntop() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry305), value);

  // Destination IPv6 address (128 bits)
  if (inet_ntop (AF_INET6, &(data->ip6hdr[14].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp6_tr_show(): inet_ntop() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry306), value);

  // UDP header (IPv6)

  // Source port number (16 bits)
  old = data->ran_udp6_tr_sourceport;
  if (data->ran_udp6_tr_sourceport) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton40), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton40), FALSE);
  }
  // Variable data->ran_udp6_tr_sourceport will be changed by on_checkbutton40_toggled(), so set it now.
  data->ran_udp6_tr_sourceport = old;
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[14].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry307), value);

  // Destination port number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[14].uh_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry308), value);

  // Length of UDP datagram (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[14].uh_ulen));
  gtk_entry_set_text (GTK_ENTRY (data->entry309), value);

  // UDP header checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[14].uh_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry310), value);

  // Free allocated memory.
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}
