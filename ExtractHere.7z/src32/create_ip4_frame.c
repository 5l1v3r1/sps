/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Create IPv4 ethernet frame.
int
create_ip4_frame (int type, SPSData *data)
{
  int i, j, c, hdrlen, len[MAX_FRAGS], offset[MAX_FRAGS], *ip_flags, old_nframes;
  int unfraglen, fraglen;
  struct ip iphdr;
  uint8_t *buffer;

  // Set upper layer protocol header length.
  if ((type == 0) || (type == 9)) {
    hdrlen = TCP_HDRLEN;

  } else if ((type == 1) || (type == 10)) {
    hdrlen = ICMP_HDRLEN;

  } else if ((type == 2) || (type == 11)) {
    hdrlen = UDP_HDRLEN;

  } else {
    fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in create_ip4_frame().\n", type);
    exit (EXIT_FAILURE);
  }

  ip_flags = allocate_intmem (4);

  // Allocate memory for a buffer for fragmentable portion.
  buffer = allocate_ustrmem (IP_MAXPACKET + ETH_HDRLEN);

  // Copy IPv4 header so we don't corrupt original during fragmentation.
  memcpy (&iphdr, &data->ip4hdr[type], IP4_HDRLEN * sizeof (uint8_t));

  // Length of unfragmentable portion.
  unfraglen = find4_unfraglen (type, data);

  // Length of fragmentable portion.
  fraglen = find4_fraglen (type, data);

  // Determine required number of IPv6 ethernet frames, frame lengths, and data offsets.
  old_nframes = data->nframes[type];
  find_nframes (type, data->ifmtu[type], unfraglen, fraglen, &data->nframes[type], len, offset);

  // Check if number of frames has changed and re-allocate memory as necessary.
  nframes_change (old_nframes, type, data);

  // Unpack current ip_flags settings.
  ip_flags[0] = (ntohs (iphdr.ip_off) >> 15) & 1u;
  ip_flags[1] = (ntohs (iphdr.ip_off) >> 14) & 1u;
  ip_flags[2] = (ntohs (iphdr.ip_off) >> 13) & 1u;
  ip_flags[3] = ntohs (iphdr.ip_off) & 0x1fffu;

  // Build fragmentable portion of packet in buffer array.

  // Upper layer protocol header
  if ((type == 0) || (type == 9)) {
    memcpy (buffer, &data->tcphdr[type], hdrlen * sizeof (uint8_t));  // TCP header
  } else if ((type == 1) || (type == 10)) {
    memcpy (buffer, &data->icmp4hdr[type], hdrlen * sizeof (uint8_t));  // ICMP header
  } else if ((type == 2) || (type == 11)) {
    memcpy (buffer, &data->udphdr[type], hdrlen * sizeof (uint8_t));  // UDP header
  }
  c = hdrlen;  // Keep count of bytes added to buffer.

  // TCP header options, if appropriate.
  if ((type == 0) || (type == 9)) {
    for (i=0; i<data->tcp_nopt[type]; i++) {
      memcpy (buffer + c, data->tcp_options[type][i], data->tcp_optlen[type][i] * sizeof (uint8_t));
      c += data->tcp_optlen[type][i];
    }
    c += data->tcp_optpadlen[type];  // TCP options padding
  }

  // Upper layer protocol payload data.
  memcpy (buffer + c, data->payload[type], data->payloadlen[type] * sizeof (uint8_t));

  // Loop through fragments.
  for (i=0; i<data->nframes[type]; i++) {

    // Set ethernet frame contents to zero initially.
    memset (data->ether_frame[type][i], 0, (IP_MAXPACKET + ETH_HDRLEN) * sizeof (uint8_t));

    // Index of ethernet frame.
    c = 0;

    // Fill out ethernet frame header.

    // Copy destination and source MAC addresses to ethernet frame.
    memcpy (data->ether_frame[type][i], data->ethhdr[type].dst_mac, 6 * sizeof (uint8_t));
    memcpy (data->ether_frame[type][i] + 6, data->ethhdr[type].src_mac, 6 * sizeof (uint8_t));

    // Copy ethernet type code to ethernet frame.
    memcpy (data->ether_frame[type][i] + 12, &data->ethhdr[type].type_code, 2 * sizeof (uint8_t));
    c += ETH_HDRLEN;

    // Next is ethernet frame data.

    // IPv4 header length (4 bits): Number of 32-bit words in header (includes IP options)
    iphdr.ip_hl = (unfraglen) / sizeof (uint32_t);

    // Total length of datagram (16 bits)
    iphdr.ip_len = htons (unfraglen + len[i]);

    // More fragments following flag (1 bit)
    if ((data->nframes[type] > 1) && (i < (data->nframes[type] - 1))) {
      ip_flags[2] = 1u;
    } else {
      ip_flags[2] = 0u;
    }

    // Fragmentation offset (13 bits)
    if (data->nframes[type] > 1) {
      ip_flags[3] = offset[i];
    }

    // Flags, and Fragmentation offset (3, 13 bits)
    iphdr.ip_off = htons ((ip_flags[0] << 15)
                        + (ip_flags[1] << 14)
                        + (ip_flags[2] << 13)
                        +  ip_flags[3]);

    // IPv4 header checksum (16 bits)
    iphdr.ip_sum = 0;
    iphdr.ip_sum = ip4_checksum (iphdr, data->ip_nopt[type], data->ip_optlen[type], data->ip_options[type], data->ip_optpadlen[type]);

    // Copy IPv4 header to ethernet frame.
    memcpy (data->ether_frame[type][i] + c, &iphdr, IP4_HDRLEN * sizeof (uint8_t));
    c += IP4_HDRLEN;

    // Copy IP options to ethernet frame.
    for (j=0; j<data->ip_nopt[type]; j++) {
      memcpy (data->ether_frame[type][i] + c, data->ip_options[type][j], data->ip_optlen[type][j] * sizeof (uint8_t));
      c += data->ip_optlen[type][j];
    }

    // IP options padding
    c += data->ip_optpadlen[type];

    // Copy fragmentable portion of packet to ethernet frame.
    memcpy (data->ether_frame[type][i] + c, buffer + (offset[i] * 8), len[i] * sizeof (uint8_t));
    c += len[i];

    // Ethernet frame length
    data->frame_length[type][i] = c;
  }

  // Now build the unfragmented packet (for packet display purposes with show_packet()).

  // Set packet contents to zero initially.
  memset (data->packet[type], 0, (IP_MAXPACKET + ETH_HDRLEN) * sizeof (uint8_t));

  // Index of packet.
  c = 0;

  // Copy destination and source MAC addresses to packet.
  memcpy (data->packet[type], data->ethhdr[type].dst_mac, 6 * sizeof (uint8_t));
  memcpy (data->packet[type] + 6, data->ethhdr[type].src_mac, 6 * sizeof (uint8_t));

  // Copy ethernet type code to packet.
  memcpy (data->packet[type] + 12, &data->ethhdr[type].type_code, 2 * sizeof (uint8_t));
  c += ETH_HDRLEN;

  // Next is ethernet frame data.

  // Copy IPv4 header to packet.
  memcpy (data->packet[type] + c, &data->ip4hdr[type], IP4_HDRLEN * sizeof (uint8_t));
  c += IP4_HDRLEN;

  // Copy IP options to packet.
  for (i=0; i<data->ip_nopt[type]; i++) {
    memcpy (data->packet[type] + c, data->ip_options[type][i], data->ip_optlen[type][i] * sizeof (uint8_t));
    c += data->ip_optlen[type][i];
  }

  // IP options padding
  c += data->ip_optpadlen[type];

  // Copy upper layer protocol header to packet.
  if ((type == 0) || (type == 9)) {
    memcpy (data->packet[type] + c, &data->tcphdr[type], hdrlen * sizeof (uint8_t));  // TCP
  } else if ((type == 1) || (type == 10)) {
    memcpy (data->packet[type] + c, &data->icmp4hdr[type], hdrlen * sizeof (uint8_t));  // ICMP
  } else if ((type == 2) || (type == 11)) {
    memcpy (data->packet[type] + c, &data->udphdr[type], hdrlen * sizeof (uint8_t));  // UDP
  }
  c += hdrlen;

  // Copy TCP options to packet, if appropriate.
  if ((type == 0) || (type == 9)) {
    for (i=0; i<data->tcp_nopt[type]; i++) {
      memcpy (data->packet[type] + c, data->tcp_options[type][i], data->tcp_optlen[type][i] * sizeof (uint8_t));
      c += data->tcp_optlen[type][i];
    }

    // TCP options padding.
    c += data->tcp_optpadlen[type];
  }

  // Copy upper layer protocol payload data to packet.
  memcpy (data->packet[type] + c, data->payload[type], data->payloadlen[type] * sizeof (uint8_t));
  c += data->payloadlen[type];

  // Packet length
  data->packet_length[type] = c;

  // Free allocated memory.
  free (ip_flags);
  free (buffer);

  return (EXIT_SUCCESS);
}
