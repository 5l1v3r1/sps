/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Apply IPv4 TCP traceroute default settings
int
tcp4_tr_default (SPSData *data)
{
  int status, i, *ip4_flags, *tcp4_flags;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // TCP flags
  tcp4_flags = allocate_intmem (8);

  // Number of ethernet frames
  data->nframes[9] = 1;

  // Ethernet header

  // Default to have the user specify the ethernet header
  data->specify_ether[9] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[9].dst_mac, 0, 6 * sizeof (uint8_t));

  // Source Interface Name: defaults to blank
  memset (data->ifname[9], 0, TMP_STRINGLEN * sizeof (char));

  // Default interface MTU
  data->ifmtu[9] = 1500;

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[9].src_mac, 0, 6 * sizeof (uint8_t));

  // Ethernet type code (16 bits): default to IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[9].type_code = htons (ETH_P_IP);

  // Deal with IP header options and TCP data first so that
  // lengths and offsets are correct for updating IP and TCP headers.

  // IP header options

  // IP option data entry format: default to hexadecimal input
  data->dec_hex_ipopt_tcp4_tr = 1;

  // No IP options
  data->ip_nopt[9] = 0;

  // Set all option data to zero.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    data->ip_optlen[9][i] = 0;
    memset (data->ip_options[9][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
  }
  memset (data->ip_optionsbuf[9], 0, MAX_IP4OPTLEN * sizeof (uint8_t));

  // Show actual length of option in buffer as zero.
  data->ip_optlenbuf[9] = 0;

  // Default option number after which to insert a new option
  data->ipopt_tcp4_tr_after = 0;

  // Number of IP option to remove (0 = none)
  data->ipopt_tcp4_tr_remove = 0;

  // TCP header options

  // TCP option data entry format: default to hexadecimal input
  data->dec_hex_tcpopt_tcp4_tr = 1;

  // No TCP options
  data->tcp_nopt[9] = 0;

  // Set all option data to zero.
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    data->tcp_optlen[9][i] = 0;
    memset (data->tcp_options[9][i], 0, MAX_TCPOPTLEN * sizeof (uint8_t));
  }
  memset (data->tcp_optionsbuf[9], 0, MAX_TCPOPTLEN * sizeof (uint8_t));

  // Set total length of options to zero.
  data->tcp_opt_totlen[9] = 0;

  // Show actual length of option in buffer as zero.
  data->tcp_optlenbuf[9] = 0;

  // Default option number after which to insert a new option
  data->tcpopt_tcp4_tr_after = 0;

  // Number of TCP option to remove (0 = none)
  data->tcpopt_tcp4_tr_remove = 0;

  // TCP data

  // Clear TCP data buffer.
  memset (data->payload[9], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[9] = 0;

  // TCP data entry format: default to hexadecimal input
  data->ascii_hex_tcp4_tr = 1;

  // IPv4 header

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[9].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[9].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[9].ip_tos = 0;

  // Total length of datagram (16 bits): IP header + TCP header
  data->ip4hdr[9].ip_len = htons (IP4_HDRLEN + TCP_HDRLEN);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[9].ip_id = htons (0);

  // Zero (1 bit)
  ip4_flags[0] = 0;

  // Do not fragment flag (1 bit)
  ip4_flags[1] = 0;

  // More fragments following flag (1 bit)
  ip4_flags[2] = 0;

  // Fragmentation offset (13 bits)
  ip4_flags[3] = 0;

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  data->ip4hdr[9].ip_off = htons ((ip4_flags[0] << 15) +
   (ip4_flags[1] << 14) + (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): start at 1
  data->ip4hdr[9].ip_ttl = 1u;

  // Transport layer protocol (8 bits): 6 for TCP
  data->ip4hdr[9].ip_p = IPPROTO_TCP;

  // Source IPv4 address (32 bits): default to loopback
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[9].ip_src))) != 1) {
    sprintf (data->error_text, "tcp4_tr_default(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (tcp4_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address (32 bits): default to loopback IP address to be safe
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[9].ip_dst))) != 1) {
    sprintf (data->error_text, "tcp4_tr_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (tcp4_flags);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[9].ip_sum = 0;
  data->ip4hdr[9].ip_sum = ip4_checksum (data->ip4hdr[9], data->ip_nopt[9], data->ip_optlen[9], data->ip_options[9], data->ip_optpadlen[9]);

  // TCP header (IPv4)

  // Source port number (16 bits): default to not random
  data->ran_tcp4_tr_sourceport = 0;
  data->tcphdr[9].th_sport = htons (80u);

  // Destination port number (16 bits)
  data->tcphdr[9].th_dport = htons (80u);

  // Sequence number (32 bits)
  data->tcphdr[9].th_seq = htonl (0);

  // Acknowledgement number (32 bits): 0 in first packet
  data->tcphdr[9].th_ack = htonl (0);

  // Reserved (4 bits): should be 0
  data->tcphdr[9].th_x2 = 0;

  // Data offset (4 bits): size of TCP header in 32-bit words
  data->tcphdr[9].th_off = TCP_HDRLEN / sizeof (uint32_t);

  // FIN flag (1 bit)
  tcp4_flags[0] = 0;

  // SYN flag (1 bit): set to 1
  tcp4_flags[1] = 1;

  // RST flag (1 bit)
  tcp4_flags[2] = 0;

  // PSH flag (1 bit)
  tcp4_flags[3] = 0;

  // ACK flag (1 bit)
  tcp4_flags[4] = 0;

  // URG flag (1 bit)
  tcp4_flags[5] = 0;

  // ECE flag (1 bit)
  tcp4_flags[6] = 0;

  // CWR flag (1 bit)
  tcp4_flags[7] = 0;

  // Flags (8 bits): 2 for SYN
  data->tcphdr[9].th_flags = bin8_to_dec (tcp4_flags);

  // Window size (16 bits): default to maximum value
  data->tcphdr[9].th_win = htons (0xffffu);

  // Urgent pointer (16 bits): 0 (only valid if URG flag is set)
  data->tcphdr[9].th_urp = htons (0);

  // TCP checksum (16 bits)
  data->tcphdr[9].th_sum = tcp4_checksum (data->ip4hdr[9], data->tcphdr[9], data->tcp_nopt[9], data->tcp_opt_totlen[9], data->tcp_optlen[9], data->tcp_options[9], data->tcp_optpadlen[9], data->payload[9], data->payloadlen[9]);

  // Free allocated memory.
  free (ip4_flags);
  free (tcp4_flags);

  // Update ethernet frame.
  create_ip4_frame (9, data);

  return (EXIT_SUCCESS);
}

// Apply IPv4 ICMP traceroute page default settings
int
icmp4_tr_default (SPSData *data)
{
  int status, i, *ip4_flags;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Number of ethernet frames
  data->nframes[10] = 1;

  // Ethernet header

  // Default to have the user specify the ethernet header
  data->specify_ether[10] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[10].dst_mac, 0, 6 * sizeof (uint8_t));

  // Source Interface Name: defaults to blank
  memset (data->ifname[10], 0, TMP_STRINGLEN * sizeof (char));

  // Default interface MTU
  data->ifmtu[10] = 1500;

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[10].src_mac, 0, 6 * sizeof (uint8_t));

  // Ethernet type code (16 bits): default to IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[10].type_code = htons (ETH_P_IP);

  // Deal with IP header options and ICMP data first so that
  // lengths and offsets are correct for updating IP and ICMP headers.

  // IP header options

  // IP option data entry format: default to hexadecimal input
  data->dec_hex_ipopt_icmp4_tr = 1;

  // No IP options
  data->ip_nopt[10] = 0;

  // Set all option data to zero.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    data->ip_optlen[10][i] = 0;
    memset (data->ip_options[10][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
  }
  memset (data->ip_optionsbuf[10], 0, MAX_IP4OPTLEN * sizeof (uint8_t));

  // Show actual length of option in buffer as zero.
  data->ip_optlenbuf[10] = 0;

  // Default option number after which to insert a new option
  data->ipopt_icmp4_tr_after = 0;

  // Number of IP option to remove (0 = none)
  data->ipopt_icmp4_tr_remove = 0;

  // ICMP data

  // Clear ICMP data buffer.
  memset (data->payload[10], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[10] = 0;

  // ICMP data entry format: default to hexadecimal input
  data->ascii_hex_icmp4_tr = 1;

  // IPv4 header

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[10].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[10].ip_v = 4u;

  // Type of service (8 bits): default is 0
  data->ip4hdr[10].ip_tos = 0;

  // Total length of datagram (16 bits): IP header + ICMP header
  data->ip4hdr[10].ip_len = htons (IP4_HDRLEN + ICMP_HDRLEN);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[10].ip_id = htons (0);

  // Zero (1 bit)
  ip4_flags[0] = 0;

  // Do not fragment flag (1 bit)
  ip4_flags[1] = 0;

  // More fragments following flag (1 bit)
  ip4_flags[2] = 0;

  // Fragmentation offset (13 bits)
  ip4_flags[3] = 0;

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  data->ip4hdr[10].ip_off = htons ((ip4_flags[0] << 15) +
   (ip4_flags[1] << 14) + (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): start at 1
  data->ip4hdr[10].ip_ttl = 1u;

  // Transport layer protocol (8 bits): 1 for ICMP
  data->ip4hdr[10].ip_p = IPPROTO_ICMP;

  // Source IPv4 address (32 bits): default to loopback
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[10].ip_src))) != 1) {
    sprintf (data->error_text, "icmp4_tr_default(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address (32 bits): default to loopback IP address to be safe
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[10].ip_dst))) != 1) {
    sprintf (data->error_text, "icmp4_tr_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[10].ip_sum = 0;
  data->ip4hdr[10].ip_sum = ip4_checksum (data->ip4hdr[10], data->ip_nopt[10], data->ip_optlen[10], data->ip_options[10], data->ip_optpadlen[10]);

  // ICMP header (IPv4)

  // Message Type (8 bits): echo request
  data->icmp4hdr[10].icmp_type = ICMP_ECHO;

  // Message Code (8 bits): echo request
  data->icmp4hdr[10].icmp_code = 0;

  // Identifier (16 bits): usually pid of sending process - we'll arbitrarily use 1000
  data->icmp4hdr[10].icmp_id = htons (1000u);

  // Sequence Number (16 bits): starts at 0
  data->icmp4hdr[10].icmp_seq = htons (0);

  // ICMP header checksum (16 bits)
  data->icmp4hdr[10].icmp_cksum = icmp4_checksum (data->icmp4hdr[10], data->payload[10], data->payloadlen[10]);

  // Free allocated memory.
  free (ip4_flags);

  // Update ethernet frame.
  create_ip4_frame (10, data);

  return (EXIT_SUCCESS);
}

// Apply IPv4 UDP traceroute page default settings
int
udp4_tr_default (SPSData *data)
{
  int status, i, *ip4_flags;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Number of ethernet frames
  data->nframes[11] = 1;

  // Ethernet header

  // Default to have the user specify the ethernet header
  data->specify_ether[11] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[11].dst_mac, 0, 6 * sizeof (uint8_t));

  // Source Interface Name: defaults to blank
  memset (data->ifname[11], 0, TMP_STRINGLEN * sizeof (char));

  // Default interface MTU
  data->ifmtu[11] = 1500;

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[11].src_mac, 0, 6 * sizeof (uint8_t));

  // Ethernet type code (16 bits): default to IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[11].type_code = htons (ETH_P_IP);

  // Deal with IP header options and UDP data first so that
  // lengths and offsets are correct for updating IP and UDP headers.

  // IP header options

  // IP option data entry format: default to hexadecimal input
  data->dec_hex_ipopt_udp4_tr = 1;

  // No IP options
  data->ip_nopt[11] = 0;

  // Set all option data to zero.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    data->ip_optlen[11][i] = 0;
    memset (data->ip_options[11][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
  }
  memset (data->ip_optionsbuf[11], 0, MAX_IP4OPTLEN * sizeof (uint8_t));

  // Show actual length of option in buffer as zero.
  data->ip_optlenbuf[11] = 0;

  // Default option number after which to insert a new option
  data->ipopt_udp4_tr_after = 0;

  // Number of IP option to remove (0 = none)
  data->ipopt_udp4_tr_remove = 0;

  // UDP data

  // Clear UDP data buffer.
  memset (data->payload[11], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[11] = 0;

  // UDP data entry format: default to hexadecimal input
  data->ascii_hex_udp4_tr = 1;

  // IPv4 header

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[11].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[11].ip_v = 4u;

  // Type of service (8 bits): default is 0
  data->ip4hdr[11].ip_tos = 0;

  // Total length of datagram (16 bits): IP header + UDP header
  data->ip4hdr[11].ip_len = htons (IP4_HDRLEN + UDP_HDRLEN);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[11].ip_id = htons (0);

  // Zero (1 bit)
  ip4_flags[0] = 0;

  // Do not fragment flag (1 bit)
  ip4_flags[1] = 0;

  // More fragments following flag (1 bit)
  ip4_flags[2] = 0;

  // Fragmentation offset (13 bits)
  ip4_flags[3] = 0;

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  data->ip4hdr[11].ip_off = htons ((ip4_flags[0] << 15) +
   (ip4_flags[1] << 14) + (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): start at 1
  data->ip4hdr[11].ip_ttl = 1u;

  // Transport layer protocol (8 bits): 17 for UDP
  data->ip4hdr[11].ip_p = IPPROTO_UDP;

  // Source IPv4 address (32 bits): default to loopback
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[11].ip_src))) != 1) {
    sprintf (data->error_text, "udp4_tr_default(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address (32 bits): default to loopback IP address to be safe
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[11].ip_dst))) != 1) {
    sprintf (data->error_text, "udp4_tr_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[11].ip_sum = 0;
  data->ip4hdr[11].ip_sum = ip4_checksum (data->ip4hdr[11], data->ip_nopt[11], data->ip_optlen[11], data->ip_options[11], data->ip_optpadlen[11]);

  // UDP header (IPv4)

  // Source port number (16 bits): we'll arbitrarily use 4950
  data->ran_udp4_tr_sourceport = 0;
  data->udphdr[11].uh_sport = htons (4950u);

  // Destination port number (16 bits): 33435
  data->udphdr[11].uh_dport = htons (33435u);

  // Length of UDP datagram (16 bits): UDP header + UDP payload
  data->udphdr[11].uh_ulen = htons (UDP_HDRLEN + data->payloadlen[11]);

  // UDP checksum (16 bits)
  data->udphdr[11].uh_sum = udp4_checksum (data->ip4hdr[11], data->udphdr[11], data->payload[11], data->payloadlen[11]);

  // Free allocated memory.
  free (ip4_flags);

  // Update ethernet frame.
  create_ip4_frame (11, data);

  return (EXIT_SUCCESS);
}
