/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Obtain interface current MTU setting.
int
interface_getmtu (char *interface, GtkWidget *parent, SPSData *data)
{
  int sd, status;
  struct ifreq ifr;

  // Submit request for a socket descriptor to use ioctl().
  if ((sd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "interface_getmtu(): socket() failed to get a socket descriptor for ioctl().\nAppears to be an invalid interface name.\nError message: %s", strerror (status));
    data->parent = parent;
    report_error (data);
    return (0);  // Failed to obtain socket decriptor.
  }

  memset (&ifr, 0, sizeof (ifr));
  strncpy (ifr.ifr_name, interface, IFNAMSIZ - 1);  // 16 - 1 for string termination.

  // Get MTU using SIOCGIFMTU.
  if (ioctl (sd, SIOCGIFMTU, &ifr) < 0) {
    status = errno;
    sprintf (data->error_text, "interface_getmtu(): ioctl() failed to get interface's current MTU.\nAppears to be an invalid interface name.\nError message: %s", strerror (status));
    data->parent = parent;
    report_error (data);
    return (0);  // Failed to obtain interface's current MTU.
  }

  // Close file descriptor.
  close (sd);

  return (ifr.ifr_mtu);
}

// Check if current MTU is sufficiently large to accomodate packet.
// This is driven by size of unfragmentable portion of packet.
int
check_mtu (int type, SPSData *data)
{
  int min;

  // Set parent window for error reporting.
  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // Calculate IPv4 minimum MTU value for specified packet.
  // Use minimum MTU to give best chance of successful packet transmission.
  if ((type == 0) || (type == 1) || (type == 2) || (type == 9) || (type == 10) || (type == 11)) {
    min = min4_mtu (type, data);
    if (change_mtu (type, min, data)) {
      report_mtu_change (type, min, data);
    }

  // Calculate IPv6 minimum MTU value for specified packet.
  // Use minimum MTU to give best chance of successful packet transmission.
  } else if ((type == 3) || (type == 4) || (type == 5) || (type == 12) || (type == 13) || (type == 14)) {
    // IPv6
    min = min6_mtu (type, data);
    if (change_mtu (type, min, data)) {
      report_mtu_change (type, min, data);
    }

    // 6to4
    min = min6to4_mtu (type+3, data);
    change_mtu (type+3, min, data);

  // Calculate 6to4 minimum MTU value for specified packet.
  // Only called as a result of changing MTU on Send page.
  // Use minimum MTU to give best chance of successful packet transmission.
  } else if ((type == 6) || (type == 7) || (type == 8) || (type == 15) || (type == 16) || (type == 17)) {
    min = min6to4_mtu (type, data);
    if (change_mtu (type, min, data)) {
      report_mtu_change (type, min, data);
    }
  }

  return (EXIT_SUCCESS);
}

// Find minimum MTU for IPv4 packet.
int
min4_mtu (int type, SPSData *data)
{
  int unfraglen, fraglen, min;

  // Find length of unfragmentable portion.
  unfraglen = find4_unfraglen (type, data);

  // Find length of fragmentable portion.
  fraglen = find4_fraglen (type, data);

  // Is fragmentation required?

  // Yes
  if ((data->ifmtu[type] - unfraglen - fraglen) < 0) {
    // Minimum fragment is 8 bytes. See Section 2.3 of RFC 791.
    min = unfraglen + 8;

  // No
  } else {
    min = unfraglen + fraglen;
  }

  return (min);
}

// Find minimum MTU for IPv6 packet.
int
min6_mtu (int type, SPSData *data)
{
  int unfraglen, fraglen, min;

  // Find length of unfragmentable portion.
  unfraglen = find6_unfraglen (type, data);

  // Find length of fragmentable portion.
  fraglen = find6_fraglen (type, data);

  // Is fragmentation required?

  // Yes
  if ((data->ifmtu[type] - unfraglen - fraglen) < 0) {
    // Minimum fragment is 8 bytes (<-- this is NOT the fragmentation header). See Section 4.5 of RFC 2460.
    // Fragmentation header will also be needed.
    min = unfraglen + FRG_HDRLEN + 8;

  // No
  } else {
    min = unfraglen + fraglen;  // Don't need to fragment, so no fragmentation header.
  }

  return (min);
}

// Find minimum MTU for 6to4 packet.
int
min6to4_mtu (int type, SPSData *data)
{
  int unfraglen, fraglen, min;

  // Find length of unfragmentable portion.
  unfraglen = find6_unfraglen (type-3, data);

  // Find length of fragmentable portion.
  fraglen = find6_fraglen (type-3, data);

  // Is fragmentation required?

  // Yes, fragmentation is required.
  if ((data->ifmtu[type] - IP4_HDRLEN - unfraglen - fraglen) < 0) {
    // Minimum fragment is 8 bytes (<-- this is NOT the fragmentation header). See Section 4.5 of RFC 2460.
    min = IP4_HDRLEN + unfraglen + FRG_HDRLEN + 8;  // Fragmentation header will be needed.

  // No, fragmentation is not required.
  } else {
    min = IP4_HDRLEN + unfraglen + fraglen;  // Don't need to fragment, so no fragmentation header.
  }

  return (min);
}

// Change maximum transmission unit (MTU).
int
change_mtu (int type, int min, SPSData *data)
{
  // Is current MTU smaller than minimum required for specified packet?
  if (data->ifmtu[type] < min) {

    // If so, revise MTU to accomodate packet size.
    data->ifmtu[type] = min;  // Revise MTU to minimum required for this packet.
    return (1);  // MTU changed.
  }

  return (0);  // MTU not changed.
}

// Report then MTU was changed.
int
report_mtu_change (int type, int min, SPSData *data)
{
  sprintf (data->warning_text, "For specified packet, MTU must be at least %i bytes.\nMTU has been revised to %i bytes.", min, data->ifmtu[type]);
  report_warning (data);

  return (EXIT_SUCCESS);
}
