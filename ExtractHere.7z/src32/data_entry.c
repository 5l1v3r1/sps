/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Data entry for IPv4 header, TCP header, hop-by-hop or destination header options, or other extension header data.
int
data_entry (GtkWidget *entry, int *datlen, int maxdatlen, uint8_t *dat, int dec_hex, GtkWidget *parent, SPSData *data)
{
  int i, j, c, temp2_len;
  const char *entry_text;
  char *temp, *value, **endptr;
  uint8_t *temp2;

  // Allocate memory for various arrays.
  value = allocate_strmem (IP_MAXPACKET);
  temp = allocate_strmem (IP_MAXPACKET);
  temp2 = allocate_ustrmem (IP_MAXPACKET);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Remove any leading spaces.
  strncpy (temp, entry_text, IP_MAXPACKET - 1);  // Minus 1 for string termination.
  i = 0;
  while (temp[i] == ' ') i++;
  j = 0;
  while (temp[i]) {
    temp[j] = temp[i];
    i++;
    j++;
  }
  temp[j] = 0;

  // Test for all adjacent zeros.
  i = 0;
  j = 1;  // Adjacent zeros flag, initially assume all adjacent zeros.
  while (temp[i]) {
    if (temp[i] != '0') {
      j = 0;
      break;
    }
    i++;
  }
  if (j == 1) {  // User entered all adjacent zeros.
    memset (temp, 0, IP_MAXPACKET * sizeof (char));
    strncpy (temp, "0", 1);
  }

  // Set temp2 array length to zero initially.
  temp2_len = 0;

  // If user asked for no data or they entered 0 then zero it out.
  if (strnlen (temp, IP_MAXPACKET) == 0 || ((temp[0] == '0') && strnlen (temp, IP_MAXPACKET) == 1)) {
    memset (dat, 0, maxdatlen * sizeof (uint8_t));
    *datlen = 0;
  
  // Some data was entered.
  } else if (strnlen (temp, IP_MAXPACKET) != 0) {

    if (dec_hex == 0) {  // Decimal input
      // Check for invalid decimal data.
      if (!is_valid_decdata (temp, data)) {
        sprintf (data->error_text, "There seems to be invalid decimal data.\nHere's an example of acceptable data: 23, 4,0,00    ,7");
        data->parent = parent;
        report_error (data);
        free (value);
        free (temp);
        free (temp2);
        return (EXIT_FAILURE);

      // Data is in acceptable format.
      } else {

        // Store values in data array.
        c = 0;  // index for temp2 array
        i = 0;  // index for entry array
        while (i < (int) strnlen (temp, IP_MAXPACKET)) {

          // Grab next decimal value.
          memset (value, 0, IP_MAXPACKET * sizeof (char));
          j = 0;
          while ((temp[i+j] != ' ') && (temp[i+j] != ',') && ((i + j) < (int) strnlen (temp, IP_MAXPACKET))) {
            value[j] = temp[i+j];
            j++;
          }
          i += j;
          // Store values in temp2 array.
          endptr = NULL;
          temp2[c] = (uint8_t) strtol (value, endptr, 10);
          if (endptr != NULL) {
            sprintf (data->error_text, "data_entry(): strtol() failed.\n");
            data->parent = parent;
            report_error (data);
            free (value);
            free (temp);
            free (temp2);
            return (EXIT_FAILURE);
          }
          c++;
          temp2_len++;

          // Increment i until we find more dec values or hit end of string.
          while (((temp[i] == ' ') || (temp[i] == ',')) && (i < (int) strnlen (temp, IP_MAXPACKET))) {
            i++;
          }
        }  // Looping through array temp
      }  // else data is in acceptable format

    } else {  // Hexadecimal input when dec_hex == 1
      // Check for invalid hexadecimal data.
      if (!is_valid_hexdata (temp, data)) {
        sprintf (data->error_text, "There seems to be invalid hexadecimal data.\nHere's an example of acceptable data: 23, 4e,a,cd    ,7");
        data->parent = parent;
        report_error (data);
        free (value);
        free (temp);
        return (EXIT_FAILURE);

      // Data is in acceptable format.
      } else {

        // Store values in data array.
        c = 0;  // index for data array
        i = 0;  // index for entry array
        while (i < (int) strnlen (temp, IP_MAXPACKET)) {

          // Grab next hexadecimal value.
          memset (value, 0, IP_MAXPACKET * sizeof (char));
          j = 0;
          while ((temp[i+j] != ' ') && (temp[i+j] != ',') && ((i + j) < (int) strnlen (temp, IP_MAXPACKET))) {
            value[j] = temp[i+j];
            j++;
          }
          i += j;
          // Convert to base-10 chars and store values in temp2 array.
          endptr = NULL;
          temp2[c] = (uint8_t) strtol (value, endptr, 16);
          if (endptr != NULL) {
            sprintf (data->error_text, "data_entry(): strtol() failed.\n");
            data->parent = parent;
            report_error (data);
            free (value);
            free (temp);
            free (temp2);
            return (EXIT_FAILURE);
          }
          c++;
          temp2_len++;

          // Increment i until we find more hex or hit end of string.
          while (((temp[i] == ' ') || (temp[i] == ',')) && (i < (int) strnlen (temp, IP_MAXPACKET))) {
            i++;
          }
        }  // Looping through array temp
      }  // else data is in acceptable format
    }  // else data is hex

  }  // end if data was entered

  // Set data array and length to zero.
  memset (dat, 0, maxdatlen * sizeof (uint8_t));
  *datlen = 0;

  // New data length based upon text entry contents or limit, whichever is smaller.
  if (temp2_len <= maxdatlen) {
    (*datlen) = temp2_len;
  } else {
    (*datlen) = maxdatlen;
    sprintf (data->warning_text, "Extension header data was truncated\nto accomodate maximum size of %i bytes.", maxdatlen);
    report_warning (data);
  }

  // Copy data to final location.
  memcpy (dat, temp2, (*datlen) * sizeof (uint8_t));

  // Free allocated memory.
  free (value);
  free (temp);
  free (temp2);

  return (EXIT_SUCCESS);
}
