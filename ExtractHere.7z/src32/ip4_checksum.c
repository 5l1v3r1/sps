/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

#define IP4_HDRLEN 20  // IPv4 header length

// Build a buffer containing IPv4 header and IP options and call checksum function.
uint16_t
ip4_checksum (struct ip iphdr, int nopt, int *optlen, unsigned char **options, int pad)
{
  int i, indx;
  char buf[IP_MAXPACKET];

  memset (buf, 0, IP_MAXPACKET);

  indx = 0;

  // Copy IPv4 header into buf (20 bytes)
  memcpy (buf, &iphdr, IP4_HDRLEN);
  indx += IP4_HDRLEN;

  // Copy IP options into buf.
  for (i=0; i<nopt; i++) {
    memcpy (buf + indx, options[i], optlen[i]);
    indx += optlen[i];
  }

  // Pad to the next 32-bit boundary.
  indx += pad;

  return checksum ((uint16_t *) buf, indx);
}
