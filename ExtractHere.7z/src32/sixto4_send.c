/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int flood_mode;  // Flood flag
extern int sending;  // Sending flag for sending finite number of packets

G_LOCK_EXTERN (sending);  // MUTEX for flag indicating packets are being sent

// Send IPv6 packet(s) over IPv4 tunnel (6to4).
// This function will be executed as a separate thread spawned by on_button1_clicked().
int
sixto4_send (SPSData *data)
{
  int status; 
  uint64_t i;  // unsigned 64-bit integer for number of packets to send
  int j, frame, sd_tcp, sd_icmp, sd_udp;
  char *ipaddress, *message;
  const int on = 1;
  struct sockaddr_in tcp_sin, icmp_sin, udp_sin;
  struct sockaddr_ll tcp_device, icmp_device, udp_device;
  Msgdata *msgdata;

  // This state can be changed by on_button5_clicked()
  // as will flood_mode.
  G_LOCK (sending);
  sending = 1;
  G_UNLOCK (sending);

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Grab system date and time.
  memset (message, 0, TEXT_STRINGLEN * sizeof (char));
  message = date_and_time (message, TEXT_STRINGLEN);

  // Display packet activity in Activity Log.
  if (flood_mode) {
    sprintf (message, "%s Flooding ", message);
  } else {
    sprintf (message, "%s Sending ", message);
  }
  if (data->packet_type == 3) {
    sprintf (message, "%sIPv6 TCP ethernet frames over IPv4 tunnel.\n", message);
  } else if (data->packet_type == 4) {
    sprintf (message, "%sIPv6 ICMP ethernet frames over IPv4 tunnel.\n", message);
  } else if (data->packet_type == 5) {
    sprintf (message, "%sIPv6 UDP ethernet frames over IPv4 tunnel.\n", message);
  } else if (data->packet_type == 101) {
    sprintf (message, "%sIPv6 TCP+ICMP+UDP ethernet frames over IPv4 tunnel.\n", message);
  } else {
    fprintf (stderr, "ERROR: Invalid upper layer protocol type %i sixto4_send().\n", data->packet_type);
    free (message);
    exit (EXIT_FAILURE);
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview1;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Make sure all interfaces were specified, if needed.
  if ((data->specify_ether[6] && (((data->packet_type == 3) || (data->packet_type == 101)) &&
       (strnlen (data->ifname[3], TMP_STRINGLEN) < 2))) ||
      (data->specify_ether[7] && ((data->packet_type == 4) || (data->packet_type == 101)) &&
       (strnlen (data->ifname[4], TMP_STRINGLEN) < 2)) ||
      (data->specify_ether[8] && ((data->packet_type == 5) || (data->packet_type == 101)) &&
       (strnlen (data->ifname[5], TMP_STRINGLEN) < 2))) {
    sprintf (data->error_text, "sixto4_send(): Appears to be an invalid interface name.");
    data->parent = data->main_window;
    send_error ();
    free (message);
    free (ipaddress);
    return (EXIT_FAILURE);
  }

  // Resolve interface index.
  memset (&tcp_device, 0, sizeof (tcp_device));
  memset (&icmp_device, 0, sizeof (icmp_device));
  memset (&udp_device, 0, sizeof (udp_device));

  // TCP
  if (data->specify_ether[6] && ((data->packet_type == 3) || (data->packet_type == 101))) {
    if ((tcp_device.sll_ifindex = if_nametoindex (data->ifname[3])) == 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_send(): if_nametoindex() failed to obtain interface index for TCP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // ICMP
  if (data->specify_ether[7] && ((data->packet_type == 4) || (data->packet_type == 101))) {
    if ((icmp_device.sll_ifindex = if_nametoindex (data->ifname[4])) == 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_send(): if_nametoindex() failed to obtain interface index for ICMP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // UDP
  if (data->specify_ether[8] && ((data->packet_type == 5) || (data->packet_type == 101))) {
    if ((udp_device.sll_ifindex = if_nametoindex (data->ifname[5])) == 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_send(): if_nametoindex() failed to obtain interface index for UDP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // Fill out sockaddr_ll.
  tcp_device.sll_family = AF_PACKET;
  memcpy (tcp_device.sll_addr, data->ethhdr[3].src_mac, 6 * sizeof (uint8_t));
  tcp_device.sll_halen = 6u;

  icmp_device.sll_family = AF_PACKET;
  memcpy (icmp_device.sll_addr, data->ethhdr[4].src_mac, 6 * sizeof (uint8_t));
  icmp_device.sll_halen = 6u;

  udp_device.sll_family = AF_PACKET;
  memcpy (udp_device.sll_addr, data->ethhdr[5].src_mac, 6 * sizeof (uint8_t));
  udp_device.sll_halen = 6u;

  // For packets (no ethernet header):
  // The kernel will provide Layer 2 (data link layer) information (MAC addresses).
  // To do that, we need to specify a destination for the kernel in order for it
  // to decide where to send the raw datagram. We fill in a struct in_addr with
  // the desired destination IP address, and pass this structure to the sendto() function.
  // Here, regardless of IPv6 packet type, we're sending to the IPv4 6to4 anycast address
  // which is 192.88.99.1 e.g., see sixto4_tcp6_default ().
  memset (&tcp_sin, 0, sizeof (tcp_sin));
  tcp_sin.sin_family = AF_INET;
  tcp_sin.sin_addr.s_addr = data->ip4hdr[6].ip_dst.s_addr;

  memset (&icmp_sin, 0, sizeof (icmp_sin));
  icmp_sin.sin_family = AF_INET;
  icmp_sin.sin_addr.s_addr = data->ip4hdr[7].ip_dst.s_addr;

  memset (&udp_sin, 0, sizeof (udp_sin));
  udp_sin.sin_family = AF_INET;
  udp_sin.sin_addr.s_addr = data->ip4hdr[8].ip_dst.s_addr;

  i = data->npackets;  // Number of packets to send
  j = 0;               // Number of packets sent

  // Submit request for a raw IPv4 socket descriptor.
  // Separate descriptors for TCP, ICMP, and UDP since we may use difference ethernet headers and interfaces.
  sd_tcp = -1;  // Initially set to invalid socket descriptor.
  sd_icmp = -1;  // Initially set to invalid socket descriptor.
  sd_udp = -1;  // Initially set to invalid socket descriptor.

  // TCP
  if ((data->packet_type == 3) || (data->packet_type == 101)) {
    if (data->specify_ether[6]) {
      if ((sd_tcp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
        status = errno;
        sprintf (data->error_text, "sixto4_send(): socket() failed to get a socket descriptor for TCP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);
      }

    } else {
      if ((sd_tcp = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
        status = errno;
        sprintf (data->error_text, "sixto4_send(): socket() failed to get a socket descriptor for TCP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);

      } else {
        // Set flag so socket expects us to provide IPv4 header.
        if (setsockopt (sd_tcp, IPPROTO_IP, IP_HDRINCL, &on, sizeof (on)) < 0) {
          status = errno;
          sprintf (data->error_text, "sixto4_send(): setsockopt() failed to set IP_HDRINCL for TCP socket.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
    }
  }

  // ICMP
  if ((data->packet_type == 4) || (data->packet_type == 101)) {
    if (data->specify_ether[7]) {
      if ((sd_icmp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
        status = errno;
        sprintf (data->error_text, "sixto4_send(): socket() failed to get a socket descriptor for ICMP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);
      }

    } else {
      if ((sd_icmp = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
        status = errno;
        sprintf (data->error_text, "sixto4_send(): socket() failed to get a socket descriptor for ICMP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);

      } else {
        // Set flag so socket expects us to provide IPv4 header.
        if (setsockopt (sd_icmp, IPPROTO_IP, IP_HDRINCL, &on, sizeof (on)) < 0) {
          status = errno;
          sprintf (data->error_text, "sixto4_send(): setsockopt() failed to set IP_HDRINCL for ICMP socket.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
    }
  }

  // UDP
  if ((data->packet_type == 5) || (data->packet_type == 101)) {
    if (data->specify_ether[8]) {
      if ((sd_udp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
        status = errno;
        sprintf (data->error_text, "sixto4_send(): socket() failed to get a socket descriptor for UDP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);
      }

    } else {
      if ((sd_udp = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
        status = errno;
        sprintf (data->error_text, "sixto4_send(): socket() failed to get a socket descriptor for UDP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);

      } else {
        // Set flag so socket expects us to provide IPv4 header.
        if (setsockopt (sd_udp, IPPROTO_IP, IP_HDRINCL, &on, sizeof (on)) < 0) {
          status = errno;
          sprintf (data->error_text, "sixto4_send(): setsockopt() failed to set IP_HDRINCL for UDP socket.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
    }
  }

  // Send TCP packet(s).
  if (data->packet_type == 3) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[6]; frame++) {

        if (data->specify_ether[6]) {

          if ((sendto (sd_tcp, data->ether_frame[6][frame], data->frame_length[6][frame], 0, (struct sockaddr *) &tcp_device, sizeof (tcp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_tcp, data->ether_frame[6][frame] + ETH_HDRLEN, data->frame_length[6][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &tcp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_tcp6to4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[6].ip_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized TCP source IPv4 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source IPv6 address if requested.
      if (data->ran_tcp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[3].ip6_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized TCP source IPv6 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_tcp6_sourceport) {
        data->tcphdr[3].th_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate IPv4 and upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // TCP header checksum (16 bits)
      data->tcphdr[3].th_sum = tcp6_checksum (data->ip6hdr[3], data->tcphdr[3], data->tcp_nopt[3], data->tcp_opt_totlen[3], data->tcp_optlen[3], data->tcp_options[3], data->tcp_optpadlen[3], data->payload[3], data->payloadlen[3]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[6].ip_sum = 0;
      data->ip4hdr[6].ip_sum = checksum ((uint16_t *) &data->ip4hdr[6], IP4_HDRLEN);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frame.
      create_ip6_frame (3, data);
      create_6to4_frame (6, data);
    }

  // Send ICMP packet(s)
  } else if (data->packet_type == 4) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[7]; frame++) {

        if (data->specify_ether[7]) {

          if ((sendto (sd_icmp, data->ether_frame[7][frame], data->frame_length[7][frame], 0, (struct sockaddr *) &icmp_device, sizeof (icmp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_icmp, data->ether_frame[7][frame] + ETH_HDRLEN, data->frame_length[7][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &icmp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_icmp6to4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[7].ip_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized ICMP source IPv4 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source IPv6 address if requested.
      if (data->ran_icmp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[4].ip6_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized ICMP source IPv6 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Re-calculate IPv4 and upper layer protocol checksum.
      // ICMPv6 header checksum (16 bits)
      data->icmp6hdr[4].icmp6_cksum = icmp6_checksum (data->ip6hdr[4], data->icmp6hdr[4], data->payload[4], data->payloadlen[4]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[7].ip_sum = 0;
      data->ip4hdr[7].ip_sum = checksum ((uint16_t *) &data->ip4hdr[7], IP4_HDRLEN);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frame.
      create_ip6_frame (4, data);
      create_6to4_frame (7, data);
    }

  // Send UDP packet(s).
  } else if (data->packet_type == 5) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[8]; frame++) {

        if (data->specify_ether[8]) {

          if ((sendto (sd_udp, data->ether_frame[8][frame], data->frame_length[8][frame], 0, (struct sockaddr *) &udp_device, sizeof (udp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_udp, data->ether_frame[8][frame] + ETH_HDRLEN, data->frame_length[8][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &udp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_udp6to4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[8].ip_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized UDP source IPv4 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source IPv6 address if requested.
      if (data->ran_udp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[5].ip6_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized UDP source IPv6 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_udp6_sourceport) {
        data->udphdr[5].uh_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate IPv4 and upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // UDP header checksum (16 bits)
      data->udphdr[5].uh_sum = udp6_checksum (data->ip6hdr[5], data->udphdr[5], data->payload[5], data->payloadlen[5]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[8].ip_sum = 0;
      data->ip4hdr[8].ip_sum = checksum ((uint16_t *) &data->ip4hdr[8], IP4_HDRLEN);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frame.
      create_ip6_frame (5, data);
      create_6to4_frame (8, data);
    }

  // Send all packet types.
  } else if (data->packet_type == 101) {

    while ((i > 0ull) && sending) {

      // Send TCP packet.
      for (frame=0; frame<data->nframes[6]; frame++) {

        if (data->specify_ether[6]) {

          if ((sendto (sd_tcp, data->ether_frame[6][frame], data->frame_length[6][frame], 0, (struct sockaddr *) &tcp_device, sizeof (tcp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_tcp, data->ether_frame[6][frame] + ETH_HDRLEN, data->frame_length[6][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &tcp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      // Send ICMP packet.
      for (frame=0; frame<data->nframes[7]; frame++) {

        if (data->specify_ether[7]) {

          if ((sendto (sd_icmp, data->ether_frame[7][frame], data->frame_length[7][frame], 0, (struct sockaddr *) &icmp_device, sizeof (icmp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_icmp, data->ether_frame[7][frame] + ETH_HDRLEN, data->frame_length[7][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &icmp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      // Send UDP packet.
      for (frame=0; frame<data->nframes[8]; frame++) {

        if (data->specify_ether[8]) {

          if ((sendto (sd_udp, data->ether_frame[8][frame], data->frame_length[8][frame], 0, (struct sockaddr *) &udp_device, sizeof (udp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_udp, data->ether_frame[8][frame] + ETH_HDRLEN, data->frame_length[8][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &udp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "sixto4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }
      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_tcp6to4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[6].ip_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized TCP source IPv4 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_icmp6to4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[7].ip_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized ICMP source IPv4 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_udp6to4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[8].ip_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized UDP source IPv4 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source IPv6 address if requested.
      if (data->ran_tcp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[3].ip6_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized TCP source IPv6 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_icmp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[4].ip6_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized ICMP source IPv6 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_udp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[5].ip6_src)) != 1) {
          sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized UDP source IPv6 address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_tcp6_sourceport) {
        data->tcphdr[3].th_sport = htons (ran16_0to65535 (data));
      }
      if (data->ran_udp6_sourceport) {
        data->udphdr[5].uh_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate IPv4 and upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // Upper layer protocol header checksum (16 bits)
      data->tcphdr[3].th_sum = tcp6_checksum (data->ip6hdr[3], data->tcphdr[3], data->tcp_nopt[3], data->tcp_opt_totlen[3], data->tcp_optlen[3], data->tcp_options[3], data->tcp_optpadlen[3], data->payload[3], data->payloadlen[3]);
      data->icmp6hdr[4].icmp6_cksum = icmp6_checksum (data->ip6hdr[4], data->icmp6hdr[4], data->payload[4], data->payloadlen[4]);
      data->udphdr[5].uh_sum = udp6_checksum (data->ip6hdr[5], data->udphdr[5], data->payload[5], data->payloadlen[5]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[6].ip_sum = 0;
      data->ip4hdr[6].ip_sum = checksum ((uint16_t *) &data->ip4hdr[6], IP4_HDRLEN);
      data->ip4hdr[7].ip_sum = 0;
      data->ip4hdr[7].ip_sum = checksum ((uint16_t *) &data->ip4hdr[7], IP4_HDRLEN);
      data->ip4hdr[8].ip_sum = 0;
      data->ip4hdr[8].ip_sum = checksum ((uint16_t *) &data->ip4hdr[8], IP4_HDRLEN);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));
      memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));
      memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (3, data);
      create_6to4_frame (6, data);
      create_ip6_frame (4, data);
      create_6to4_frame (7, data);
      create_ip6_frame (5, data);
      create_6to4_frame (8, data);
    }

    // Close appropriate socket descriptors.
    if ((data->packet_type == 3) || (data->packet_type == 101)) {
      close (sd_tcp);
    } else if ((data->packet_type == 4) || (data->packet_type == 101)) {
      close (sd_icmp);
    } else if ((data->packet_type == 5) || (data->packet_type == 101)) {
      close (sd_udp);
    }
  }

  // Display packet activity in Activity Log.
  memset (message, 0, TEXT_STRINGLEN * sizeof (char));
  if (data->packet_type == 3) {
    sprintf (message, "%i IPv6 TCP ethernet frames (%i packets) sent over IPv4 tunnel.\n", j * data->nframes[6], j);
  } else if (data->packet_type == 4) {
    sprintf (message, "%i IPv6 ICMP ethernet frames (%i packets) sent over IPv4 tunnel.\n", j * data->nframes[7], j);
  } else if (data->packet_type == 5) {
    sprintf (message, "%i IPv6 UDP ethernet frames (%i packets) sent over IPv4 tunnel.\n", j * data->nframes[8], j);
  } else if (data->packet_type == 101) {
    sprintf (message, "%i IPv6 TCP+ICMP+UDP packets sent over IPv4 tunnel.\n", j);
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview1;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Have idle function update source IPv6 addresses and source ports, which may have changed if randomized during send.
  g_idle_add ((GSourceFunc) update_ip6_sources, data);

  // Have idle function update source 6to4 IPv4 addresses, which may have changed if randomized during send.
  g_idle_add ((GSourceFunc) update_6to4_sources, data);

  // Free allocated memory.
  free (ipaddress);
  free (message);

  return (EXIT_SUCCESS);
}

// Idle function to update source 6to4 IPv4 addresses, which may have changed if randomized during send.
// This idle function returns 0 in order to stop.
int
update_6to4_sources (SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP source 6to4 IPv4 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET, &(data->ip4hdr[6].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for TCP source 6to4 IPv4 address in update_6to4_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry125), value);

  // ICMP source 6to4 IPv4 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET, &(data->ip4hdr[7].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for ICMP source 6to4 IPv4 address in update_6to4_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry160), value);

  // UDP source 6to4 IPv4 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET, &(data->ip4hdr[8].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for UDP source 6to4 IPv4 address in update_6to4_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry161), value);

  // Free allocated memory.
  free (value);

  return (0);  // This idle function stops when it returns a value of zero.
}
