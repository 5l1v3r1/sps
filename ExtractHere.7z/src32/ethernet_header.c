/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Check for valid link-layer (MAC) address (48 bits) and process.
int
mac_entry (GtkWidget *entry, uint8_t *mac, int type, SPSData *data)
{
  int i, bad;
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is new value in appropriate form?

  // Check length
  bad = 0;
  if (strnlen (entry_text, 17) != 17) {
    bad = 1;
  }

  // Check for colons
  i = 2;
  while (i < 17) {
    if (entry_text[i] != ':') {
      bad = 1;
    }
    i += 3;
  }

  // Check for valid hexadecimals
  i = 0;
  while (i < 17) {
    if (!(((entry_text[i] > 47) && (entry_text[i] < 58)) ||    // 0 to 10
        ((entry_text[i] > 64) && (entry_text[i] < 71)) ||      // A to Z
        ((entry_text[i] > 96) && (entry_text[i] < 103)))) {    // a to z
      bad = 1;
    }
    i++;
    if (!(((entry_text[i] > 47) && (entry_text[i] < 58)) ||    // 0 to 10
        ((entry_text[i] > 64) && (entry_text[i] < 71)) ||      // A to Z
        ((entry_text[i] > 96) && (entry_text[i] < 103)))) {    // a to z
      bad = 1;
    }
    i += 2;
  }
  if (bad) {
    mac_bin2string (mac, value);
    gtk_entry_set_text (GTK_ENTRY (entry), value);
  } else {
    // Seems ok, so keep it.
    mac_string2bin ((char *) entry_text, mac);

    // Update ethernet frames.
    if ((type == 0) || (type == 1) || (type == 2) ||
      (type == 9) || (type == 10) || (type == 11)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 4) || (type == 5) ||
      (type == 12) || (type == 13) || (type == 14)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Find link-layer (MAC) address for given interface name.
int
ifname_entry (GtkWidget *entry, char *ifname, uint8_t *mac, GtkWidget *mac_entry, int type, SPSData *data)
{
  int old;
  const char *entry_text;
  char *text;

  // Array for error messages.
  text = allocate_strmem (TEXT_STRINGLEN);

  // Get new name from text entry.
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Set parent window for reporting error messages.
  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // Check for bad interface name.
  if ((mac = interface_getmac ((char *) entry_text, mac, data->parent, data)) == NULL) {
    free (text);
    return (EXIT_FAILURE);
  }

  // Obtain interface's current MTU.
  old = data->ifmtu[type];  // Save current value
  if ((data->ifmtu[type] = interface_getmtu ((char *) entry_text, data->parent, data)) == 0) {
    data->ifmtu[type] = old;  // Restore previous value.
    free (text);
    return (EXIT_FAILURE);

  } else {
    // Check if MTU is sufficiently large to accomodate packet. If not, revise.
    check_mtu (type, data);
  }

  // Update interface name.
  memset (ifname, 0, TMP_STRINGLEN * sizeof (char));
  strncpy (ifname, entry_text, TMP_STRINGLEN - 1);  // Minus 1 for string termination.

  // Update source MAC address
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  mac_bin2string (mac, text);
  gtk_entry_set_text (GTK_ENTRY (mac_entry), text);

  // Update ethernet frames.
  if ((type == 0) || (type == 1) || (type == 2) ||
    (type == 9) || (type == 10) || (type == 11)) {
    create_ip4_frame (type, data);

  } else if ((type == 3) || (type == 4) || (type == 5) ||
    (type == 12) || (type == 13) || (type == 14)) {
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (text);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
ethtype_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535u)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[type].type_code));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ethhdr[type].type_code = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ethernet header with new value

    // Update ethernet frames.
    if ((type == 0) || (type == 1) || (type == 2) ||
      (type == 9) || (type == 10) || (type = 11)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 4) || (type == 5) ||
      (type == 12) || (type == 13) || (type == 14)) {
      // Update ethernet type code in 6to4 ethernet header, since create_6to4_frame() doesn't copy it.
      data->ethhdr[type + 3].type_code = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));
      // Update ethernet frames.
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Convert link-layer (MAC) address from binary to colon-separated string.
int
mac_bin2string (unsigned char *mac, char *string)
{
  int i;

  // NOTE: we assume string was set to zero prior to call to this function.

  for (i=0; i<5; i++) {
    sprintf (string, "%s%02x:", string, mac[i]);
  }
  sprintf (string, "%s%02x", string, mac[5]);

  return (EXIT_SUCCESS);
}

// Convert link-layer (MAC) address from colon-separated string to binary.
int
mac_string2bin (char *string, uint8_t *mac)
{
  unsigned int a, b, c, d, e, f;

  sscanf (string, "%02x:%02x:%02x:%02x:%02x:%02x", &a, &b, &c, &d, &e, &f);

  mac[0] = a;
  mac[1] = b;
  mac[2] = c;
  mac[3] = d;
  mac[4] = e;
  mac[5] = f;

  return (EXIT_SUCCESS);
}
