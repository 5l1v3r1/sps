/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Routing extension header editing window
int
route_win (SPSData *data)
{
  GtkBuilder *builder;
  GError *error = NULL;

  // If routing window is already open, return with no action.
  if (data->route_flag) {
    return (EXIT_FAILURE);
  } else {
    data->route_flag = 1;
  }

  // Create new GtkBuilder object.
  builder = gtk_builder_new();
  if (!gtk_builder_add_from_file (builder, "routing.ui", &error)) {
    g_warning ("%s", error->message);
    g_free (error);
    exit (EXIT_FAILURE);
  }

  // Get objects from UI file
  data->route_window = GTK_WIDGET (gtk_builder_get_object (builder, "route_window"));

  data->button145 = GTK_BUTTON (gtk_builder_get_object (builder, "button145"));  // Toggle: attach / detach a routing header
  data->textview50 = GTK_WIDGET (gtk_builder_get_object (builder, "textview50"));  // Status: attached / detached
  data->entry446 = GTK_WIDGET (gtk_builder_get_object (builder, "entry446"));  // Header length
  data->entry447 = GTK_WIDGET (gtk_builder_get_object (builder, "entry447"));  // Routing type
  data->entry448 = GTK_WIDGET (gtk_builder_get_object (builder, "entry448"));  // Segments left
  data->radiobutton73 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton73"));  // Decimal routing data entry
  data->radiobutton74 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton74"));  // Hexadecimal routing data entry
  data->entry449 = GTK_WIDGET (gtk_builder_get_object (builder, "entry449"));  // Routing data
  data->button125 = GTK_BUTTON (gtk_builder_get_object (builder, "button125"));  // Load ICV from file ...

  // Connect signals.
  gtk_builder_connect_signals (builder, data);

  // Destroy builder, since we don't need it anymore.
  g_object_unref (G_OBJECT (builder));

  // Show window. All other widgets are automatically shown by GtkBuilder.
  gtk_widget_show (data->route_window);

  // Populate/set widgets in routing header editing window.
  route_show (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Populate route_window with contents of selected routing header.
int
route_show (int type, SPSData *data)
{
  int i, c, val;
  char *temp, *value;
  GtkTextBuffer *textbuffer50;

  // Strings to hold miscellaneous calculated values
  temp = allocate_strmem (TMP_STRINGLEN);
  value = allocate_strmem (IP_MAXPACKET);

  // Flag indicating a routing header
  textbuffer50 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview50));
  if (data->route_hdr_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer50, "Attached", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer50, "Not Attached", -1);
  }

  // Decimal or hexadecimal routing data entry
  val = data->dec_hex_route;
  if (val == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton73), FALSE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton73), TRUE);
  }
  // Variable data->dec_hex_route will be changed by on_radiobutton73_toggled(), so set it now.
  data->dec_hex_route = val;

  // Header length
  sprintf (value, "%" PRIu8, (uint8_t) data->routehdr[type].hdr_len);
  gtk_entry_set_text (GTK_ENTRY (data->entry446), value);

  // Routing type
  sprintf (value, "%" PRIu8, (uint8_t) data->routehdr[type].routing_type);
  gtk_entry_set_text (GTK_ENTRY (data->entry447), value);

  // Segments left
  sprintf (value, "%" PRIu8, (uint8_t) data->routehdr[type].segs_left);
  gtk_entry_set_text (GTK_ENTRY (data->entry448), value);

  // Routing data
  // NOTE: Always displays in decimal.
  memset (value, 0, IP_MAXPACKET * sizeof (char));
  c = 0;
  for (i=0; i<data->route_datlen[type]; i++) {
    sprintf (temp, "%" PRIu8, (uint8_t) data->route_data[type][i]);
    strncpy (value + c, temp, IP_MAXPACKET - c - 1);  // Minus 1 for string termination.
    c += strnlen (temp, TMP_STRINGLEN);
    if (i != (data->route_datlen[type] - 1)) {  // There's more values to come.
      sprintf (value, "%s, ", value);  // Add a comma and space.
      c += 2;
    }
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry449), value);

  // Free allocated memory.
  free (temp);
  free (value);

  return (EXIT_SUCCESS);
}

// Update routing header length.
int
update_route_len (int type, SPSData *data)
{
  // Length of routing header (8-byte units), excluding first 8 bytes
  // Section 4.4 of RFC 2460
  // If routing data is >= 4 bytes, then we have 8+ in total; RTE_HDRLEN = 4, so subtract 4 from data, for a total subtraction of 8.
  if (data->route_datlen[type] >= 4 ) {
    data->routehdr[type].hdr_len = ((data->route_datlen[type] - 4u) / 8u);  // Don't count 1st 4 bytes of routing data.
  } else {
    data->routehdr[type].hdr_len = 0u;
  }

  return (EXIT_SUCCESS);
}
