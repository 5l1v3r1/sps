/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Allocate memory for an array of chars.
char *
allocate_strmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_strmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (char *) malloc (len * sizeof (char));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (char));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_strmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of chars.
char **
allocate_strmemp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_strmemp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (char **) malloc (len * sizeof (char *));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (char *));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_strmemp().\n");
    exit (EXIT_FAILURE);
  }
}

// Reallocate memory for an array of chars. Do not clear contents.
char *
reallocate_strmem (char *tmp, int len)
{
  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot reallocate memory because len = %i in reallocate_strmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (char *) realloc (tmp, len * sizeof (char));
  if (tmp != NULL) {
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot reallocate memory for array in reallocate_strmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of unsigned chars.
uint8_t *
allocate_ustrmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t *) malloc (len * sizeof (uint8_t));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of unsigned chars.
uint8_t **
allocate_ustrmemp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmemp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t **) malloc (len * sizeof (uint8_t *));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t *));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmemp().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of pointers to arrays of unsigned chars.
uint8_t ***
allocate_ustrmempp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmempp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t ***) malloc (len * sizeof (uint8_t **));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t **));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmempp().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of pointers to arrays of pointers to arrays of unsigned chars.
uint8_t ****
allocate_ustrmemppp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmemppp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t ****) malloc (len * sizeof (uint8_t ***));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t ***));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmemppp().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of unsigned short ints.
uint16_t *
allocate_u2strmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_u2strmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint16_t *) malloc (len * sizeof (uint16_t));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint16_t));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_u2strmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of ints.
int *
allocate_intmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_intmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (int *) malloc (len * sizeof (int));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (int));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_intmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of pointers to arrays of ints.
int **
allocate_intmemp (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_intmemp().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (int **) malloc (len * sizeof (int *));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (int *));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_intmemp().\n");
    exit (EXIT_FAILURE);
  }
}

// Check if number of frames has changed and re-allocate memory as necessary.
// Not IP version-specific.
int
nframes_change (int old_nframes, int type, SPSData *data)
{
  int i;
  void *tmp;

  if (old_nframes != data->nframes[type]) {

    // Free memory currently reserved for ethernet frames of this packet.
    for (i=0; i<old_nframes; i++) {
      free (data->ether_frame[type][i]);
    }

    // Re-allocate memory to accomodate new ethernet frames.
    tmp = (uint8_t **) realloc (data->ether_frame[type], data->nframes[type] * sizeof (uint8_t *));
    if (tmp != NULL) {
      memset (tmp, 0, data->nframes[type] * sizeof (uint8_t *));
      data->ether_frame[type] = tmp;
    } else {
      fprintf (stderr, "ERROR: Cannot reallocate memory for array 'ether_frame' in nframes_change().\n");
      exit (EXIT_FAILURE);
    }
    for (i=0; i<data->nframes[type]; i++) {
      data->ether_frame[type][i] = allocate_ustrmem (IP_MAXPACKET + ETH_HDRLEN);
    }
  }

  return (EXIT_SUCCESS);
}

// Allocate memory for an array of ethernet headers.
Ethhdr *
allocate_ethhdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ethhdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Ethhdr *) malloc (len * sizeof (Ethhdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Ethhdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ethhdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of IPv4 headers.
struct ip *
allocate_ip4hdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ip4hdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (struct ip *) malloc (len * sizeof (struct ip));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (struct ip));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ip4hdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of IPv6 headers.
struct ip6_hdr *
allocate_ip6hdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ip6hdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (struct ip6_hdr *) malloc (len * sizeof (struct ip6_hdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (struct ip6_hdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ip6hdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of hop-by-hop or destination extension headers, excluding options.
Hopdst_hdr *
allocate_hopdsthdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_hopdsthdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Hopdst_hdr *) malloc (len * sizeof (Hopdst_hdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Hopdst_hdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_hopdsthdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of routing extension headers.
Route_hdr *
allocate_routehdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_routehdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Route_hdr *) malloc (len * sizeof (Route_hdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Route_hdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_routehdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of authentication extension headers.
Auth_hdr *
allocate_authhdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_authhdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Auth_hdr *) malloc (len * sizeof (Auth_hdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Auth_hdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_authhdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of encapsulating security payload (ESP) extension headers.
Esp_hdr *
allocate_esphdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_esphdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Esp_hdr *) malloc (len * sizeof (Esp_hdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Esp_hdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_esphdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of encapsulating security payload (ESP) trailers.
Esp_tail *
allocate_esptail (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_esptail().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Esp_tail *) malloc (len * sizeof (Esp_tail));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Esp_tail));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_esptail().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of TCP headers.
struct tcphdr *
allocate_tcphdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_tcphdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (struct tcphdr *) malloc (len * sizeof (struct tcphdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (struct tcphdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_tcphdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of IPv4 ICMP headers.
struct icmp *
allocate_icmp4hdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_icmp4hdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (struct icmp *) malloc (len * sizeof (struct icmp));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (struct icmp));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_icmp4hdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of IPv6 ICMP headers.
struct icmp6_hdr *
allocate_icmp6hdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_icmp6hdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (struct icmp6_hdr *) malloc (len * sizeof (struct icmp6_hdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (struct icmp6_hdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_icmp6hdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of UDP headers.
struct udphdr *
allocate_udphdr (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_udphdr().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (struct udphdr *) malloc (len * sizeof (struct udphdr));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (struct udphdr));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_udphdr().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of Msgdata structs.
Msgdata *
allocate_msgdata (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_msgdata().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (Msgdata *) malloc (len * sizeof (Msgdata));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (Msgdata));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_msgdata().\n");
    exit (EXIT_FAILURE);
  }
}
