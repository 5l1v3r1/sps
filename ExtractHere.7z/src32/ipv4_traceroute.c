/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()
extern int tracing;  // Flag to indicate a traceroute thread is active

G_LOCK_EXTERN (message_available);  // Obtain a MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen().
G_LOCK_EXTERN (tracing);  // Obtain a MUTEX for flag indicating a traceroute thread is active.

// Start an IPv4 traceroute.
// This function will be executed as a separate thread on_button24_clicked.
int
ipv4_tr_send (SPSData *data)
{
  int status, frame, sendsd, recsd, probes;
  int bytes, timeout, node, trylim, trycount, done;
  char *src_ip, *dst_ip, *rec_ip;
  char hostname[NI_MAXHOST], *message;
  struct ip *iphdr;
  struct tcphdr *tcphdr;
  struct icmp *icmphdr;
  uint8_t *rec_ether_frame;
  struct sockaddr_in sa, sin;
  struct sockaddr from;
  struct sockaddr_ll device;
  socklen_t fromlen;
  struct timezone tz;
  struct timeval wait, t1, t2;
  double dt;
  Msgdata *msgdata;

  // Allocate memory for various arrays.
  rec_ip = allocate_strmem (INET_ADDRSTRLEN);
  rec_ether_frame = allocate_ustrmem (IP_MAXPACKET);
  src_ip = allocate_strmem (INET_ADDRSTRLEN);
  dst_ip = allocate_strmem (INET_ADDRSTRLEN);

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Make sure all interface names were specified.
  if (((data->packet_type_tr == 9) && data->specify_ether[9] &&
       (strnlen (data->ifname[9], TMP_STRINGLEN) < 2)) ||
      ((data->packet_type_tr == 10) && data->specify_ether[10] &&
       (strnlen (data->ifname[10], TMP_STRINGLEN) < 2)) ||
      ((data->packet_type_tr == 11) && data->specify_ether[11] &&
       (strnlen (data->ifname[11], TMP_STRINGLEN) < 2))) {
    sprintf (data->error_text, "ipv4_tr_send(): Appears to be an invalid interface name.");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Fill out sockaddr_ll struct.
  memset (&device, 0, sizeof (device));
  device.sll_family = AF_PACKET;  // Address family
  device.sll_halen = 6u;  // Length of address

  // Set source MAC address and resolve interface index from interface name.
  if ((data->packet_type_tr == 9) && data->specify_ether[9]) {
    memcpy (device.sll_addr, data->ethhdr[9].src_mac, 6 * sizeof (uint8_t));
    if ((device.sll_ifindex = if_nametoindex (data->ifname[9])) == 0) {
      status = errno;
    }
  } else if ((data->packet_type_tr == 10) && data->specify_ether[10]) {
    memcpy (device.sll_addr, data->ethhdr[10].src_mac, 6 * sizeof (uint8_t));
    if ((device.sll_ifindex = if_nametoindex (data->ifname[10])) == 0) {
      status = errno;
    }
  } else if ((data->packet_type_tr == 11) && data->specify_ether[11]) {
    memcpy (device.sll_addr, data->ethhdr[11].src_mac, 6 * sizeof (uint8_t));
    if ((device.sll_ifindex = if_nametoindex (data->ifname[11])) == 0) {
      status = errno;
    }
  } else {
    fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ipv4_tr_send().\n", data->packet_type_tr);
    free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    exit (EXIT_FAILURE);
  }
  if (device.sll_ifindex == 0) {
    sprintf (data->error_text, "ipv4_tr_send(): if_nametoindex() failed to obtain interface index.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // For packets (no ethernet header):
  // The kernel will provide Layer 2 (data link layer) information (MAC addresses).
  // To do that, we need to specify a destination for the kernel in order for it
  // to decide where to send the raw datagram. We fill in a struct in_addr with
  // the desired destination IP address, and pass this structure to the sendto() function.
  memset (&sin, 0, sizeof (sin));
  sin.sin_family = AF_INET;
  if (data->packet_type_tr == 9) {
    sin.sin_addr.s_addr = data->ip4hdr[9].ip_dst.s_addr;
  } else if (data->packet_type_tr == 10) {
    sin.sin_addr.s_addr = data->ip4hdr[10].ip_dst.s_addr;
  } else if (data->packet_type_tr == 11) {
    sin.sin_addr.s_addr = data->ip4hdr[11].ip_dst.s_addr;
  }

  // Grab system date and time.
  message = date_and_time (message, TEXT_STRINGLEN);

  // Show target of traceroute.
  memset (&sa, 0, sizeof (sa));
  sa.sin_family = AF_INET;
  if (data->packet_type_tr == 9) {
    if (inet_ntop (AF_INET, &(data->ip4hdr[9].ip_dst.s_addr), dst_ip, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ipv4_tr_send(): inet_ntop() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  } else if (data->packet_type_tr == 10) {
    if (inet_ntop (AF_INET, &(data->ip4hdr[10].ip_dst.s_addr), dst_ip, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ipv4_tr_send(): inet_ntop() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  } else if (data->packet_type_tr == 11) {
    if (inet_ntop (AF_INET, &(data->ip4hdr[11].ip_dst.s_addr), dst_ip, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ipv4_tr_send(): inet_ntop() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  }
  if ((status = inet_pton (AF_INET, dst_ip, &sa.sin_addr)) != 1) {  // Load sa with sock address info.
    sprintf (data->error_text, "ipv4_tr_send(): inet_pton() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  if (data->resolve_tr) {
    if ((status = getnameinfo ((struct sockaddr*)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
      sprintf (data->error_text, "ipv4_tr_send(): getnameinfo() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
    if (data->packet_type_tr == 9) {
      sprintf (message, "%s TCP (IPv4) traceroute to %s (%s) port %i\n", message, dst_ip, hostname, ntohs (data->tcphdr[9].th_dport));
    } else if (data->packet_type_tr == 10) {
      sprintf (message, "%s ICMP (IPv4) traceroute to %s (%s)\n", message, dst_ip, hostname);
    } else if (data->packet_type_tr == 11) {
      sprintf (message, "%s UDP (IPv4) traceroute to %s (%s) port %i\n", message, dst_ip, hostname, ntohs (data->udphdr[11].uh_dport));
    }
  } else {
    if (data->packet_type_tr == 9) {
      sprintf (message, "%s TCP (IPv4) traceroute to %s port %i\n", message, dst_ip, ntohs (data->tcphdr[9].th_dport));
    } else if (data->packet_type_tr == 10) {
      sprintf (message, "%s ICMP (IPv4) traceroute to %s\n", message, dst_ip);
    } else if (data->packet_type_tr == 11) {
      sprintf (message, "%s UDP (IPv4) traceroute to %s port %i\n", message, dst_ip, ntohs (data->udphdr[11].uh_dport));
    }
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview7;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Submit request for raw socket descriptors - one to send, one to receive.
  if (((data->packet_type_tr == 9) && data->specify_ether[9]) ||
      ((data->packet_type_tr == 10) && data->specify_ether[10]) ||
      ((data->packet_type_tr == 11) && data->specify_ether[11])) {
    if ((sendsd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
      status = errno;
      sprintf (data->error_text, "ipv4_tr_send(): socket() failed to get a socket descriptor for sending.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  } else {
    if ((sendsd = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
      status = errno;
      sprintf (data->error_text, "ipv4_tr_send(): socket() failed to get a socket descriptor for sending.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  }

  if ((recsd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "ipv4_tr_send(): socket() failed to get a socket descriptor for receiving.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Set maximum number of tries for a host before incrementing TTL and moving on.
  trylim = 3;

  // Set pointer to IPv4 header within received ethernet frame.
  iphdr = (struct ip *) (rec_ether_frame + ETH_HDRLEN);

  // SEND LOOP
  // Loop incrementing TTL each time, exiting when we get our target IP address.
  done = 0;
  trycount = 0;
  node = 1;
  probes = 0;

  for (;;) {

    if (!tracing) {  // Break out of Send loop if Stop button was pressed.
      done = 2;
      break;
    }

    // Set time-to-live and update ethernet frames.
    data->ip4hdr[data->packet_type_tr].ip_ttl = node;
    create_ip4_frame (data->packet_type_tr, data);

    // Send ethernet frame.
    bytes = -1;  // Initially set to failure value.
    if (((data->packet_type_tr == 9) && data->specify_ether[9]) ||
        ((data->packet_type_tr == 10) && data->specify_ether[10]) ||
        ((data->packet_type_tr == 11) && data->specify_ether[11])) {

      for (frame=0; frame<data->nframes[data->packet_type_tr]; frame++) {

        if ((bytes = sendto (sendsd, data->ether_frame[data->packet_type_tr][frame], data->frame_length[data->packet_type_tr][frame], 0, (struct sockaddr *) &device, sizeof (device))) <= 0) {
          status = errno;
        }
      }

    // Send a packet (no ethernet header) to socket.
    } else {
      for (frame=0; frame<data->nframes[data->packet_type_tr]; frame++) {
        if ((bytes = sendto (sendsd, data->ether_frame[data->packet_type_tr][frame] + ETH_HDRLEN, data->frame_length[data->packet_type_tr][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &sin, sizeof (sin))) <= 0) {
          status = errno;
        }
      }
    }
    if (bytes <= 0) {
      sprintf (data->error_text, "ipv4_tr_send(): sendto() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }

    probes++;

    // Start timer.
    (void) gettimeofday (&t1, &tz);

    // Set time for the socket to timeout and give up waiting for a reply.
    timeout = data->timeout_tr;
    wait.tv_sec  = timeout;  
    wait.tv_usec = 0;
    if (setsockopt (recsd, SOL_SOCKET, SO_RCVTIMEO, (char *) &wait, sizeof (struct timeval)) < 0) {
      status = errno;
      sprintf (data->error_text, "ipv4_tr_send(): setsockopt() failed to set timeout.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }

    // Listen for incoming ethernet frame from socket sd.
    // We expect an ICMP ethernet frame of the form:
    //     MAC (6 bytes) + MAC (6 bytes) + ethernet type (2 bytes)
    //     + ethernet data (IP header + ICMP header + IP header + TCP/ICMP/UDP header)
    // Keep at it for data->timeout seconds, or until we get an ICMP reply.

    // RECEIVE LOOP
    for (;;) {

      memset (rec_ether_frame, 0, IP_MAXPACKET * sizeof (uint8_t));
      memset (&from, 0, sizeof (from));
      fromlen = sizeof (from);
      if ((bytes = recvfrom (recsd, rec_ether_frame, IP_MAXPACKET, 0, (struct sockaddr *) &from, &fromlen)) < 0) {

        status = errno;

        // Deal with error conditions first.
        if (status == EAGAIN) {  // EAGAIN = 11
          memset (message, 0, TEXT_STRINGLEN * sizeof (char));
          sprintf (message, "  %i No reply within %i seconds.\n", node, timeout);
          msgdata = allocate_msgdata (1);
          msgdata->textview = data->textview7;
          g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
          trycount++;
          break;  // Break out of Receive loop.
        } else if (status == EINTR) {  // EINTR = 4
          continue;  // Something weird happened, but let's keep listening.
        } else {
          sprintf (data->error_text, "ipv4_tr_send(): recvfrom() failed.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          G_LOCK (message_available);
          message_available = 1;
          G_UNLOCK (message_available);
          G_LOCK (tracing);
          tracing = 0;
          G_UNLOCK (tracing);
          free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
          return (EXIT_FAILURE);
        }
      }  // End of error handling conditionals.

      // Check for an IP ethernet frame. If not, ignore and keep listening.
      if (((rec_ether_frame[12] << 8) + rec_ether_frame[13]) == ETH_P_IP) {

        // Determine offsets to ICMP and TCP headers from received IPv4 header length, which is expressed in 32-bit words.
        icmphdr = (struct icmp *) (rec_ether_frame + ETH_HDRLEN + (iphdr->ip_hl * 4));
        tcphdr = (struct tcphdr *) (rec_ether_frame + ETH_HDRLEN + (iphdr->ip_hl * 4));

        // Did we get an ICMP_TIME_EXCEEDED?
        if ((iphdr->ip_p == IPPROTO_ICMP) && (icmphdr->icmp_type == ICMP_TIME_EXCEEDED)) {
          trycount = 0;
          // Stop timer and calculate how long it took to get a reply.
          (void) gettimeofday (&t2, &tz);
          dt = (double) (t2.tv_sec - t1.tv_sec) * 1000.0 + (double) (t2.tv_usec - t1.tv_usec) / 1000.0;

          // Extract source IP address from received ethernet frame.
          if (inet_ntop (AF_INET, &(iphdr->ip_src.s_addr), rec_ip, INET_ADDRSTRLEN) == NULL) {
            status = errno;
            sprintf (data->error_text, "ipv4_tr_send(): recvfrom() failed.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            G_LOCK (message_available);
            message_available = 1;
            G_UNLOCK (message_available);
            G_LOCK (tracing);
            tracing = 0;
            G_UNLOCK (tracing);
            free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
            return (EXIT_FAILURE);
          }

          // Report source IP address and time for reply.
          if (!data->resolve_tr) {
            memset (message, 0, TEXT_STRINGLEN * sizeof (char));
            sprintf (message, "%2i  %s  %g ms (%i bytes received)", node, rec_ip, dt, bytes);
          } else {
            sa.sin_family = AF_INET;
            if ((status = inet_pton (AF_INET, rec_ip, &sa.sin_addr)) != 1) {
              sprintf (data->error_text, "ipv4_tr_send(): inet_pton() failed.\nError message: %s", strerror (status));
              data->parent = data->main_window;
              G_LOCK (message_available);
              message_available = 1;
              G_UNLOCK (message_available);
              G_LOCK (tracing);
              tracing = 0;
              G_UNLOCK (tracing);
              free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
              return (EXIT_FAILURE);
            }
            if ((status = getnameinfo ((struct sockaddr*)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
              fprintf (stderr, "getnameinfo() failed in ipv4_tr_send().\nError message: %s", strerror (status));
              exit (EXIT_FAILURE);
            }
            memset (message, 0, TEXT_STRINGLEN * sizeof (char));
            sprintf (message, "%2i  %s (%s)  %g ms (%i bytes received)", node, rec_ip, hostname, dt, bytes);
          }
          if (probes < data->num_probes) {
            sprintf (message, "%s : ", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            break;  // Break out of Receive loop and probe this node again.
          } else {
            sprintf (message, "%s\n", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            node++;
            probes = 0;
            break;  // Break out of Receive loop and probe next node in route.
          }
        }  // End of ICMP_TIME_EXCEEDED conditional.

        // Did we reach our destination?
        // TCP SYN-ACK means TCP SYN packet reached destination node.
        // ICMP echo reply means ICMP echo request packet reached destination node.
        // ICMP port unreachable means UDP packet reached destination node.
        if (((iphdr->ip_p == IPPROTO_TCP) && (tcphdr->th_flags == 18)) ||  // (18 = SYN, ACK)
            ((iphdr->ip_p == IPPROTO_ICMP) && (icmphdr->icmp_type == ICMP_ECHOREPLY) && (icmphdr->icmp_code == 0)) ||  // ECHO REPLY
            ((iphdr->ip_p == IPPROTO_ICMP) && (icmphdr->icmp_type == ICMP_PORT_UNREACH) && (icmphdr->icmp_code == 3))) {  // PORT UNREACHABLE

          // Stop timer and calculate how long it took to get a reply.
          (void) gettimeofday (&t2, &tz);
          dt = (double) (t2.tv_sec - t1.tv_sec) * 1000.0 + (double) (t2.tv_usec - t1.tv_usec) / 1000.0;

          // Extract source IP address from received ethernet frame.
          if (inet_ntop (AF_INET, &(iphdr->ip_src.s_addr), rec_ip, INET_ADDRSTRLEN) == NULL) {
            status = errno;
            sprintf (data->error_text, "ipv4_tr_send(): recvfrom() failed.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            G_LOCK (message_available);
            message_available = 1;
            G_UNLOCK (message_available);
            G_LOCK (tracing);
            tracing = 0;
            G_UNLOCK (tracing);
            free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);
            return (EXIT_FAILURE);
          }

          // Report source IP address and time for reply.
          memset (message, 0, TEXT_STRINGLEN * sizeof (char));
          sprintf (message, "%2i  %s  %g ms", node, rec_ip, dt);
          if (probes < data->num_probes) {
            sprintf (message, "%s : ", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            break;  // Break out of Receive loop and probe this node again.
          } else {
            sprintf (message, "%s\n", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            done = 1;
            break;  // Break out of Receive loop and finish.
          }
        }  // End of Reached Destination conditional.
      }  // End of Was IP Frame conditional.
    }  // End of Receive loop.


    // Reached destination node or Stop button pressed.
    if ((done == 1) || (done == 2)) {
      break;  // Break out of Send loop.

    // Reached maxhops.
    } else if (node > data->maxhops) {
      memset (message, 0, TEXT_STRINGLEN * sizeof (char));
      sprintf (message, "Reached maximum number of hops. Maximum is set to %i hops.\n", data->maxhops);
      msgdata = allocate_msgdata (1);
      msgdata->textview = data->textview7;
      g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
      done = 3;
      break;  // Break out of Send loop.
    }

    // We ran out of tries, let's move on to next node unless we reached maxhops limit.
    if (trycount == trylim) {
      memset (message, 0, TEXT_STRINGLEN * sizeof (char));
      sprintf (message, "%2i  Node won't respond after %i probes.\n", node, trylim);
      msgdata = allocate_msgdata (1);
      msgdata->textview = data->textview7;
      g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
      node++;
      probes = 0;
      trycount = 0;
      continue;
    }

    // Randomize source ports if requested.
    // create_ip4_frame() will be called when Send loop cycles and TTL is updated.

    // TCP
    if ((data->packet_type_tr == 9) && data->ran_tcp4_tr_sourceport) {
      data->tcphdr[data->packet_type_tr].th_sport = htons (ran16_0to65535 (data));

      // TCP header checksum (16 bits)
      data->tcphdr[data->packet_type_tr].th_sum = tcp4_checksum (data->ip4hdr[data->packet_type_tr], data->tcphdr[data->packet_type_tr], data->tcp_nopt[data->packet_type_tr], data->tcp_opt_totlen[data->packet_type_tr], data->tcp_optlen[data->packet_type_tr], data->tcp_options[data->packet_type_tr], data->tcp_optpadlen[data->packet_type_tr], data->payload[data->packet_type_tr], data->payloadlen[data->packet_type_tr]);
    }

    // UDP
    if ((data->packet_type_tr == 11) && data->ran_udp4_tr_sourceport) {
      data->udphdr[data->packet_type_tr].uh_sport = htons (ran16_0to65535 (data));

      // UDP header checksum (16 bits)
      data->udphdr[data->packet_type_tr].uh_sum = udp4_checksum (data->ip4hdr[data->packet_type_tr], data->udphdr[data->packet_type_tr], data->payload[data->packet_type_tr], data->payloadlen[data->packet_type_tr]);
    }

  }  // End of Send loop.

  if (done == 1) {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "End of traceroute.\n\n");
    msgdata = allocate_msgdata (1);
    msgdata->textview = data->textview7;
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  } else if ((done == 2) || (done == 3)) {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "Traceroute aborted.\n\n");
    msgdata = allocate_msgdata (1);
    msgdata->textview = data->textview7;
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
  }

  // Close socket descriptors.
  close (sendsd);
  close (recsd);

  // Have idle function update IPv4 traceroute source ports, which may have changed if randomized.
  // Only start idle function if traceroute packet-editing window is activated.
  if (data->traceroute_flag) {
    g_idle_add ((GSourceFunc) update_tr_ip4_sources, data);
  }

  // Free allocated memory.
  free_ipv4_tr_mem (rec_ip, rec_ether_frame, src_ip, dst_ip, message);

  // Clear tracing flag.
  G_LOCK (tracing);
  tracing = 0;
  G_UNLOCK (tracing);

  return (EXIT_SUCCESS);
}

// Free allocated memory used in ipv4_tr_send().
int
free_ipv4_tr_mem (char *rec_ip, uint8_t *rec_ether_frame, char *src_ip, char *dst_ip, char *message)
{
  free (rec_ether_frame);
  free (src_ip);
  free (dst_ip);
  free (rec_ip);
  free (message);

  return (EXIT_SUCCESS);
}

// Idle function to update IPv4 traceroute source ports, which may have changed if randomized.
// This idle function returns 0 in order to stop.
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
update_tr_ip4_sources (SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP (IPv4 traceroute) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[9].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry182), value);

  // UDP (IPv4 traceroute) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[11].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry242), value);

  // Free allocated memory.
  free (value);

  return (0);  // This idle function stops when it returns a value of zero.
}

// Populate IPv4 TCP entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
tcp4_tr_show (SPSData *data)
{
  int status, old;
  char *value;
  GtkTextBuffer *textbuffer34, *textbuffer36;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Specify the ethernet header or not.
  if (data->specify_ether[9]) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton34), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton34), FALSE);
  }

  // Destination link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[9].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry164), value);

  // Source Interface Name
  gtk_entry_set_text (GTK_ENTRY (data->entry166), data->ifname[9]);

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton11), data->ifmtu[9]);

  // Source link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[9].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry165), value);

  // Ethernet type code (16 bits)
  // http://www.iana.org/assignments/ethernet-numbers
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[9].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry167), value);

  // IP header options

  // IP option entry format
  if (data->dec_hex_ipopt_tcp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton50), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton50), FALSE);
  }

  // Number of IP options
  textbuffer34 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview34));
  sprintf (value, "%i", data->ip_nopt[9]);
  gtk_text_buffer_set_text (textbuffer34, value, -1);

  // IP options entry
  if (data->ip_nopt[9] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry416), "Options loaded.");
  }

  // Default option number after which to insert a new option
  gtk_entry_set_text (GTK_ENTRY (data->entry417), "");

  // Number of IP option to remove (0 = none)
  gtk_entry_set_text (GTK_ENTRY (data->entry418), "");

  // TCP header options

  // TCP option entry format
  if (data->dec_hex_tcpopt_tcp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton52), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton52), FALSE);
  }

  // Number of TCP options
  textbuffer36 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview36));
  sprintf (value, "%i", data->tcp_nopt[9]);
  gtk_text_buffer_set_text (textbuffer36, value, -1);

  // TCP options entry
  if (data->tcp_nopt[9] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry419), "Options loaded.");
  }

  // Default option number after which to insert a new option
  gtk_entry_set_text (GTK_ENTRY (data->entry420), "");

  // Number of TCP option to remove (0 = none)
  gtk_entry_set_text (GTK_ENTRY (data->entry421), "");

  // TCP data entry
  if (data->payloadlen[9] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry199), "Data file loaded.");
  }

  // TCP data entry format
  if (data->ascii_hex_tcp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton30), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton30), FALSE);
  }

  // IPv4 header

  // IPv4 header length (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[9].ip_hl);
  gtk_entry_set_text (GTK_ENTRY (data->entry168), value);

  // Internet Protocol version (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[9].ip_v);
  gtk_entry_set_text (GTK_ENTRY (data->entry169), value);

  // Type of service (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[9].ip_tos);
  gtk_entry_set_text (GTK_ENTRY (data->entry170), value);

  // Total length of datagram (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[9].ip_len));
  gtk_entry_set_text (GTK_ENTRY (data->entry171), value);

  // ID sequence number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[9].ip_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry172), value);

  // Zero (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[9].ip_off) >> 15));
  gtk_entry_set_text (GTK_ENTRY (data->entry173), value);

  // Do not fragment flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[9].ip_off) >> 14) & 1));
  gtk_entry_set_text (GTK_ENTRY (data->entry174), value);

  // More fragments following flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[9].ip_off) >> 13) & 1));
  gtk_entry_set_text (GTK_ENTRY (data->entry175), value);

  // Fragmentation offset (13 bits)
  sprintf (value, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[9].ip_off) & 0x1fffu));
  gtk_entry_set_text (GTK_ENTRY (data->entry176), value);

  // Time-to-Live (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[9].ip_ttl);
  gtk_entry_set_text (GTK_ENTRY (data->entry177), value);

  // Transport layer protocol (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[9].ip_p);
  gtk_entry_set_text (GTK_ENTRY (data->entry178), value);

  // Source IPv4 address (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[9].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp4_tr_show(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry179), value);

  // Destination IPv4 address (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[9].ip_dst), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp4_tr_show(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry180), value);

  // IPv4 header checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[9].ip_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry181), value);

  // TCP header (IPv4)

  // Source port number (16 bits)
  old = data->ran_tcp4_tr_sourceport;
  if (data->ran_tcp4_tr_sourceport) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton30), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton30), FALSE);
  }
  // Variable data->ran_tcp4_tr_sourceport will be changed by on_checkbutton30_toggled(), so set it now.
  data->ran_tcp4_tr_sourceport = old;
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[9].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry182), value);

  // Destination port number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[9].th_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry183), value);

  // Sequence number (32 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[9].th_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry184), value);

  // Acknowledgement number (32 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[9].th_ack));
  gtk_entry_set_text (GTK_ENTRY (data->entry185), value);

  // Reserved (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[9].th_x2);
  gtk_entry_set_text (GTK_ENTRY (data->entry186), value);

  // Data offset (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[9].th_off);
  gtk_entry_set_text (GTK_ENTRY (data->entry187), value);

  // FIN flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[9].th_flags & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry188), value);

  // SYN flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 1) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry189), value);

  // RST flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 2) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry190), value);

  // PSH flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 3) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry191), value);

  // ACK flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 4) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry192), value);

  // URG flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 5) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry193), value);

  // ECE flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 6) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry194), value);

  // CWR flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (data->tcphdr[9].th_flags >> 7) & 1);
  gtk_entry_set_text (GTK_ENTRY (data->entry195), value);

  // Window size (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[9].th_win));
  gtk_entry_set_text (GTK_ENTRY (data->entry196), value);

  // Urgent pointer (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[9].th_urp));
  gtk_entry_set_text (GTK_ENTRY (data->entry198), value);

  // TCP checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[9].th_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry197), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Populate IPv4 ICMP entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
icmp4_tr_show (SPSData *data)
{
  int status;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer40;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Ethernet header

  // Specify the ethernet header or not.
  if (data->specify_ether[10]) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton31), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton31), FALSE);
  }

  // Destination link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[10].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry200), value);

  // Source Interface Name
  gtk_entry_set_text (GTK_ENTRY (data->entry202), data->ifname[10]);

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton12), data->ifmtu[10]);

  // Source link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[10].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry201), value);

  // Ethernet type code (16 bits)
  // http://www.iana.org/assignments/ethernet-numbers
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[10].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry203), value);

  // IP header options

  // IP option entry format
  if (data->dec_hex_ipopt_icmp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton56), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton56), FALSE);
  }

  // Number of IP options
  textbuffer40 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview40));
  sprintf (value, "%i", data->ip_nopt[10]);
  gtk_text_buffer_set_text (textbuffer40, value, -1);

  // IP options entry
  if (data->ip_nopt[10] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry425), "Options loaded.");
  }

  // Default option number after which to insert a new option
  gtk_entry_set_text (GTK_ENTRY (data->entry426), "");

  // Number of IP option to remove (0 = none)
  gtk_entry_set_text (GTK_ENTRY (data->entry427), "");

  // ICMP data

  // ICMP data entry
  if (data->payloadlen[10] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry223), "Data file loaded.");
  }

  // ICMP data entry format: default to hexadecimal input
  if (data->ascii_hex_icmp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton32), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton32), FALSE);
  }

  // IPv4 header

  // IPv4 header length (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[10].ip_hl);
  gtk_entry_set_text (GTK_ENTRY (data->entry204), value);

  // Internet Protocol version (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[10].ip_v);
  gtk_entry_set_text (GTK_ENTRY (data->entry205), value);

  // Type of service (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[10].ip_tos);
  gtk_entry_set_text (GTK_ENTRY (data->entry206), value);

  // Total length of datagram (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[10].ip_len));
  gtk_entry_set_text (GTK_ENTRY (data->entry207), value);

  // ID sequence number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[10].ip_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry208), value);

  // Zero (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[10].ip_off) >> 15));
  gtk_entry_set_text (GTK_ENTRY (data->entry209), value);

  // Do not fragment flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[10].ip_off) >> 14) & 1));
  gtk_entry_set_text (GTK_ENTRY (data->entry210), value);

  // More fragments following flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[10].ip_off) >> 13) & 1));
  gtk_entry_set_text (GTK_ENTRY (data->entry211), value);

  // Fragmentation offset (13 bits)
  sprintf (value, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[10].ip_off) & 0x1fffu));
  gtk_entry_set_text (GTK_ENTRY (data->entry212), value);

  // Time-to-Live (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[10].ip_ttl);
  gtk_entry_set_text (GTK_ENTRY (data->entry213), value);

  // Transport layer protocol (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[10].ip_p);
  gtk_entry_set_text (GTK_ENTRY (data->entry214), value);

  // Source IPv4 address (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[10].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp4_tr_show(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry215), value);

  // Destination IPv4 address (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[10].ip_dst), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp4_tr_show(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry216), value);

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[10].ip_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry217), value);

  // ICMP header (IPv4)

  // Message Type (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp4hdr[10].icmp_type);
  gtk_entry_set_text (GTK_ENTRY (data->entry218), value);

  // Message Code (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp4hdr[10].icmp_code);
  gtk_entry_set_text (GTK_ENTRY (data->entry219), value);

  // Identifier (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[10].icmp_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry221), value);

  // Sequence Number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[10].icmp_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry222), value);

  // ICMP header checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[10].icmp_cksum));
  gtk_entry_set_text (GTK_ENTRY (data->entry220), value);

  // Free allocated memory.
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}

// Populate IPv4 UDP entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
udp4_tr_show (SPSData *data)
{
  int status, old;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer42;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Ethernet header

  // Specify the ethernet header or not.
  if (data->specify_ether[11]) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton33), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton33), FALSE);
  }

  // Destination link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[11].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry224), value);

  // Source Interface Name
  gtk_entry_set_text (GTK_ENTRY (data->entry226), data->ifname[11]);

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton13), data->ifmtu[11]);

  // Source link-layer (MAC) address (48 bits)
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[11].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry225), value);

  // Ethernet type code (16 bits)
  // http://www.iana.org/assignments/ethernet-numbers
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[11].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry227), value);

  // IP header options

  // IP option entry format
  if (data->dec_hex_ipopt_udp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton58), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton58), FALSE);
  }

  // Number of IP options
  textbuffer42 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview42));
  sprintf (value, "%i", data->ip_nopt[11]);
  gtk_text_buffer_set_text (textbuffer42, value, -1);

  // IP options entry
  if (data->ip_nopt[11] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry428), "Options loaded.");
  }

  // Default option number after which to insert a new option
  gtk_entry_set_text (GTK_ENTRY (data->entry429), "");

  // Number of IP option to remove (0 = none)
  gtk_entry_set_text (GTK_ENTRY (data->entry430), "");

  // UDP data

  // UDP data entry
  if (data->payloadlen[11] > 0) {
    gtk_entry_set_text (GTK_ENTRY (data->entry246), "Data file loaded.");
  }

  // UDP data entry format
  if (data->ascii_hex_udp4_tr == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton34), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton34), FALSE);
  }

  // IPv4 header

  // IPv4 header length (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[11].ip_hl);
  gtk_entry_set_text (GTK_ENTRY (data->entry228), value);

  // Internet Protocol version (4 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[11].ip_v);
  gtk_entry_set_text (GTK_ENTRY (data->entry229), value);

  // Type of service (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[11].ip_tos);
  gtk_entry_set_text (GTK_ENTRY (data->entry230), value);

  // Total length of datagram (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[11].ip_len));
  gtk_entry_set_text (GTK_ENTRY (data->entry231), value);

  // ID sequence number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[11].ip_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry232), value);

  // Zero (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[11].ip_off) >> 15));
  gtk_entry_set_text (GTK_ENTRY (data->entry233), value);

  // Do not fragment flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[11].ip_off) >> 14) & 1));
  gtk_entry_set_text (GTK_ENTRY (data->entry234), value);

  // More fragments following flag (1 bit)
  sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[11].ip_off) >> 13) & 1));
  gtk_entry_set_text (GTK_ENTRY (data->entry235), value);

  // Fragmentation offset (13 bits)
  sprintf (value, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[11].ip_off) & 0x1fffu));
  gtk_entry_set_text (GTK_ENTRY (data->entry236), value);

  // Time-to-Live (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[11].ip_ttl);
  gtk_entry_set_text (GTK_ENTRY (data->entry237), value);

  // Transport layer protocol (8 bits)
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[11].ip_p);
  gtk_entry_set_text (GTK_ENTRY (data->entry238), value);

  // Source IPv4 address (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[11].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp4_tr_show(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry239), value);

  // Destination IPv4 address (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[11].ip_dst), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp4_tr_show(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry240), value);

  // IPv4 header checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[11].ip_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry241), value);

  // UDP header (IPv4)

  // Source port number (16 bits)
  old = data->ran_udp4_tr_sourceport;
  if (data->ran_udp4_tr_sourceport) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton35), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton35), FALSE);
  }
  // Variable data->ran_udp4_tr_sourceport will be changed by on_checkbutton35_toggled(), so set it now.
  data->ran_udp4_tr_sourceport = old;
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[11].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry242), value);

  // Destination port number (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[11].uh_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry243), value);

  // Length of UDP datagram (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[11].uh_ulen));
  gtk_entry_set_text (GTK_ENTRY (data->entry244), value);

  // UDP checksum (16 bits)
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[11].uh_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry245), value);

  // Free allocated memory.
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}
