/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()
extern int tracing;  // Flag to indicate a traceroute thread is active

G_LOCK_EXTERN (message_available);  // Obtain a MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen().
G_LOCK_EXTERN (tracing);  // Obtain a MUTEX for flag indicating a traceroute thread is active.

// Start an IPv6 over IPv4 (6to4) traceroute.
// This function will be executed as a separate thread on_button24_clicked.
int
sixto4_tr_send (SPSData *data)
{
  int status, frame, sendsd, recsd, probes;
  int bytes, timeout, node, trylim, trycount, done;
  char *src4_ip, *src6_ip, *dst_ip, *rec_ip;
  char hostname[NI_MAXHOST], *message;
  struct ip6_hdr *ip6hdr;
  struct tcphdr *tcphdr;
  struct icmp6_hdr *icmphdr;
  uint8_t *rec_ether_frame;
  struct sockaddr_in sin;
  struct sockaddr_in6 sa;
  struct sockaddr from;
  struct sockaddr_ll device;
  socklen_t fromlen;
  struct timezone tz;
  struct timeval wait, t1, t2;
  double dt;
  Msgdata *msgdata;

  // Allocate memory for various arrays.
  rec_ip = allocate_strmem (INET6_ADDRSTRLEN);
  rec_ether_frame = allocate_ustrmem (IP_MAXPACKET);
  src4_ip = allocate_strmem (INET_ADDRSTRLEN);
  src6_ip = allocate_strmem (INET6_ADDRSTRLEN);
  dst_ip = allocate_strmem (INET6_ADDRSTRLEN);

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Make sure all interfaces were specified
  if (data->specify_ether[data->packet_type_tr] && (strnlen (data->ifname[data->packet_type_tr], TMP_STRINGLEN) < 2)) {
    sprintf (data->error_text, "sixto4_tr_send(): Appears to be an invalid interface name.");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Resolve interface index.
  memset (&device, 0, sizeof (device));
  if (data->specify_ether[15] && (data->packet_type_tr == 12)) {
    if ((device.sll_ifindex = if_nametoindex (data->ifname[data->packet_type_tr])) == 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_tr_send(): if_nametoindex() failed to obtain interface index for TCP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  }
  if (data->specify_ether[16] && (data->packet_type_tr == 13)) {
    if ((device.sll_ifindex = if_nametoindex (data->ifname[data->packet_type_tr])) == 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_tr_send(): if_nametoindex() failed to obtain interface index for ICMP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  }
  if (data->specify_ether[17] && (data->packet_type_tr == 14)) {
    if ((device.sll_ifindex = if_nametoindex (data->ifname[data->packet_type_tr])) == 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_tr_send(): if_nametoindex() failed to obtain interface index for UDP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  }

  // Fill out sockaddr_ll.
  device.sll_family = AF_PACKET;
  memcpy (device.sll_addr, data->ethhdr[data->packet_type_tr].src_mac, 6 * sizeof (uint8_t));
  device.sll_halen = 6u;

  // For packets (no ethernet header):
  // The kernel will provide Layer 2 (data link layer) information (MAC addresses).
  // To do that, we need to specify a destination for the kernel in order for it
  // to decide where to send the raw datagram. We fill in a struct in_addr with
  // the desired destination IP address, and pass this structure to the sendto() function.
  // Here, regardless of IPv6 packet type, we're sending to the IPv4 6to4 anycast address
  // which is 192.88.99.1. e.g., see sixto4_tcp6_tr_default ().
  memset (&sin, 0, sizeof (sin));
  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = data->ip4hdr[data->packet_type_tr].ip_dst.s_addr;

  // Grab system date and time.
  message = date_and_time (message, TEXT_STRINGLEN);

  // Show target of traceroute.
  memset (&sa, 0, sizeof (sa));
  sa.sin6_family = AF_INET6;
  if (inet_ntop (AF_INET6, &(data->ip6hdr[data->packet_type_tr].ip6_dst), dst_ip, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_tr_send(): inet_ntop() failed for destination IPv6 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }
  if ((status = inet_pton (AF_INET6, dst_ip, &sa.sin6_addr)) != 1) {
    sprintf (data->error_text, "sixto4_tr_send(): inet_pton() failed for destination IPv6 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  if (data->resolve_tr) {
    if ((status = getnameinfo ((struct sockaddr *)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
      sprintf (data->error_text, "sixto4_tr_send(): getnameinfo() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
    if (data->packet_type_tr == 12) {
      sprintf (message, "%s TCP (IPv6 over IPv4) traceroute to %s (%s) port %i\n", message, dst_ip, hostname, ntohs (data->tcphdr[12].th_dport));
    } else if (data->packet_type_tr == 13) {
      sprintf (message, "%s ICMP (IPv6 over IPv4) traceroute to %s (%s)\n", message, dst_ip, hostname);
    } else if (data->packet_type_tr == 14) {
      sprintf (message, "%s UDP (IPv6 over IPv4) traceroute to %s (%s) port %i\n", message, dst_ip ,hostname, ntohs (data->udphdr[14].uh_dport));
    }
  } else {
    if (data->packet_type_tr == 12) {
      sprintf (message, "%s TCP (IPv6 over IPv4) traceroute to %s port %i\n", message, dst_ip, ntohs (data->tcphdr[12].th_dport));
    } else if (data->packet_type_tr == 13) {
      sprintf (message, "%s ICMP (IPv6 over IPv4) traceroute to %s\n", message, dst_ip);
    } else if (data->packet_type_tr == 14) {
      sprintf (message, "%s UDP (IPv6 over IPv4) traceroute to %s port %i\n", message, dst_ip,ntohs (data->udphdr[14].uh_dport));
    }
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview7;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Submit request for raw socket descriptors - one to send, one to receive.
  if (((data->packet_type_tr == 12) && data->specify_ether[15]) ||
      ((data->packet_type_tr == 13) && data->specify_ether[16]) ||
      ((data->packet_type_tr == 14) && data->specify_ether[17])) {
    if ((sendsd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_tr_send(): socket() failed to get a socket descriptor for sending.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  } else {
    if ((sendsd = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
      status = errno;
      sprintf (data->error_text, "sixto4_tr_send(): socket() failed to get a socket descriptor for sending.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      G_LOCK (tracing);
      tracing = 0;
      G_UNLOCK (tracing);
      free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
      return (EXIT_FAILURE);
    }
  }

  if ((recsd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "sixto4_tr_send(): socket() failed to get a socket descriptor for receiving.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    G_LOCK (tracing);
    tracing = 0;
    G_UNLOCK (tracing);
    free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
    return (EXIT_FAILURE);
  }

  // Set maximum number of tries for a host before incrementing TTL and moving on.
  trylim = 3;

  // Set pointers to IPv4, ICMP, and TCP headers within received ethernet frame.
  ip6hdr = (struct ip6_hdr *) (rec_ether_frame + ETH_HDRLEN + IP4_HDRLEN);
  icmphdr = (struct icmp6_hdr *) (rec_ether_frame + ETH_HDRLEN + IP4_HDRLEN + IP6_HDRLEN);
  tcphdr = (struct tcphdr *) (rec_ether_frame + ETH_HDRLEN + IP4_HDRLEN + IP6_HDRLEN);

  // SEND LOOP
  // Loop incrementing TTL each time, exiting when we get our target IP address.
  done = 0;
  trycount = 0;
  node = 1;
  probes = 0;

  for (;;) {

    if (!tracing) {  // Break out of Send loop if Stop button was pressed.
      done = 2;
      break;
    }

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[data->packet_type_tr + 3], &data->ip6hdr[data->packet_type_tr], IP6_HDRLEN * sizeof (uint8_t));

    // Change hop limit.
    data->ip6hdr[data->packet_type_tr + 3].ip6_hops = node;  // + 3 to change hop limit in 6to4 IPv6 header

    // Create probe ethernet frames.
    // create_ip6_frame() is called because we may be changing (randomizing) TCP or UDP port number.
    create_ip6_frame (data->packet_type_tr, data);
    create_6to4_frame (data->packet_type_tr + 3, data);

    // Send ethernet frames.
    for (frame=0; frame<data->nframes[data->packet_type_tr]; frame++) {
      if (((data->packet_type_tr == 12) && data->specify_ether[15]) ||
          ((data->packet_type_tr == 13) && data->specify_ether[16]) ||
          ((data->packet_type_tr == 14) && data->specify_ether[17])) {

        if ((bytes = sendto (sendsd, data->ether_frame[data->packet_type_tr + 3][frame], data->frame_length[data->packet_type_tr + 3][frame], 0, (struct sockaddr *) &device, sizeof (device))) <= 0) {
          status = errno;
        }

      // Send a packet (no ethernet header) to socket.
      } else {
        if ((bytes = sendto (sendsd, data->ether_frame[data->packet_type_tr + 3][frame] + ETH_HDRLEN, data->frame_length[data->packet_type_tr + 3][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &device, sizeof (device))) <= 0) {
          status = errno;
        }
      }
      if (bytes <= 0) {
        sprintf (data->error_text, "sixto4_tr_send(): sendto() failed.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        G_LOCK (tracing);
        tracing = 0;
        G_UNLOCK (tracing);
        free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
        return (EXIT_FAILURE);
      }
    }

    probes++;

    // Start timer.
    (void) gettimeofday (&t1, &tz);

    // Set time for the socket to timeout and give up waiting for an ARP reply.
    timeout = data->timeout_tr;
    wait.tv_sec  = timeout;  
    wait.tv_usec = 0;
    setsockopt (recsd, SOL_SOCKET, SO_RCVTIMEO, (char *) &wait, sizeof (struct timeval));

    // Listen for incoming ethernet frame from socket sd.
    // We expect an ICMP ethernet frame of the form:
    //     MAC (6 bytes) + MAC (6 bytes) + ethernet type (2 bytes)
    //     + ethernet data (IPv4 header + IPv6 header + ICMP header + IPv6 header + TCP/ICMP/UDP header)
    // Keep at it for data->timeout seconds, or until we get an ICMP reply.

    // RECEIVE LOOP
    for (;;) {

      memset (rec_ether_frame, 0, IP_MAXPACKET * sizeof (uint8_t));
      memset (&from, 0, sizeof (from));
      fromlen = sizeof (from);
      if ((bytes = recvfrom (recsd, rec_ether_frame, IP_MAXPACKET, 0, (struct sockaddr *) &from, &fromlen)) < 0) {

        status = errno;

        // Deal with error conditions first.
        if (status == EAGAIN) {  // EAGAIN = 11
          memset (message, 0, TEXT_STRINGLEN * sizeof (char));
          sprintf (message, "  %i No reply within %i seconds.\n", node, timeout);
          msgdata = allocate_msgdata (1);
          msgdata->textview = data->textview7;
          g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
          trycount++;
          break;  // Break out of Receive loop.
        } else if (status == EINTR) {  // EINTR = 4
          continue;  // Something weird happened, but let's keep listening.
        } else {
          sprintf (data->error_text, "sixto4_tr_send(): recvfrom() failed.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          G_LOCK (message_available);
          message_available = 1;
          G_UNLOCK (message_available);
          G_LOCK (tracing);
          tracing = 0;
          G_UNLOCK (tracing);
          free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
          return (EXIT_FAILURE);
        }
      }  // End of error handling conditionals.

      // Check for an IP ethernet frame. If not, ignore and keep listening.
      if (((rec_ether_frame[12] << 8) + rec_ether_frame[13]) == ETH_P_IP) {

        // Did we get an ICMP6_TIME_EXCEEDED?
        if ((ip6hdr->ip6_nxt == IPPROTO_ICMPV6) && (icmphdr->icmp6_type == ICMP6_TIME_EXCEEDED)) {

          trycount = 0;
          // Stop timer and calculate how long it took to get a reply.
          (void) gettimeofday (&t2, &tz);
          dt = (double) (t2.tv_sec - t1.tv_sec) * 1000.0 + (double) (t2.tv_usec - t1.tv_usec) / 1000.0;

          // Extract source IP address from received ethernet frame.
          if (inet_ntop (AF_INET6, &(ip6hdr->ip6_src), rec_ip, INET6_ADDRSTRLEN) == NULL) {
            status = errno;
            sprintf (data->error_text, "sixto4_tr_send(): inet_ntop() failed.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            G_LOCK (message_available);
            message_available = 1;
            G_UNLOCK (message_available);
            G_LOCK (tracing);
            tracing = 0;
            G_UNLOCK (tracing);
            free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
            return (EXIT_FAILURE);
          }

          // Report source IP address and time for reply.
          if (!data->resolve_tr) {
            memset (message, 0, TEXT_STRINGLEN * sizeof (char));
            sprintf (message, "%2i  %s  %g ms (%i bytes received)", node, rec_ip, dt, bytes);
          } else if (data->resolve_tr) {
            sa.sin6_family = AF_INET6;
            if ((status = inet_pton (AF_INET6, rec_ip, &sa.sin6_addr)) != 1) {
              sprintf (data->error_text, "sixto4_tr_send(): inet_pton() failed.\nError message: %s", strerror (status));
              data->parent = data->main_window;
              G_LOCK (message_available);
              message_available = 1;
              G_UNLOCK (message_available);
              G_LOCK (tracing);
              tracing = 0;
              G_UNLOCK (tracing);
              free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
              return (EXIT_FAILURE);
            }
            if ((status = getnameinfo ((struct sockaddr*)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
              fprintf (stderr, "getnameinfo() failed.\nError message: %s", strerror (status));
              exit (EXIT_FAILURE);
            }
            memset (message, 0, TEXT_STRINGLEN * sizeof (char));
            sprintf (message, "%2i  %s (%s)  %g ms (%i bytes received)", node, rec_ip, hostname, dt, bytes);
          }
          if (probes < data->num_probes) {
            sprintf (message, "%s : ", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            break;  // Break out of Receive loop and probe this node again.
          } else {
            sprintf (message, "%s\n", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            node++;
            probes = 0;
            break;  // Break out of Receive loop and probe next node in route.
          }
        }  // End of ICMP6_TIME_EXCEEDED conditional.

        // Did we reach our destination?
        // TCP SYN-ACK means TCP SYN packet reached destination node.
        // ICMP echo reply means ICMP echo request packet reached destination node.
        // ICMP port unreachable means UDP packet reached destination node.
        if (((ip6hdr->ip6_nxt == IPPROTO_TCP) && (tcphdr->th_flags == 18)) ||  // (18 = SYN, ACK)
            ((ip6hdr->ip6_nxt == IPPROTO_ICMPV6) && (icmphdr->icmp6_type == ICMP6_ECHO_REPLY) && (icmphdr->icmp6_code == 0)) ||  // ECHO REPLY
            ((ip6hdr->ip6_nxt == IPPROTO_ICMPV6) && (icmphdr->icmp6_type == ICMP6_DST_UNREACH) && (icmphdr->icmp6_code == ICMP6_DST_UNREACH_NOPORT))) {  // PORT UNREACHABLE

          // Stop timer and calculate how long it took to get a reply.
          (void) gettimeofday (&t2, &tz);
          dt = (double) (t2.tv_sec - t1.tv_sec) * 1000.0 + (double) (t2.tv_usec - t1.tv_usec) / 1000.0;

          // Extract source IP address from received ethernet frame.
          if (inet_ntop (AF_INET6, &(ip6hdr->ip6_src), rec_ip, INET6_ADDRSTRLEN) == NULL) {
            status = errno;
            sprintf (data->error_text, "sixto4_tr_send(): inet_ntop() failed.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            G_LOCK (message_available);
            message_available = 1;
            G_UNLOCK (message_available);
            G_LOCK (tracing);
            tracing = 0;
            G_UNLOCK (tracing);
            free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);
            return (EXIT_FAILURE);
          }

          // Report source IP address and time for reply.
          memset (message, 0, TEXT_STRINGLEN * sizeof (char));
          sprintf (message, "%2i  %s  %g ms", node, rec_ip, dt);
          if (probes < data->num_probes) {
            sprintf (message, "%s : ", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            break;  // Break out of Receive loop and probe this node again.
          } else {
            sprintf (message, "%s\n", message);
            msgdata = allocate_msgdata (1);
            msgdata->textview = data->textview7;
            g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
            done = 1;
            break;  // Break out of Receive loop and finish.
          }
        }  // End of Reached Destination conditional.
      }  // End of Was IP Frame conditional.
    }  // End of Receive loop.


    // Reached destination node or Stop button pressed.
    if ((done == 1) || (done == 2)) {
      break;  // Break out of Send loop.

    // Reached maxhops.
    } else if (node > data->maxhops) {
      memset (message, 0, TEXT_STRINGLEN * sizeof (char));
      sprintf (message, "Reached maximum number of hops. Maximum is set to %i hops.\n", data->maxhops);
      msgdata = allocate_msgdata (1);
      msgdata->textview = data->textview7;
      g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
      done = 3;
      break;  // Break out of Send loop.
    }

    // We ran out of tries, let's move on to next node unless we reached maxhops limit.
    if (trycount == trylim) {
      memset (message, 0, TEXT_STRINGLEN * sizeof (char));
      sprintf (message, "%2i  Node won't respond after %i probes.\n", node, trylim);
      msgdata = allocate_msgdata (1);
      msgdata->textview = data->textview7;
      g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
      node++;
      probes = 0;
      trycount = 0;
      continue;
    }

    // Randomize source ports if requested.
    // create_6to4_frame() will be called when Send loop cycles and TTL is updated.

    // TCP
    if ((data->packet_type_tr == 12) && data->ran_tcp6_tr_sourceport) {
      data->tcphdr[data->packet_type_tr].th_sport = htons (ran16_0to65535 (data));

      // TCP header checksum (16 bits)
      data->tcphdr[data->packet_type_tr].th_sum = tcp6_checksum (data->ip6hdr[data->packet_type_tr], data->tcphdr[data->packet_type_tr], data->tcp_nopt[data->packet_type_tr], data->tcp_opt_totlen[data->packet_type_tr], data->tcp_optlen[data->packet_type_tr], data->tcp_options[data->packet_type_tr], data->tcp_optpadlen[data->packet_type_tr], data->payload[data->packet_type_tr], data->payloadlen[data->packet_type_tr]);
    }

    // UDP
    if ((data->packet_type_tr == 14) && data->ran_udp6_tr_sourceport) {
      data->udphdr[data->packet_type_tr].uh_sport = htons (ran16_0to65535 (data));

      // UDP header checksum (16 bits)
      data->udphdr[data->packet_type_tr].uh_sum = udp6_checksum (data->ip6hdr[data->packet_type_tr], data->udphdr[data->packet_type_tr], data->payload[data->packet_type_tr], data->payloadlen[data->packet_type_tr]);
    }

  }  // End of Send loop.

  if (done == 1) {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "End of traceroute.\n\n");
    msgdata = allocate_msgdata (1);
    msgdata->textview = data->textview7;
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  } else if ((done == 2) || (done == 3)) {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "Traceroute aborted.\n\n");
    msgdata = allocate_msgdata (1);
    msgdata->textview = data->textview7;
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
  }

  // Close socket descriptors.
  close (sendsd);
  close (recsd);

  // Have idle function update IPv6 traceroute source ports, which may have changed if randomized.
  // Only start idle function if traceroute packet-editing window is activated.
  if (data->traceroute_flag) {
    g_idle_add ((GSourceFunc) update_tr_ip6_sources, data);
  }

  // Free allocated memory.
  free_sixto4_tr_mem (rec_ip, rec_ether_frame, src4_ip, src6_ip, dst_ip, message);

  // Clear tracing flag.
  G_LOCK (tracing);
  tracing = 0;
  G_UNLOCK (tracing);

  return (EXIT_SUCCESS);
}

// Free allocated memory used in sixto4_tr_send().
int
free_sixto4_tr_mem (char *rec_ip, uint8_t *rec_ether_frame, char *src4_ip, char *src6_ip, char *dst_ip, char *message)
{
  free (rec_ether_frame);
  free (src4_ip);
  free (src6_ip);
  free (dst_ip);
  free (rec_ip);
  free (message);

  return (EXIT_SUCCESS);
}

// Populate IPv6 over IPv4 (6to4) entries on Traceroute page
// **ONLY TO BE CALLED WHEN TRACEROUTE PACKET-EDITING WINDOW IS ACTIVATED**
int
sixto4_tr_show (SPSData *data)
{
  int status, old;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Flag to use 6to4
  old = data->sixto4_tr_flag;
  if (data->sixto4_tr_flag) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton29), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton29), FALSE);
  }
  // Variable data->sixto4_flag will be changed by on_checkbutton29_toggled(), so set it now.
  data->sixto4_tr_flag = old;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton18), data->ifmtu[15]);

  // Flag to use ethernet header from IPv6 TCP page
  old = data->specify_ether[15];
  if (data->specify_ether[15]) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton48), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton48), FALSE);
  }
  // Variable data->specify_ether[15] will be changed by on_checkbutton48_toggled(), so set it now.
  data->specify_ether[15] = old;

  // Flag to use ethernet header from IPv6 ICMP page
  old = data->specify_ether[16];
  if (data->specify_ether[16]) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton49), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton49), FALSE);
  }
  // Variable data->specify_ether[16] will be changed by on_checkbutton49_toggled(), so set it now.
  data->specify_ether[16] = old;

  // Flag to use ethernet header from IPv6 UDP page
  old = data->specify_ether[17];
  if (data->specify_ether[17]) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton50), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton50), FALSE);
  }
  // Variable data->specify_ether[17] will be changed by on_checkbutton50_toggled(), so set it now.
  data->specify_ether[17] = old;

  // Source IPv4 addresses (32 bits)
  if (inet_ntop (AF_INET, &(data->ip4hdr[15].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_tr_show(): inet_ntop() failed for TCP source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry316), value);
  if (inet_ntop (AF_INET, &(data->ip4hdr[16].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_tr_show(): inet_ntop() failed for ICMP source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry317), value);
  if (inet_ntop (AF_INET, &(data->ip4hdr[17].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_tr_show(): inet_ntop() failed for UDP source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry318), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}
