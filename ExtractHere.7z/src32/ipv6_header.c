/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// IP version (4 bits)
int
ip6_ver_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  uint32_t old;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Save value currently in header
  old = ntohl (data->ip6hdr[type].ip6_flow);

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 15l)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->ip6hdr[type].ip6_flow) >> 28);
    gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Value is in acceptable range.
  } else {
    data->ip6hdr[type].ip6_flow = htonl ((((uint32_t) ascii_to_int64 ((char *) entry_text)) << 28) + (old & 0xffffffful));  // Update IPv6 header with new value

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
ip6_tc_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  uint32_t old;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Save value currently in header
  old = ntohl (data->ip6hdr[type].ip6_flow);

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255l)) {
    sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[type].ip6_flow) >> 20) & 0xfful));
    gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Value is in acceptable range.
  } else {
    data->ip6hdr[type].ip6_flow = htonl ((((uint32_t) ascii_to_int64 ((char *) entry_text)) << 20) + (old & 0xf00ffffful));  // Update IPv6 header with new value

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
ip6_fl_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  uint32_t old;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Save value currently in header
  old = ntohl (data->ip6hdr[type].ip6_flow);

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 0xfffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[type].ip6_flow) & 0xffffful));
    gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Value is in acceptable range.
  } else {
    data->ip6hdr[type].ip6_flow = htonl (((uint32_t) ascii_to_int64 ((char *) entry_text)) + (old & 0xfff00000ul));  // Update IPv6 header with new value

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
ip6_plen_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[type].ip6_plen));
    gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Value is in acceptable range.
  } else {
    data->ip6hdr[type].ip6_plen = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update IPv6 header with new value

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
ip6_nxt_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[type].ip6_nxt);
    gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Value is in acceptable range.
  } else {
    data->ip6hdr[type].ip6_nxt = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv6 header with new value

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
ip6_hops_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[type].ip6_hops);
    gtk_entry_set_text (GTK_ENTRY (entry), value);

  // Value is in acceptable range.
  } else {
    data->ip6hdr[type].ip6_hops = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv6 header with new value

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
ip6_sip_entry (GtkWidget *entry, int type, SPSData *data)
{
  int status;
  const char *entry_text;
  char *value;

  if (type > 8) {
    data->parent = data->traceroute_window;
  } else {
    data->parent = data->main_window;
  }

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is it a valid IP address? Valid if inet_pton returns 1.
  if (inet_pton (AF_INET6, entry_text, &(data->ip6hdr[type].ip6_src)) != 1) {
    
    // Invalid IP
    if (inet_ntop (AF_INET6, &(data->ip6hdr[type].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ip6_sip_entry(): inet_ntop() failed.\nError message: %s", strerror (status));
      report_error (data);
      free (value);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    sprintf (data->error_text, "ip6_sip_entry(): inet_pton() failed.\nAppears to be an invalid IPv6 address.");
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

  // Update upper layer protocol checksum, which protects source and destination IP addresses.
  switch (type) {
    case 3:
      tcp_chksum (type, data);
      break;
    case 4:
      icmp_chksum (type, data);
      break;
    case 5:
      udp_chksum (type, data);
      break;
    case 12:
      tcp_chksum (type, data);
      break;
    case 13:
      icmp_chksum (type, data);
      break;
    case 14:
      udp_chksum (type, data);
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip6_sip_entr().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }

  // Update ethernet frames.
  create_ip6_frame (type, data);
  create_6to4_frame (type + 3, data);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Randomize source IP address
int
ip6_ransip_checkbutton (int *ran_sourceip, GtkWidget *entry, int type, SPSData *data)
{
  int status;
  char *value, *ipaddress;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv6 address + '\0'
  // Array of chars.
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  if (!(*ran_sourceip)) {
    *ran_sourceip = 1;
    if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[type].ip6_src)) != 1) {
      sprintf (data->error_text, "ip6_ransip_checkbutton(): inet_pton() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (ipaddress);
      free (value);
      return (EXIT_FAILURE);
    }
    if (inet_ntop (AF_INET6, &(data->ip6hdr[type].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ip6_ransip_checkbutton(): inet_ntop() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (ipaddress);
      free (value);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);

    // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
    memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

    // Update upper layer protocol checksum, which protects source and destination IP addresses.
    switch (type) {
      case 3:
        tcp_chksum (type, data);
        break;
      case 4:
        icmp_chksum (type, data);
        break;
      case 5:
        udp_chksum (type, data);
        break;
      case 12:
        tcp_chksum (type, data);
        break;
      case 13:
        icmp_chksum (type, data);
        break;
      case 14:
        udp_chksum (type, data);
        break;
      default:
        fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip6_ransip_checkbutton().\n", type);
        free (value);
        free (ipaddress);
        exit (EXIT_FAILURE);
    }

    // Update ethernet frames.
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);

  } else {
    *ran_sourceip = 0;
  }

  // Free allocated memory.
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
ip6_dip_entry (GtkWidget *entry, int type, SPSData *data)
{
  int status;
  const char *entry_text;
  char *value;

  if (type > 8) {
    data->parent = data->traceroute_window;
  } else {
    data->parent = data->main_window;
  }

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is it a valid IP address? Valid if inet_pton returns 1.
  if (inet_pton (AF_INET6, entry_text, &(data->ip6hdr[type].ip6_dst)) != 1) {

    // Invalid IP
    if (inet_ntop (AF_INET6, &(data->ip6hdr[type].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ip6_dip_entry(): inet_ntop() failed.\nError message: %s", strerror (status));
      report_error (data);
      free (value);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    sprintf (data->error_text, "ip6_dip_entry(): inet_pton() failed.\nAppears to be an invalid IPv6 address.");
    report_error (data);
    free (value);
    return (EXIT_FAILURE);
  }

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[type + 3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

  // Update upper layer protocol checksum, which protects source and destination IP addresses.
  switch (type) {
    case 3:
      tcp_chksum (type, data);
      break;
    case 4:
      icmp_chksum (type, data);
      break;
    case 5:
      udp_chksum (type, data);
      break;
    case 12:
      tcp_chksum (type, data);
      break;
    case 13:
      icmp_chksum (type, data);
      break;
    case 14:
      udp_chksum (type, data);
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip6_dip_entry().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }

  // Update ethernet frames.
  create_ip6_frame (type, data);
  create_6to4_frame (type + 3, data);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Truncate IPv6 payload length as necessary to accomodate the
// variable lengths of extension headers and TCP options.
int
truncate_ip6 (int type, SPSData *data)
{
  int unfraglen, fraglen_nopayload;

  // Find length of unfragmentable portion. Note allowance for IPv4 header for 6to4.
  unfraglen = find6_unfraglen (type, data) + IP4_HDRLEN;

  // Find length of fragmentable portion, excluding payload data.
  fraglen_nopayload = find6_fraglen (type, data) - data->payloadlen[type];

  if ((unfraglen + fraglen_nopayload + data->payloadlen[type]) > IP_MAXPACKET) {
    data->payloadlen[type] = IP_MAXPACKET - unfraglen - fraglen_nopayload;
    return (1);  // Truncation occurred.
  }

  return (0);  // Truncation did not occur.
}

// Re-calculate IPv6 payload length and update text entry.
int
ip6_paylen (int type, SPSData *data)
{
  int i, len;
  GtkWidget *plen_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Set order of all headers, extension headers, and data.
  // This must be called in order to ensure any new items are included in chain length.
  ip6_order (type, data);  // Note: This will set data->first_frag[type]

  // Payload length (16 bits)
  len = 0;
  i = 1;  // Skip initial IPv6 header at index 0.
  while ((data->order[type][i] != 99) && (i < MAX_IP6LINKS)) {
    switch (data->order[type][i]) {

      // New IP6 header (if tunnelling AH or ESP)
      case 98:
        len += IP6_HDRLEN;
        break;

      // IP6 header - shouldn't be found, but leave for any possible future use.
      case 0:
        len += IP6_HDRLEN;
        break;

      // Hop-by-hop header
      case 1:
        len += HOP_HDRLEN + data->hbh_opt_totlen[type] + data->hbh_optpadlen[type];
        break;

      // Destination header (first)
      case 2:
        len += DST_HDRLEN + data->dstf_opt_totlen[type] + data->dstf_optpadlen[type];
        break;

      // Routing header
      case 3:
        len += RTE_HDRLEN + data->route_datlen[type];
        break;

      // Authentication header
      case 5:
        len += ATH_HDRLEN + data->auth_len[type];
        break;

      // ESP header, excluding payload data, ESP tail, and auth. data
      // All links in chain to follow are part of ESP payload.
      case 6:
        len += ESP_HDRLEN;
        break;

      // Destination header (last)
      case 8:
        len += DST_HDRLEN + data->dstl_opt_totlen[type] + data->dstl_optpadlen[type];
        break;

      // TCP header and options
      case 9:
        len += TCP_HDRLEN + data->tcp_opt_totlen[type] + data->tcp_optpadlen[type];
        break;

      // TCP payload data
      case 12:
        len += data->payloadlen[type];
        break;

      // ICMP header
      case 10:
        len += ICMP_HDRLEN;
        break;

      // ICMP payload data
      case 13:
        len += data->payloadlen[type];
        break;

      // UDP header
      case 11:
        len += UDP_HDRLEN;
        break;

      // UDP payload data
      case 14:
        len += data->payloadlen[type];
        break;

      // Encapsulating security payload trailer (transport and tunnel mode)
      // Add padding (Section 2.4 of RFC 2406).
      case 7:
        len += data->esptail[type].pad_len;
        len += ESP_TAILLEN;
        len += data->esp_auth_len[type];
        break;

      // Unknown index value
      default:
        fprintf (stderr, "ERROR: Unknown index value %i in ip6_paylen().\n", data->order[type][i]);
        exit (EXIT_FAILURE);
    }  // End switch statement

    i++;  // Go to next item in chain
  }  // End loop through IPv6 chain

  data->ip6hdr[type].ip6_plen = htons (len);

  // Copy revised IPv6 header to 6to4 header.
  memcpy (&data->ip6hdr[type+3], &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

  // Update IPv6 header payload length entry
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[type].ip6_plen));

  switch (type) {
    case 3:  // IPv6 TCP
      plen_entry = data->entry25;
      break;
    case 4:  // IPv6 ICMP
      plen_entry = data->entry113;
      break;
    case 5:  // IPv6 UDP
      plen_entry = data->entry100;
      break;
    case 12:  // IPv6 TCP for traceroute
      plen_entry = data->entry254;
      break;
    case 13:  // IPv6 ICMP for traceroute
      plen_entry = data->entry284;
      break;
    case 14:  // IPv6 UDP for traceroute
      plen_entry = data->entry302;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip6_paylen().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (plen_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Update (IPv6): lengths, checksums, offsets, and update extension header
// editing window if open. Also regenerate ethernet frames.
int
ip6data_update (int type, SPSData *data)
{
  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  if (truncate_ip6 (type, data)) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // IPv6 payload length (16 bits)
  ip6_paylen (type, data);

  // "New" IPv6 header payload length (16 bits):
  data->ip6hdr[data->exthdr_type+20].ip6_plen = htons (find6_unfraglen (data->exthdr_type, data) + find6_fraglen (data->exthdr_type, data));

  // "New" IPv6 header source IPv6 address (128 bits): copy from encapsulated IPv6 header
  memcpy (&data->ip6hdr[data->exthdr_type+20].ip6_src, &data->ip6hdr[data->exthdr_type].ip6_src, 16 * sizeof (uint8_t));

  // "New" IPv6 header destination IPv6 address (128 bits): copy from encapsulated IPv6 header
  memcpy (&data->ip6hdr[data->exthdr_type+20].ip6_dst, &data->ip6hdr[data->exthdr_type].ip6_dst, 16 * sizeof (uint8_t));

  // Update TCP stuff, if appropriate.
  if ((type == 3) || (type == 12)) {
    // TCP data offset (4 bits)
    tcp_dataoffset (type, data);

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);
  }

  // Update ICMP stuff, if appropriate.
  if ((type == 4) || (type == 13)) {
    // ICMP header checksum (16 bits)
    icmp_chksum (type, data);
  }

  // Update UDP stuff, if appropriate.
  if ((type == 5) || (type == 14)) {
    // Length of UDP datagram (16 bits)
    udp_len (type, data);

    // UDP header checksum (16 bits)
    udp_chksum (type, data);
  }

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frames.
  create_ip6_frame (type, data);
  create_6to4_frame (type + 3, data);

  // Update widgets in extension header editing window if open (might not be).
  if (data->hop_flag) {
    hop_show (type, data);  // Populate/set widgets in hop-by-hop header editing window.
  }
  if (data->dst_flag) {
    dst_show (type, data);  // Populate/set widgets in destination header editing window.
  }
  if (data->route_flag) {
    route_show (type, data);  // Populate/set widgets in routing header editing window.
  }
  if (data->auth_flag) {
    auth_show (type, data);  // Populate/set widgets in authentication header editing window.
  }
  if (data->esp_flag) {
    esp_show (type, data);  // Populate/set widgets in encapsulating security payload (ESP) header editing window.
  }

  return (EXIT_SUCCESS);
}
