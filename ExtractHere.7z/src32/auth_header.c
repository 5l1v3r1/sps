/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Authentication extension header editing window
int
auth_win (SPSData *data)
{
  GtkBuilder *builder;
  GError *error = NULL;

  // If authentication window is already open, return with no action.
  if (data->auth_flag) {
    return (EXIT_FAILURE);
  } else {
    data->auth_flag = 1;
  }

  // Create new GtkBuilder object.
  builder = gtk_builder_new();
  if (!gtk_builder_add_from_file (builder, "authentication.ui", &error)) {
    g_warning ("%s", error->message);
    g_free (error);
    exit (EXIT_FAILURE);
  }

  // Get objects from UI file
  data->auth_window = GTK_WIDGET (gtk_builder_get_object (builder, "auth_window"));

  data->button138 = GTK_BUTTON (gtk_builder_get_object (builder, "button138"));  // Toggle: attach / detach an authentication header
  data->textview43 = GTK_WIDGET (gtk_builder_get_object (builder, "textview43"));  // Status: attached / detached
  data->button139 = GTK_BUTTON (gtk_builder_get_object (builder, "button139"));  // Toggle: transport / tunnel mode
  data->textview44 = GTK_WIDGET (gtk_builder_get_object (builder, "textview44"));  // Status: transport / tunnel mode
  data->entry433 = GTK_WIDGET (gtk_builder_get_object (builder, "entry433"));  // Payload length
  data->entry434 = GTK_WIDGET (gtk_builder_get_object (builder, "entry434"));  // Reserved
  data->entry435 = GTK_WIDGET (gtk_builder_get_object (builder, "entry435"));  // Security parameters index (SPI)
  data->entry436 = GTK_WIDGET (gtk_builder_get_object (builder, "entry436"));  // Sequence number
  data->radiobutton67 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton67"));  // Decimal integrity check value (ICV) entry
  data->radiobutton68 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton68"));  // Hexadecimal integrity check value (ICV) entry
  data->entry437 = GTK_WIDGET (gtk_builder_get_object (builder, "entry437"));  // Integrity check value (ICV)
  data->button108 = GTK_BUTTON (gtk_builder_get_object (builder, "button108"));  // Load ICV from file ...
  data->button122 = GTK_BUTTON (gtk_builder_get_object (builder, "button122"));  // Save data for ICV calculation

  // Connect signals.
  gtk_builder_connect_signals (builder, data);

  // Destroy builder, since we don't need it anymore.
  g_object_unref (G_OBJECT (builder));

  // Show window. All other widgets are automatically shown by GtkBuilder.
  gtk_widget_show (data->auth_window);

  // Populate/set widgets in authentication header editing window.
  auth_show (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Populate auth_window with contents of selected authentication header.
int
auth_show (int type, SPSData *data)
{
  int i, c, val;
  char *temp, *value;
  GtkTextBuffer *textbuffer43, *textbuffer44;

  // Strings to hold miscellaneous calculated values
  temp = allocate_strmem (TMP_STRINGLEN);
  value = allocate_strmem (IP_MAXPACKET);

  // Flag indicating an authentication header
  textbuffer43 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview43));
  if (data->auth_hdr_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer43, "Attached", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer43, "Not Attached", -1);
  }

  // Transport or tunnel mode
  textbuffer44 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview44));
  if (data->auth_tr_tun_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer44, "Tunnel mode", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer44, "Transport mode", -1);
  }

  // Decimal or hexadecimal ICV data entry
  val = data->dec_hex_auth;
  if (val) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton67), FALSE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton67), TRUE);
  }
  // Variable data->dec_hex_auth will be changed by on_radiobutton67_toggled(), so set it now.
  data->dec_hex_auth = val;

  // Payload length
  sprintf (value, "%" PRIu8, (uint8_t) data->authhdr[type].pay_len);
  gtk_entry_set_text (GTK_ENTRY (data->entry433), value);

  // Reserved
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->authhdr[type].reserved));
  gtk_entry_set_text (GTK_ENTRY (data->entry434), value);

  // Security parameters index (SPI)
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->authhdr[type].spi));
  gtk_entry_set_text (GTK_ENTRY (data->entry435), value);

  // Sequence number
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->authhdr[type].seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry436), value);

  // Integrity check value (ICV)
  // NOTE: Always displays in decimal.
  memset (value, 0, IP_MAXPACKET * sizeof (char));
  c = 0;
  for (i=0; i<data->auth_len[type]; i++) {
    sprintf (temp, "%" PRIu8, (uint8_t) data->auth_data[type][i]);
    strncpy (value + c, temp, IP_MAXPACKET - c - 1);  // Minus 1 for string termination.
    c += strnlen (temp, TMP_STRINGLEN);
    if (i != (data->auth_len[type] - 1)) {  // There's more values to come.
      sprintf (value, "%s, ", value);  // Add a comma and space.
      c += 2;
    }
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry437), value);

  // Free allocated memory.
  free (temp);
  free (value);

  return (EXIT_SUCCESS);
}

// Update authentication header payload and padding length.
int
update_auth_pad (int type, SPSData *data)
{
  // Authentication header payload length (in units of 32-bits) less 2 (Section 2.2 of RFC 2402).
  data->authhdr[type].pay_len = (ATH_HDRLEN / sizeof (uint32_t)) + (data->auth_len[type] / sizeof (uint32_t)) - 2;

  // Add padding, if required. Contents of padding is unimportant. We'll use zero.
  // For IPv6, AH header must be multiple of 64 bits (8 bytes). See Section 3.3.3.2.1 of RFC 2402.
  while (((ATH_HDRLEN + data->auth_len[type]) % 8) != 0) {
    data->auth_data[type][data->auth_len[type]] = 0;
    data->auth_len[type]++;
  }

  return (EXIT_SUCCESS);
}
